// Copies the libraries and fonts that the embedded INDnote needs from node_modules into public/note, so Note mode works fully offline.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const nm = (...p) => path.join(root, 'node_modules', ...p);
const base = path.join(root, 'public', 'note');
const lib = path.join(base, 'lib');
const fontsDir = path.join(base, 'fonts');
fs.mkdirSync(lib, { recursive: true });
fs.mkdirSync(fontsDir, { recursive: true });
let failed = false;
[
  [nm('pdfjs-dist', 'build', 'pdf.min.js'), 'pdf.min.js'],
  [nm('pdfjs-dist', 'build', 'pdf.worker.min.js'), 'pdf.worker.min.js'],
  [nm('pdf-lib', 'dist', 'pdf-lib.min.js'), 'pdf-lib.min.js'],
  [nm('mammoth', 'mammoth.browser.min.js'), 'mammoth.browser.min.js'],
  [nm('jszip', 'dist', 'jszip.min.js'), 'jszip.min.js'],
].forEach(([src, name]) => {
  if (!fs.existsSync(src)) { console.error('MISSING', src); failed = true; return; }
  fs.copyFileSync(src, path.join(lib, name));
});
let css = '';
[['inter', 'Inter'], ['merriweather', 'Merriweather'], ['caveat', 'Caveat'], ['jetbrains-mono', 'JetBrains Mono'], ['poppins', 'Poppins']].forEach(([id, family]) => {
  [400, 700].forEach((w) => {
    const fn = `${id}-latin-${w}-normal.woff2`;
    const src = nm('@fontsource', id, 'files', fn);
    if (!fs.existsSync(src)) { console.warn('font missing', fn); return; }
    fs.copyFileSync(src, path.join(fontsDir, fn));
    css += `@font-face{font-family:'${family}';font-weight:${w};font-style:normal;font-display:swap;src:url(../fonts/${fn}) format('woff2');}\n`;
  });
});
fs.mkdirSync(path.join(base, 'css'), { recursive: true });
fs.writeFileSync(path.join(base, 'css', 'fonts.css'), css);
if (failed) process.exit(1);
console.log('Note mode libraries ready');
