/**
 * Renders notes pages with the browser's own layout engine (SVG foreignObject -> canvas).
 * Unlike html2canvas this keeps wrapped highlights, heading boxes and fonts exactly as on screen.
 */
const blobToDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });

async function collectCss(stage) {
  const used = new Set();
  [stage, ...stage.querySelectorAll('*')].forEach((el) => { getComputedStyle(el).fontFamily.split(',').forEach((f) => used.add(f.trim().replace(/^["']|["']$/g, '').toLowerCase())); });
  let css = '';
  const jobs = [];
  Array.from(document.styleSheets).forEach((ss) => {
    let rules; try { rules = Array.from(ss.cssRules); } catch { return; }
    rules.forEach((r) => {
      if (r instanceof CSSFontFaceRule) {
        const fam = r.style.getPropertyValue('font-family').trim().replace(/^["']|["']$/g, '').toLowerCase();
        const range = r.style.getPropertyValue('unicode-range');
        if (!used.has(fam) || (range && !/U\+0000-00FF/i.test(range))) return;
        let text = r.cssText;
        const urls = [...text.matchAll(/url\(["']?([^"')]+)["']?\)/g)];
        jobs.push((async () => {
          for (const m of urls) {
            try { const res = await fetch(new URL(m[1], ss.href || document.baseURI)); text = text.replace(m[0], `url(${await blobToDataUrl(await res.blob())})`); } catch { /* keep url */ }
          }
          css += `${text}\n`;
        })());
      } else css += `${r.cssText}\n`;
    });
  });
  await Promise.all(jobs);
  return css.replace(/\]\]>/g, ']]&gt;');
}

const loadSvg = (svg) => new Promise((res, rej) => {
  const img = new Image(); img.onload = () => res(img); img.onerror = () => rej(new Error('Page render failed'));
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
});

/** returns an array of JPEG data URLs, one per page */
export async function stageToJpegs(stage, { W, H, GAP, n, scale = 2, onProgress }) {
  const css = await collectCss(stage);
  const clone = stage.cloneNode(true);
  clone.classList.add('exporting');
  const html = new XMLSerializer().serializeToString(clone);
  const out = [];
  for (let i = 0; i < n; i += 1) {
    onProgress?.(i + 1, n);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><foreignObject x="0" y="0" width="${W}" height="${H}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${W}px;height:${H}px;overflow:hidden;position:relative;background:#fff"><style><![CDATA[${css}]]></style><div style="position:absolute;left:0;top:${-i * (H + GAP)}px;width:${W}px">${html}</div></div></foreignObject></svg>`;
    const img = await loadSvg(svg);
    const c = document.createElement('canvas'); c.width = W * scale; c.height = H * scale;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
    out.push(c.toDataURL('image/jpeg', 0.92));
  }
  return out;
}
