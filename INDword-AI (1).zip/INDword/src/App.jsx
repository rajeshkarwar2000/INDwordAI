import { useState, useEffect, useRef, useCallback } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Undo2, Redo2, Save, ArrowLeft, MoreVertical, Minimize2, Minus, Plus, ChevronLeft, ChevronRight, Keyboard } from 'lucide-react';
import Logo from './components/Logo.jsx';
import Home from './components/Home.jsx';
import EditorCanvas, { useWordEditor, pageSize } from './components/EditorCanvas.jsx';
import Ribbon from './ribbon/Ribbon.jsx';
import ScrollRail from './components/ScrollRail.jsx';
import usePinchZoom from './components/usePinchZoom.js';
import SettingsPanel from './components/SettingsPanel.jsx';
import { applyAppearance } from './services/appearance.js';
import BlocksPanel from './components/BlocksPanel.jsx';
import AiNotesDialog, { CoverDialog } from './components/AiNotesDialog.jsx';
import NoteMode from './components/NoteMode.jsx';
import ModeToggle from './components/ModeToggle.jsx';
import ToolRail from './components/ToolRail.jsx';
import { NOTES_META, coverHtml, exportBase } from './services/aiNotes.js';
import { Btn, ExportMenu, Menu, Item } from './ribbon/ui.jsx';
import {
  ConfirmDialog, PromptDialog, ImageDialog, LinkDialog, TableDialog, SymbolDialog, FindDialog, StatsDialog, AboutDialog, Modal,
} from './components/Dialogs.jsx';
import {
  SaveAsDialog, PropertiesDialog, MarginsDialog, ParagraphDialog, HeaderFooterDialog, WatermarkDialog, BorderDialog,
  TocDialog, SourcesDialog, PrintDialog, MoveDialog, InfoDialog, MarginBorderDialog,
} from './components/Dialogs2.jsx';
import { saveTemplate, listTemplates, deleteTemplate, createDoc, saveDoc, deleteDoc, listDocs, getFolders, setFolders as storeFolders, getSettings, setSettings as storeSettings, DEFAULT_SETTINGS } from './services/store.js';
import { importFile } from './services/importers.js';
import { htmlToMarkdown, htmlToText, fullHtml, exportDocx, exportPdf, saveBlob, saveToDevice } from './services/exporters.js';
import { insertToc } from './services/refs.js';
import { TEMPLATES } from './templates.js';
import { newMeta, MARGIN_PRESETS } from './constants.js';
import { pageSize as pageDims } from './components/EditorCanvas.jsx';

const STATUS = {
  saved: ['Saved', 'bg-emerald-500 shadow-[0_0_10px_2px_rgba(16,185,129,0.65)]'],
  unsaved: ['Unsaved Changes', 'bg-amber-400 shadow-[0_0_10px_2px_rgba(251,191,36,0.65)]'],
  saving: ['Saving…', 'bg-blue-500 animate-pulse shadow-[0_0_10px_2px_rgba(59,130,246,0.75)]'],
};
const bytes = (n) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
const MIME = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', pdf: 'application/pdf',
  md: 'text/markdown', html: 'text/html', txt: 'text/plain',
};

export default function App() {
  const [screen, setScreen] = useState('home');
  const [section, setSection] = useState('home');
  const [docs, setDocs] = useState([]);
  const [folders, setFolders] = useState([]);
  const [settings, setSettingsState] = useState(DEFAULT_SETTINGS);
  const [customTpls, setCustomTpls] = useState([]);
  const [doc, setDoc] = useState(null);
  const [meta, setMetaState] = useState(newMeta());
  const [status, setStatus] = useState('saved');
  const [rev, setRev] = useState(0);
  const [tab, setTab] = useState('Home');
  const [mode, setMode] = useState('page');
  const [zoom, setZoom] = useState(1);
  const [focus, setFocus] = useState(false);
  const [ruler, setRuler] = useState(false);
  const [grid, setGrid] = useState(false);
  const [marks, setMarks] = useState(false);
  const [outline, setOutline] = useState(false);
  const [locked, setLocked] = useState(false);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [boundaries, setBoundaries] = useState(false);
  const [navTab, setNavTab] = useState('pages');
  const [kb, setKb] = useState(false); // false = on-screen keyboard never opens by itself
  const mainRef = useRef(null);
  const pinchRef = useRef(null);
  const [dialog, setDialog] = useState(null);
  const [toast, setToast] = useState('');
  const [painterOn, setPainterOn] = useState(false);
  const painter = useRef(null);
  const [hl, setHl] = useState({ on: false, color: '#ffff00' });
  const [appMode, setAppModeState] = useState(() => { try { return localStorage.getItem('indword.mode') === 'note' ? 'note' : 'word'; } catch { return 'word'; } });
  const [noteLoaded, setNoteLoaded] = useState(appMode === 'note');
  const [railPos, setRailPos] = useState(() => { try { return localStorage.getItem('indword.railPos') === 'left' ? 'left' : 'right'; } catch { return 'right'; } });
  const flipRail = () => setRailPos((p) => { const n = p === 'left' ? 'right' : 'left'; try { localStorage.setItem('indword.railPos', n); } catch { /* ignore */ } return n; });
  window.__indMode = appMode;
  const switchMode = async (m) => {
    if (m === 'note') { try { if (stateRef.current.screen === 'editor') await stateRef.current.persist(); } catch { /* ignore */ } setNoteLoaded(true); }
    else document.getElementById('indnote-frame')?.contentWindow?.postMessage({ type: 'ind-hide' }, '*');
    window.__indMode = m; setAppModeState(m);
    try { localStorage.setItem('indword.mode', m); } catch { /* ignore */ }
  };
  useEffect(() => {
    const onMsg = (e) => { if (e.data && e.data.type === 'ind-switch' && e.data.to === 'word') switchMode('word'); };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }); // eslint-disable-line react-hooks/exhaustive-deps
  const fileRef = useRef(null);
  const importAsTemplate = useRef(false);

  const markDirty = useCallback(() => { setStatus('unsaved'); setRev((r) => r + 1); }, []);
  const editor = useWordEditor({ onChange: markDirty });
  const flash = useCallback((m) => { setToast(m); clearTimeout(flash.t); flash.t = setTimeout(() => setToast(''), 3500); }, []);
  const setMeta = (patch) => { setMetaState((m) => ({ ...m, ...patch })); markDirty(); };

  /* ---------- load + theme + native ---------- */
  const refresh = useCallback(async () => { setDocs(await listDocs()); setCustomTpls(await listTemplates()); }, []);
  useEffect(() => { (async () => { setSettingsState(await getSettings()); setFolders(await getFolders()); refresh(); })(); }, [refresh]);
  const theme = settings.theme;
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const dark = theme === 'dark' || (theme === 'system' && mq.matches);
      document.documentElement.classList.toggle('dark', dark);
      if (Capacitor.isNativePlatform()) { StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light }).catch(() => {}); StatusBar.setBackgroundColor({ color: dark ? '#0b0b10' : '#f4f4f8' }).catch(() => {}); }
    };
    apply(); mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);
  const setSettings = (s) => { setSettingsState(s); storeSettings(s); };
  useEffect(() => { applyAppearance(settings); }, [settings]);

  /* ---------- documents ---------- */
  const openDoc = (d) => {
    setDoc(d); setMetaState({ ...newMeta(), ...d.meta }); editor.commands.setContent(d.html || '<p></p>', false);
    setStatus('saved'); setLocked(false); setMode('page'); setFocus(false); setTab('Home'); setZoom(settings.defaultZoom || 1); setRuler(!!settings.showRuler); setBoundaries(!!settings.showBoundaries); setPage(1); setScreen('editor');
  };
  const persist = useCallback(async (override = {}) => {
    if (!doc || !editor) return null;
    setStatus('saving');
    const updated = { ...doc, html: editor.getHTML(), meta, ...override };
    await saveDoc(updated); setDoc(updated); setStatus('saved'); refresh();
    return updated;
  }, [doc, editor, meta, refresh]);
  const persistRef = useRef(persist); persistRef.current = persist;

  useEffect(() => {
    if (screen !== 'editor' || !rev || !settings.autosave) return undefined;
    const t = setTimeout(() => persistRef.current(), settings.autosaveMs || 1500);
    return () => clearTimeout(t);
  }, [rev, screen, settings.autosave, settings.autosaveMs]);

  const goHome = async (sec) => { if (screen === 'editor') await persist(); if (sec) setSection(sec); setScreen('home'); refresh(); };
  const docDefaults = () => ({ size: settings.pageSize, margins: MARGIN_PRESETS[settings.marginPreset]?.m || MARGIN_PRESETS.normal.m, fontSet: settings.fontSet });
  const newDoc = async (id = 'blank') => {
    const t = [...TEMPLATES, ...customTpls].find((x) => x.id === id) || TEMPLATES[0];
    const d = await createDoc({ name: id === 'blank' ? 'Untitled Document' : t.name, html: t.html, meta: { ...docDefaults(), ...(t.meta || {}) } });
    await refresh(); openDoc(d);
  };
  const duplicateCurrent = async () => {
    const cur = await persist(); if (!cur) return;
    const d = await createDoc({ name: `Copy of ${cur.name}`, html: cur.html, folder: cur.folder, meta: cur.meta }); await refresh(); openDoc(d);
  };
  const pickFile = (asTemplate) => { importAsTemplate.current = asTemplate === true; fileRef.current?.click(); };
  const handleFile = async (f, asTemplate) => {
    try {
      flash(`Importing ${f.name}…`);
      const r = await importFile(f);
      if (asTemplate) { await saveTemplate({ name: r.name, desc: `Imported from ${f.name}`, html: r.html, meta: { ...docDefaults(), ...(r.meta || {}) } }); await refresh(); setSection('templates'); flash(`“${r.name}” added to My Templates`); return; }
      const d = await createDoc({ name: r.name, html: r.html, ext: r.ext, meta: { ...docDefaults(), ...(r.meta || {}) } });
      await refresh(); if (screen === 'editor') await persist(); openDoc(d);
      flash(r.notes[0] ? `${f.name} opened. ${r.notes[0]}` : `${f.name} opened`);
    } catch (err) { flash(err.message || 'Could not open that file'); }
  };
  const onFile = (e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) handleFile(f, importAsTemplate.current); importAsTemplate.current = false; };

  /* ---------- export ---------- */
  const makeBlob = async (fmt, name, html, json, m) => {
    if (fmt === 'docx') return exportDocx(json, { ...m, title: name });
    if (fmt === 'pdf') return exportPdf(document.querySelector('.page'), m);
    if (fmt === 'md') return new Blob([htmlToMarkdown(html)], { type: MIME.md });
    if (fmt === 'html') return new Blob([fullHtml(name, html, m)], { type: MIME.html });
    return new Blob([htmlToText(html)], { type: MIME.txt });
  };
  const exportAs = async (fmt, device = true) => {
    try {
      flash(`Preparing .${fmt}…`);
      const blob = await makeBlob(fmt, doc.name, editor.getHTML(), editor.getJSON(), meta);
      const base = exportBase(doc.name, meta);
      const msg = device ? await saveToDevice(`${base}.${fmt}`, blob) : (await saveBlob(`${base}.${fmt}`, blob), 'Ready');
      flash(msg);
    } catch (e) { flash(`Export failed: ${e.message}`); }
  };
  const exportOther = async (d, fmt) => {
    try {
      editor.commands.setContent(d.html, false);
      const blob = await makeBlob(fmt, d.name, editor.getHTML(), editor.getJSON(), d.meta || newMeta());
      flash(await saveToDevice(`${d.name}.${fmt}`, blob));
    } catch (e) { flash(`Export failed: ${e.message}`); }
  };
  const share = async (fmt) => { try { await saveBlob(`${exportBase(doc.name, meta)}.${fmt}`, await makeBlob(fmt, doc.name, editor.getHTML(), editor.getJSON(), meta)); } catch (e) { flash(e.message); } };
  const copyText = async () => { try { await navigator.clipboard.writeText(editor.getText()); flash('Document text copied'); } catch { flash('Clipboard blocked'); } };
  const saveAs = async ({ name, folder, type, device }) => {
    setDialog(null);
    const cur = await persist({ name, folder }); if (!cur) return;
    if (type !== 'indword') await exportAs(type, true);
    else if (device) { flash(await saveToDevice(`${name}.html`, new Blob([fullHtml(name, editor.getHTML(), meta)], { type: MIME.html }))); }
    else flash('Saved');
  };

  /* ---------- home actions ---------- */
  const ask = (title, label, cb, initial = '') => setDialog({ name: 'prompt', title, label, cb, initial });
  const docAction = async (k, d) => {
    if (k === 'open') openDoc(d);
    else if (k === 'rename') ask('Rename Document', 'Name', async (v) => { await saveDoc({ ...d, name: v, modified: d.modified }); refresh(); setDialog(null); }, d.name);
    else if (k === 'pin' || k === 'unpin') { await saveDoc({ ...d, pinned: k === 'pin', modified: d.modified }); refresh(); }
    else if (k === 'duplicate') { await createDoc({ name: `Copy of ${d.name}`, html: d.html, folder: d.folder, meta: d.meta, ext: d.ext }); refresh(); flash('Duplicated'); }
    else if (k === 'export') setDialog({ name: 'exportpick', d });
    else if (k === 'move') setDialog({ name: 'move', d });
    else if (k === 'info') setDialog({ name: 'info', d });
    else if (k === 'delete') setDialog({ name: 'delete', d });
  };
  const folderAction = (k, f) => {
    if (k === 'create') ask('New Folder', 'Folder name', async (v) => { if (folders.includes(v)) { flash('That folder already exists'); return; } const n = [...folders, v]; setFolders(n); await storeFolders(n); setDialog(null); });
    else ask('Rename Folder', 'Folder name', async (v) => {
      const n = folders.map((x) => (x === f ? v : x)); setFolders(n); await storeFolders(n);
      await Promise.all(docs.filter((d) => d.folder === f).map((d) => saveDoc({ ...d, folder: v, modified: d.modified }))); refresh(); setDialog(null);
    }, f);
  };

  /* ---------- format painter ---------- */
  const togglePainter = () => {
    if (painterOn) { painter.current = null; setPainterOn(false); return; }
    painter.current = { style: editor.getAttributes('textStyle'), bold: editor.isActive('bold'), italic: editor.isActive('italic'), underline: editor.isActive('underline'), strike: editor.isActive('strike'), hl: editor.getAttributes('highlight').color };
    setPainterOn(true); flash('Format Painter: select text to apply');
  };
  useEffect(() => {
    if (!editor || !painterOn) return undefined;
    const h = () => {
      const p = painter.current; if (!p || editor.state.selection.empty) return;
      painter.current = null;
      let c = editor.chain().focus().unsetAllMarks().setMark('textStyle', p.style);
      if (p.bold) c = c.setBold(); if (p.italic) c = c.setItalic(); if (p.underline) c = c.setUnderline(); if (p.strike) c = c.setStrike();
      if (p.hl) c = c.setHighlight({ color: p.hl });
      c.run(); setPainterOn(false);
    };
    editor.on('selectionUpdate', h);
    return () => editor.off('selectionUpdate', h);
  }, [editor, painterOn]);

  /* ---------- highlighter tool: stays on until another tool is chosen ---------- */
  useEffect(() => {
    if (!editor || !hl.on) return undefined;
    let t;
    const h = () => {
      clearTimeout(t);
      t = setTimeout(() => {
        if (editor.state.selection.empty) return;
        if (hl.color) editor.chain().setHighlight({ color: hl.color }).run(); else editor.chain().unsetHighlight().run();
      }, 350);
    };
    editor.on('selectionUpdate', h);
    return () => { editor.off('selectionUpdate', h); clearTimeout(t); };
  }, [editor, hl]);

  /* ---------- editability, keys, back button ---------- */
  useEffect(() => { editor?.setEditable(!(locked || mode === 'read'), false); }, [editor, locked, mode]);
  const stateRef = useRef({}); stateRef.current = { screen, dialog, focus, persist, goHome, appMode };
  useEffect(() => {
    const key = (e) => {
      if (e.key === 'Escape') setHl((h) => ({ ...h, on: false }));
      if (!(e.ctrlKey || e.metaKey) || stateRef.current.screen !== 'editor') return;
      const k = e.key.toLowerCase();
      if (k === 's') { e.preventDefault(); stateRef.current.persist(); }
      else if (k === 'k') { e.preventDefault(); setDialog({ name: 'link' }); }
      else if (k === 'f') { e.preventDefault(); setDialog({ name: 'find' }); }
      else if (k === 'x' && e.shiftKey) { e.preventDefault(); editor?.chain().focus().toggleStrike().run(); }
    };
    window.addEventListener('keydown', key);
    let sub;
    if (Capacitor.isNativePlatform()) {
      CapApp.addListener('backButton', () => {
        const s = stateRef.current;
        if (s.appMode === 'note') return; // Note mode handles its own back button
        if (s.dialog) setDialog(null);
        else if (s.focus) setFocus(false);
        else if (s.screen === 'editor') s.goHome();
        else CapApp.exitApp();
      }).then((h) => { sub = h; });
    }
    return () => { window.removeEventListener('keydown', key); sub?.remove(); };
  }, [editor]);

  /* ---------- pages & scrolling ---------- */
  const pageTop = () => { const pe = document.querySelector('.page'); const m = mainRef.current; return pe && m ? pe.getBoundingClientRect().top - m.getBoundingClientRect().top + m.scrollTop : 0; };
  const goPage = (n) => {
    const m = mainRef.current; if (!m) return;
    const [, h] = pageDims(meta); const target = Math.min(pages, Math.max(1, n));
    m.scrollTo({ top: pageTop() + (target - 1) * h * zoom - 8, behavior: 'smooth' }); setPage(target);
  };
  const onScroll = () => {
    const m = mainRef.current; if (!m || mode === 'web') return;
    const [, h] = pageDims(meta);
    setPage(Math.min(pages, Math.max(1, Math.floor((m.scrollTop + m.clientHeight * 0.35 - pageTop()) / (h * zoom)) + 1)));
  };

  /* ---------- zoom fit ---------- */
  const fit = (kind) => {
    const [w, h] = pageSize(meta);
    setZoom(Math.max(0.3, Math.min(2, kind === 'width' ? (window.innerWidth - 40) / w : (window.innerHeight - 260) / h)));
  };

  const showPinch = useCallback((v) => { const el = pinchRef.current; if (!el) return; el.style.display = v ? 'block' : 'none'; if (v) el.textContent = `${v}%`; }, []);
  usePinchZoom(mainRef, { zoom, setZoom, enabled: screen === 'editor', onLabel: showPinch });

  useEffect(() => { if (editor) editor.view.dom.setAttribute('inputmode', kb ? 'text' : 'none'); }, [editor, kb, screen]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!editor) return null;
  const view = { boundaries, setBoundaries, navTab, setNavTab, pageNav: { page, pages, go: goPage }, mode, setMode, focus, setFocus, ruler, setRuler, grid, setGrid, marks, setMarks, outline, setOutline, locked, setLocked, zoom, setZoom, fit, theme, setTheme: (t) => setSettings({ ...settings, theme: t }) };
  const toggleKb = () => { const on = !kb; setKb(on); if (on) setTimeout(() => editor?.commands.focus(), 80); else document.activeElement?.blur?.(); };
  const c = { kb, toggleKb,
    highlighter: { on: hl.on, color: hl.color, stop: () => setHl((h) => ({ ...h, on: false })), start: (color) => { setHl({ on: true, color }); if (!editor.state.selection.empty) { if (color) editor.chain().focus().setHighlight({ color }).run(); else editor.chain().focus().unsetHighlight().run(); } flash(color ? 'Highlighter on: select text to highlight it' : 'Eraser on: select text to remove highlight'); } },
    editor, meta, setMeta, view, flash, ask, painter: { on: painterOn, toggle: togglePainter }, dlg: (name) => { if (name === 'image') editor.view.dom.blur(); setDialog({ name }); },
    act: { saveTemplate: () => ask('Save as Template', 'Template name', async (v) => { await saveTemplate({ name: v, html: editor.getHTML(), meta }); await refresh(); close(); flash(`“${v}” saved to My Templates`); }, doc.name), newBlank: () => newDoc('blank'), goHome, duplicateCurrent, pickFile: () => pickFile(false), save: () => persist(), exportAs, share, copyText },
  };

  /* ---------- dialogs ---------- */
  const close = () => setDialog(null);
    const D = dialog;
  const selText = () => { const { from, to } = editor.state.selection; return editor.state.doc.textBetween(from, to, ' '); };
  const blockAttrs = (a) => editor.chain().focus().updateAttributes('paragraph', a).updateAttributes('heading', a).run();
  const dialogs = D && (() => {
    switch (D.name) {
      case 'ainotes': return <AiNotesDialog insertMode={screen === 'editor'} onClose={close} onResult={async (html, name, cols = 2) => {
        close();
        if (screen === 'editor' && editor) { editor.chain().insertContentAt(editor.state.doc.content.size, html).run(); setMeta({ ...NOTES_META, columns: cols }); flash('Notes added'); return; }
        const d = await createDoc({ name, html, meta: { ...docDefaults(), ...NOTES_META, columns: cols } }); await refresh(); openDoc(d);
      }} />;
      case 'cover': return <CoverDialog onClose={close} onInsert={(url) => { close(); editor.chain().insertContentAt(0, coverHtml(url)).run(); setMeta(NOTES_META); flash('Cover added'); }} />;
      case 'prompt': return <PromptDialog title={D.title} label={D.label} initial={D.initial} onOk={(v) => { close(); D.cb(v); }} onClose={close} />;
      case 'delete': return <ConfirmDialog title="Delete document?" message={`“${D.d.name}” will be permanently deleted from this tablet.`} onClose={close} onOk={async () => { await deleteDoc(D.d.id); close(); refresh(); flash('Deleted'); }} />;
      case 'move': return <MoveDialog folders={folders} current={D.d.folder} onClose={close} onMove={async (f) => { await saveDoc({ ...D.d, folder: f, modified: D.d.modified }); close(); refresh(); }} />;
      case 'info': return <InfoDialog doc={D.d} size={bytes(new Blob([D.d.html]).size)} onClose={close} />;
      case 'exportpick': return (
        <Modal title="Download / Export" onClose={close}>
          {[['docx', 'Word (.docx)'], ['md', 'Markdown (.md)'], ['html', 'HTML (.html)'], ['txt', 'Plain Text (.txt)']].map(([k, n]) => <button key={k} type="button" className="mitem" onClick={() => { close(); exportOther(D.d, k); }}>{n}</button>)}
          <p className="mt-2 text-xs opacity-60">Open the document to export a PDF.</p>
        </Modal>);
      case 'about': return <AboutDialog onClose={close} />;
      case 'settings': return <Modal title="Settings & Appearance" onClose={close} wide><SettingsPanel settings={settings} setSettings={setSettings} /></Modal>;
      case 'marginborder': return <MarginBorderDialog value={meta.marginBorder} onClose={close} onApply={(v) => { setMeta({ marginBorder: v }); close(); }} />;
      case 'image': return <ImageDialog flash={flash} onClose={close} onInsert={(src, alt) => { editor.chain().setImage({ src, alt: alt || '' }).run(); editor.view.dom.blur(); close(); }} />;
      case 'link': return <LinkDialog initial={editor.getAttributes('link').href} selectedText={selText()} onClose={close} onApply={(v) => {
        const ch = editor.chain().focus();
        if (!v) ch.extendMarkRange('link').unsetLink().run();
        else if (editor.state.selection.empty || (v.text && v.text !== selText())) ch.insertContent(`<a href="${v.href}" target="${v.blank ? '_blank' : '_self'}">${v.text || v.href}</a>`).run();
        else ch.extendMarkRange('link').setLink({ href: v.href, target: v.blank ? '_blank' : '_self' }).run();
        close();
      }} />;
      case 'table': return <TableDialog onClose={close} onInsert={(r, cc, h) => { editor.chain().focus().insertTable({ rows: r, cols: cc, withHeaderRow: h }).run(); close(); }} />;
      case 'symbols': return <SymbolDialog onClose={close} onPick={(s) => editor.chain().focus().insertContent(s).run()} />;
      case 'find': return <FindDialog editor={editor} flash={flash} onClose={close} />;
      case 'stats': return <StatsDialog editor={editor} pages={pages} onClose={close} />;
      case 'saveas': return <SaveAsDialog name={doc.name} folder={doc.folder} folders={folders} onClose={close} onSave={saveAs} />;
      case 'props': return <PropertiesDialog doc={doc} meta={meta} size={bytes(new Blob([editor.getHTML()]).size)} onClose={close} onSave={(m) => { setMeta(m); persist({ meta: { ...meta, ...m } }); close(); }} />;
      case 'margins': return <MarginsDialog margins={meta.margins} onClose={close} onApply={(m) => { setMeta({ margins: m }); close(); }} />;
      case 'paragraph': {
        const a = editor.getAttributes(editor.isActive('heading') ? 'heading' : 'paragraph'); const n = (v) => parseInt(v, 10) || 0;
        return <ParagraphDialog initial={{ left: n(a.marginLeft), right: n(a.marginRight), before: n(a.marginTop), after: n(a.marginBottom), line: parseFloat(a.lineHeight) || 1.5 }} onClose={close}
          onApply={(v) => { blockAttrs({ marginLeft: v.left ? `${v.left}px` : null, marginRight: v.right ? `${v.right}px` : null, marginTop: `${v.before}px`, marginBottom: `${v.after}px`, lineHeight: String(v.line) }); close(); }} />;
      }
      case 'hf': return <HeaderFooterDialog meta={meta} onClose={close} onApply={(v) => { setMeta(v); close(); }} />;
      case 'watermark': return <WatermarkDialog value={meta.watermark} onClose={close} onApply={(v) => { setMeta({ watermark: v }); close(); }} />;
      case 'border': return <BorderDialog value={meta.border} onClose={close} onApply={(v) => { setMeta({ border: v }); close(); }} />;
      case 'toc': return <TocDialog onClose={close} onApply={(lv) => { insertToc(editor, lv); close(); }} />;
      case 'sources': return <SourcesDialog sources={meta.sources} style={meta.citeStyle} onChange={(s) => setMeta({ sources: s })} onStyle={(s) => setMeta({ citeStyle: s })} onClose={close} />;
      case 'print': return <PrintDialog meta={meta} onMeta={setMeta} onClose={close} onPrint={async () => { close(); await share('pdf'); }} />;
      default: return null;
    }
  })();

  /* ---------- screens ---------- */
  const [label, dot] = STATUS[status];
  const words = screen === 'editor' ? editor.getText().trim().split(/\s+/).filter(Boolean).length : 0;
  const headings = [];
  if (screen === 'editor' && outline) editor.state.doc.descendants((n, pos) => { if (n.type.name === 'heading' && n.textContent.trim()) headings.push({ pos, level: n.attrs.level, text: n.textContent }); return true; });

  return (
    <div className="h-[100dvh] overflow-hidden">
      <NoteMode active={appMode === 'note'} loaded={noteLoaded} />
      <input ref={fileRef} type="file" hidden accept=".docx,.txt,.md,.markdown,.html,.htm,text/plain,text/markdown,text/html,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={onFile} />
      {screen === 'home' ? (
        <Home docs={docs} folders={folders} settings={settings} setSettings={setSettings} section={section} setSection={setSection} theme={theme}
          onNew={(id) => newDoc(id)} onOpen={openDoc} templates={[...TEMPLATES, ...customTpls]} onTplDelete={async (t) => { await deleteTemplate(t.id); refresh(); flash('Template deleted'); }} onPickFile={(f, asT) => (f instanceof File ? handleFile(f, asT) : pickFile(false))}
          onDocAction={docAction} onFolder={folderAction} onTheme={(t) => setSettings({ ...settings, theme: t })} openAbout={() => setDialog({ name: 'about' })} onAi={() => setDialog({ name: 'ainotes' })} appMode={appMode} onMode={switchMode} />
      ) : (
        <div className="wallpaper flex h-full flex-col">
          {!focus && (
            <header className="glass glass-ribbon no-print z-40 rounded-b-3xl pt-[env(safe-area-inset-top)]">
              <div className="flex items-center gap-1 px-2 pt-2">
                <Btn icon={ArrowLeft} title="Back to Home" onClick={() => goHome()} />
                <span className="hidden md:block"><Logo size={30} /></span>
                <input value={doc.name} onChange={(e) => { setDoc({ ...doc, name: e.target.value }); markDirty(); }} aria-label="Document title"
                  className="min-h-[44px] min-w-0 flex-1 rounded-xl bg-transparent px-3 text-center text-[15px] font-semibold outline-none hover:bg-black/5 focus:bg-white/60 dark:hover:bg-white/10 dark:focus:bg-white/10" />
                <ModeToggle mode={appMode} onChange={switchMode} compact />
                <Btn icon={Keyboard} title={kb ? 'Keyboard on (tap to hide)' : 'Keyboard off (tap to type)'} on={kb} onClick={toggleKb} />
                <Btn icon={Undo2} title="Undo (Ctrl+Z)" disabled={!editor.can().undo()} onClick={() => editor.chain().focus().undo().run()} />
                <Btn icon={Redo2} title="Redo (Ctrl+Y)" disabled={!editor.can().redo()} onClick={() => editor.chain().focus().redo().run()} />
                <Btn icon={Save} title="Save (Ctrl+S)" onClick={() => persist().then(() => flash('Saved'))} />
                <ExportMenu onExport={exportAs} label="" />
                <Menu width={230} trigger={() => <Btn icon={MoreVertical} title="More options" />}>
                  {(cl) => (<>
                    <Item onClick={() => { setDialog({ name: 'find' }); cl(); }}>Find and Replace</Item>
                    <Item onClick={() => { setDialog({ name: 'props' }); cl(); }}>Document Properties</Item>
                    <Item onClick={() => { setFocus(true); cl(); }}>Focus Mode</Item>
                    <Item onClick={() => { setDialog({ name: 'settings' }); cl(); }}>Settings &amp; Appearance</Item>
                    <Item onClick={() => { setDialog({ name: 'about' }); cl(); }}>About INDword</Item>
                  </>)}
                </Menu>
                <div className="ml-1 hidden shrink-0 items-center gap-2 rounded-full border border-black/5 bg-white/50 px-3 py-2 text-xs font-medium sm:flex dark:border-white/10 dark:bg-white/10">
                  <span className={`h-2.5 w-2.5 rounded-full ${dot}`} />{label}
                </div>
              </div>
              {mode !== 'read' && <Ribbon c={c} tab={tab} setTab={setTab} />}
            </header>
          )}
          <div className="flex min-h-0 flex-1">
            {outline && !focus && (
              <aside className="glass glass-side no-print m-3 mr-0 flex w-72 shrink-0 flex-col overflow-hidden rounded-3xl p-2">
                <div className="mb-1 flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
                  {[['pages', 'Pages'], ['headings', 'Headings'], ['blocks', 'Blocks']].map(([k, n]) => <button key={k} type="button" onClick={() => setNavTab(k)} className={`min-h-[40px] flex-1 rounded-xl text-sm font-medium ${navTab === k ? 'bg-white shadow dark:bg-zinc-700' : ''}`}>{n}</button>)}
                </div>
                <div className="flex-1 overflow-y-auto">
                  {navTab === 'headings' && (<>
                    {!headings.length && <p className="px-3 py-2 text-sm opacity-60">Headings you add will appear here.</p>}
                    {headings.map((h, i) => <button key={i} type="button" className="mitem" style={{ paddingLeft: 12 + (h.level - 1) * 14 }} onClick={() => editor.chain().focus().setTextSelection(h.pos + 1).scrollIntoView().run()}><span className="truncate">{h.text}</span></button>)}
                  </>)}
                  {navTab === 'blocks' && <BlocksPanel editor={editor} mainRef={mainRef} ask={ask} flash={flash} />}
                  {navTab === 'pages' && (
                    <div className="grid grid-cols-2 gap-2 p-1">
                      {Array.from({ length: pages }, (_, i) => (
                        <button key={i} type="button" onClick={() => goPage(i + 1)} className={`flex flex-col items-center gap-1 rounded-2xl p-2 ${page === i + 1 ? 'bg-blue-500/20 ring-2 ring-blue-500' : 'hover:bg-black/5 dark:hover:bg-white/10'}`}>
                          <span className="grid w-full place-items-center rounded bg-white text-xs text-black/40 shadow" style={{ aspectRatio: `${pageDims(meta)[0]} / ${pageDims(meta)[1]}` }}>{i + 1}</span>
                          <span className="text-xs">Page {i + 1}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </aside>
            )}
            <div className="relative min-w-0 flex-1">
              <main ref={mainRef} onScroll={onScroll} style={{ touchAction: 'pan-x pan-y' }} className="hide-vscroll h-full overflow-auto">
                <EditorCanvas editor={editor} meta={meta} zoom={zoom} mode={focus ? 'focus' : mode} showRuler={ruler} showGrid={grid} marks={marks} boundaries={boundaries} onPages={setPages} />
              </main>
              <ScrollRail targetRef={mainRef} page={page} pages={pages} resetKey={`${zoom}-${pages}-${screen}`} />
            </div>
          </div>
          {focus ? (
            <button type="button" onClick={() => setFocus(false)} className="glass no-print fixed right-4 top-[calc(env(safe-area-inset-top)+12px)] z-40 flex min-h-[44px] items-center gap-2 rounded-full px-4 text-sm font-medium"><Minimize2 size={16} />Exit Focus</button>
          ) : (
            <footer className="glass glass-status no-print z-40 flex items-center justify-between gap-2 rounded-t-2xl px-4 py-1.5 pb-[calc(env(safe-area-inset-bottom)+6px)] text-xs">
              <span className="flex items-center gap-1">
                <button type="button" aria-label="Previous page" className="rbtn !min-h-[36px] !min-w-[36px]" disabled={page <= 1} onClick={() => goPage(page - 1)}><ChevronLeft size={16} /></button>
                <Menu width={200} trigger={() => <span className="rbtn !min-h-[36px] text-xs" role="button">Page {page} of {pages}</span>}>
                  {(cl) => (<>
                    <div className="px-2 pb-1 text-[11px] uppercase tracking-wide opacity-50">Go to page</div>
                    <input type="number" min="1" max={pages} defaultValue={page} className="ginput mb-1" onKeyDown={(e) => { if (e.key === 'Enter') { goPage(Number(e.target.value)); cl(); } }} />
                    <Item onClick={() => { goPage(1); cl(); }}>First page</Item>
                    <Item onClick={() => { goPage(pages); cl(); }}>Last page</Item>
                    <Item onClick={() => { setNavTab('pages'); setOutline(true); cl(); }}>Show pages panel</Item>
                  </>)}
                </Menu>
                <button type="button" aria-label="Next page" className="rbtn !min-h-[36px] !min-w-[36px]" disabled={page >= pages} onClick={() => goPage(page + 1)}><ChevronRight size={16} /></button>
                <span className="ml-2 opacity-70">{words} words</span>
              </span>
              <span className="opacity-60">{meta.lang}{locked ? ' · Protected' : ''}</span>
              <span className="flex items-center gap-1">
                <button type="button" aria-label="Zoom out" className="rbtn !min-h-[36px] !min-w-[36px]" onClick={() => setZoom(Math.max(0.25, +(zoom - 0.1).toFixed(2)))}><Minus size={16} /></button>
                <span className="w-10 text-center tabular-nums">{Math.round(zoom * 100)}%</span>
                <button type="button" aria-label="Zoom in" className="rbtn !min-h-[36px] !min-w-[36px]" onClick={() => setZoom(Math.min(3, +(zoom + 0.1).toFixed(2)))}><Plus size={16} /></button>
              </span>
            </footer>
          )}
        </div>
      )}
      <div ref={pinchRef} className="glass no-print pointer-events-none fixed left-1/2 top-1/3 z-[75] -translate-x-1/2 rounded-full px-6 py-3 text-xl font-semibold tabular-nums" style={{ display: 'none' }} />
      {hl.on && screen === 'editor' && (
        <button type="button" onClick={() => setHl((h) => ({ ...h, on: false }))} className="glass glass-menu no-print fixed bottom-16 left-1/2 z-[70] flex min-h-[44px] -translate-x-1/2 items-center gap-2 rounded-full px-5 text-sm font-medium">
          <span className="h-4 w-4 rounded-full border border-black/20" style={{ background: hl.color || '#fff' }} />{hl.color ? 'Highlighter on' : 'Eraser on'} · tap to stop
        </button>
      )}
      {!focus && mode !== 'read' && editor && <ToolRail editor={editor} c={c} hl={hl} setHl={setHl} zoom={zoom} setZoom={setZoom} pos={railPos} onFlip={flipRail}
        onNote={() => switchMode('note')} kb={kb} toggleKb={toggleKb} outlineOn={outline} toggleOutline={() => setOutline((o) => !o)} />}
      {dialogs}
      {toast && <div className="glass no-print fixed bottom-16 left-1/2 z-[80] max-w-[90vw] -translate-x-1/2 animate-pop rounded-full px-5 py-3 text-sm">{toast}</div>}
    </div>
  );
}
