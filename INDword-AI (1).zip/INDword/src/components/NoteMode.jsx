/** INDnote (stylus notes) embedded as a full-screen page. It is created on first use and then kept alive, so switching back and forth is instant and nothing is lost. */
export default function NoteMode({ active, loaded }) {
  if (!loaded) return null;
  return (
    <iframe id="indnote-frame" title="INDnote" src="note/index.html" allow="clipboard-read; clipboard-write; camera"
      className="fixed inset-0 z-[90] h-full w-full border-0" style={{ display: active ? 'block' : 'none', background: '#0b1020' }} />
  );
}
