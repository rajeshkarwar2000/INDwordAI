// Installs the native Android pieces into the generated android project. Safe to run repeatedly.
const fs = require('fs');
const path = require('path');
const root = __dirname;
const android = path.join(root, 'android');
if (!fs.existsSync(android)) process.exit(0);

// 1) Java: two "Save to..." plugins (INDword PDF export, Note mode export) and the activity that registers them
const src = path.join(root, 'resources', 'native');
const dest = path.join(android, 'app', 'src', 'main', 'java', 'com', 'indword', 'app');
fs.mkdirSync(dest, { recursive: true });
['SaveAsPlugin.java', 'SaveFilePlugin.java', 'MainActivity.java'].forEach((f) => fs.copyFileSync(path.join(src, f), path.join(dest, f)));

// 2) manifest: camera permission (photo to note), free rotation, keyboard resize, big heap for large PDFs
const mp = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(mp)) {
  let m = fs.readFileSync(mp, 'utf8');
  if (!m.includes('android.permission.CAMERA')) m = m.replace('<application', '<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application');
  if (!m.includes('android:screenOrientation')) m = m.replace('<activity', '<activity android:screenOrientation="fullSensor"');
  if (!m.includes('android:windowSoftInputMode')) m = m.replace('<activity', '<activity android:windowSoftInputMode="adjustResize"');
  if (!m.includes('android:largeHeap')) m = m.replace('<application', '<application android:largeHeap="true"');
  fs.writeFileSync(mp, m);
}
console.log('INDword native pieces installed');
