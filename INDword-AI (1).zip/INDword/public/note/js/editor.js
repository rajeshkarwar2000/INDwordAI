// Editor core: layout, pages, zoom, history, saving, selection overlay.
(function () {
  const U = IND.u, h = U.h, R = IND.render, S = IND.store;
  const E = (IND.editor = {});
  E.doc = null; E.pgs = []; E.zoom = 1; E.curIdx = 0; E.hist = []; E.redoS = []; E.sel = null; E.baseW = 900;

  // ---------------------------------------------------------------- mount
  E.mount = function () {
    const root = U.$('#editor'); root.innerHTML = '';
    E.slots = { top: h('div', { class: 'slot slot-top' }), left: h('div', { class: 'slot slot-left' }), right: h('div', { class: 'slot slot-right' }), bottom: h('div', { class: 'slot slot-bottom' }) };
    E.stage = h('div', { class: 'stage', id: 'stage' });
    E.indEl = h('button', { class: 'pgind chipb', onclick: (e) => E.gotoPop(e.currentTarget) }, '1/1');
    E.zoomChip = h('button', { class: 'pgind chipb', onclick: (e) => IND.tools.zoomPop(e.currentTarget, 'below') }, '100%');
    E.bmBtn = h('button', { class: 'ibtn', html: IND.icon('bookmark'), 'aria-label': 'Bookmark page', onclick: () => E.toggleBookmark(E.curIdx) });
    E.titleEl = h('button', { class: 'title', onclick: () => U.prompt('Rename note', E.doc.name, 'Rename', (v) => { E.doc.name = v; E.titleEl.textContent = v; E.dirty(); }) });
    const top = h('div', { class: 'topbar glass' },
      h('button', { class: 'ibtn', html: IND.icon('home'), 'aria-label': 'Home', onclick: () => E.close() }),
      window.parent !== window ? h('button', { class: 'chipb', 'aria-label': 'Switch to Word mode', onclick: async () => { try { IND.input.finishText(); await E.save(); } catch (e) { /* ignore */ } IND.toWord(); } }, '✍ Word') : null,
      E.titleEl,
      h('div', { class: 'grow' }),
      h('button', { class: 'ibtn', html: IND.icon('left'), 'aria-label': 'Previous page', onclick: () => E.goTo(E.curIdx - 1) }),
      E.indEl, E.zoomChip,
      h('button', { class: 'ibtn', html: IND.icon('right'), 'aria-label': 'Next page', onclick: () => E.goTo(E.curIdx + 1) }),
      E.bmBtn,
      h('button', { class: 'ibtn', html: IND.icon('export'), 'aria-label': 'Export', onclick: (e) => IND.panels.exportMenu(e.currentTarget) }),
      h('button', { class: 'ibtn', html: IND.icon('settings'), 'aria-label': 'Settings', onclick: (e) => IND.panels.settings(e.currentTarget) }));
    E.vsb = h('div', { class: 'vsb' }, h('i')); E.hsb = h('div', { class: 'hsb' }, h('i')); E.sbBub = h('div', { class: 'sbbub glass' });
    E.inner = h('div', { class: 'pages' }); E.stage.append(E.inner);
    E.laserCv = h('canvas', { class: 'laser-cv' }); E.ctx = h('div', { class: 'ctxbar glass' });
    const wrap = h('div', { class: 'stagewrap' }, E.stage, E.laserCv, E.ctx, E.vsb, E.hsb, E.sbBub);
    const middle = h('div', { class: 'middle' }, E.slots.left, wrap, E.slots.right);
    root.append(top, E.slots.top, middle, E.slots.bottom);
    E.stage.addEventListener('scroll', () => { E.busy(); if (!E._sc) E._sc = requestAnimationFrame(() => { E._sc = 0; E.trackPage(); E.updSb(true); }); clearTimeout(E._rt); E._rt = setTimeout(E.refreshTiles, 140); }, { passive: true });
    IND.input.attach(E.stage); E.dragSb(E.vsb, true); E.dragSb(E.hsb, false);
    addEventListener('resize', U.debounce(() => { if (E.doc) E.layout(); IND.tools && IND.tools.renderToolbar(); }, 200));
    R.onImage = U.debounce(() => E.renderVisible(), 60);
  };

  E.busy = function () {
    const r = U.$('#editor'); if (!r.classList.contains('busy')) r.classList.add('busy');
    clearTimeout(E._bt); E._bt = setTimeout(() => r.classList.remove('busy'), 220);
  };

  // ---------------------------------------------------------------- open / close
  E.open = function (doc) {
    if (!E.stage) E.mount();
    E.doc = doc; doc.bookmarks = doc.bookmarks || []; E.hist = []; E.redoS = []; E.sel = null; E.zoom = 1; E.curIdx = doc.lastPage || 0;
    E.titleEl.textContent = doc.name;
    const r = S.settings.recent.filter((x) => x !== doc.id); r.unshift(doc.id); S.settings.recent = r.slice(0, 12); S.saveSettings();
    IND.show('editor');
    IND.tools.renderToolbar();
    requestAnimationFrame(() => { E.buildPages(); E.goTo(E.curIdx, true); E.updUndo(); });
  };
  E.close = async function () {
    if (IND.input) IND.input.finishText();
    await E.save();
    E.doc = null; E.pgs = []; E.inner.innerHTML = ''; IND.input.laserStop(); E.ctx.classList.remove('show');
    IND.show('home'); IND.home.refresh();
  };
  E.switchTo = async function (id) {
    if (E.doc && E.doc.id === id) return;
    IND.input.finishText(); await E.save();
    const d = await S.getDoc(id); if (d) E.open(d);
  };

  // ---------------------------------------------------------------- pages
  // pages are drawn a few at a time: one page per frame keeps scrolling smooth, and pages stay in memory a little beyond the screen
  E.queueRender = function (g, front) {
    if (g.q) { if (front && E._rq) { const i = E._rq.indexOf(g); if (i > 0) { E._rq.splice(i, 1); E._rq.unshift(g); } } return; }
    g.q = true; E._rq = E._rq || []; if (front) E._rq.unshift(g); else E._rq.push(g);
    if (!E._rqRaf) E._rqRaf = requestAnimationFrame(function pump() {
      E._rqRaf = 0; let g2; while ((g2 = E._rq.shift())) { g2.q = false; if (g2.vis && E.doc) { E.renderPage(g2); break; } }
      if (E._rq.length) E._rqRaf = requestAnimationFrame(pump);
    });
  };
  E.buildPages = function () {
    const st = E.inner; st.innerHTML = ''; E.pgs = []; E._rq = [];
    if (E.io) E.io.disconnect(); if (E.io2) E.io2.disconnect();
    E.io = new IntersectionObserver((entries) => {
      for (const en of entries) { const g = en.target._g; if (!g) continue; g.vis = en.isIntersecting; if (g.vis) E.queueRender(g); }
    }, { root: E.stage, rootMargin: '1500px 0px' });
    E.io2 = new IntersectionObserver((entries) => {
      for (const en of entries) { const g = en.target._g; if (g && !en.isIntersecting && !g.vis) E.freePage(g); }
    }, { root: E.stage, rootMargin: '2800px 0px' });
    E.doc.pages.forEach((p, i) => {
      const g = { idx: i, el: h('div', { class: 'pg' }), vis: false, k: 1 };
      g.el._g = g; g.pn = h('div', { class: 'pn' }, String(i + 1));
      g.el.append(g.pn); st.append(g.el); E.pgs.push(g);
    });
    E.layout();
    E.pgs.forEach((g) => { E.io.observe(g.el); E.io2.observe(g.el); });
    E.markBookmarks(); E.updInd();
  };
  E.layout = function () {
    const st = E.stage, avail = Math.max(300, st.clientWidth - 24);
    E.baseW = Math.min(avail, 1500);
    const w = E.baseW * E.zoom;
    E.pgs.forEach((g, i) => {
      const p = E.doc.pages[i], old = g.cssW;
      g.el.style.width = w + 'px'; g.el.style.height = (w * p.h / p.w) + 'px';
      if (old && g.base && old !== w) { // stretch the existing bitmap until the sharp redraw lands
        const f = w / old;
        [g.base, g.live].forEach((c) => { c.style.left = parseFloat(c.style.left || 0) * f + 'px'; c.style.top = parseFloat(c.style.top || 0) * f + 'px'; c.style.width = parseFloat(c.style.width) * f + 'px'; c.style.height = parseFloat(c.style.height) * f + 'px'; });
      }
      g.cssW = w;
    });
    E._sbm = null; E._offs = null;
    clearTimeout(E._lt); E._lt = setTimeout(() => E.renderVisible(), 70);
  };
  // After zoom or layout changes: redraw what is on screen first (one page per frame), drop far-away bitmaps instead of resizing them
  E.renderVisible = function () {
    const sr = E.stage.getBoundingClientRect(); let any = false;
    E.pgs.forEach((g) => {
      if (!g.vis) return;
      const r = g.el.getBoundingClientRect(), on = r.bottom > sr.top - 250 && r.top < sr.bottom + 250 && r.right > sr.left - 250 && r.left < sr.right + 250;
      if (on) { E.queueRender(g, true); any = true; } else if (g.base) E.freePage(g);
    });
    return any;
  };
  E.ensureRendered = function () { for (const g of E.pgs) if (g.vis && !g.base && !g.q) E.queueRender(g); };

  // Which part of a page gets a bitmap, and at what density. Big zoom levels only draw the visible window
  // (plus a margin) so text, images and PDF pages stay sharp however far you zoom in.
  const CAP = 9e6;
  E.region = function (g) {
    const p = E.doc.pages[g.idx], wCss = parseFloat(g.el.style.width) || g.el.clientWidth, hCss = wCss * p.h / p.w;
    const dev = Math.min(window.devicePixelRatio || 1, 2), dpr = S.settings.quality === 'sharp' ? dev : Math.min(dev, 1.5), full = wCss * hCss * dpr * dpr;
    if (full <= CAP) return { rx: 0, ry: 0, rw: wCss, rh: hCss, ppc: dpr, wCss, hCss, tiled: false };
    const sr = E.stage.getBoundingClientRect(), pr = g.el.getBoundingClientRect();
    const x0 = Math.max(0, sr.left - pr.left), y0 = Math.max(0, sr.top - pr.top), x1 = Math.min(wCss, sr.right - pr.left), y1 = Math.min(hCss, sr.bottom - pr.top);
    if (x1 - x0 < 2 || y1 - y0 < 2) return { rx: 0, ry: 0, rw: wCss, rh: hCss, ppc: dpr * Math.sqrt(CAP / full), wCss, hCss, tiled: false, low: true };
    let mx = (x1 - x0) * 0.25, my = (y1 - y0) * 0.25, rx, ry, rx2, ry2;
    const fit = () => { rx = Math.max(0, x0 - mx); ry = Math.max(0, y0 - my); rx2 = Math.min(wCss, x1 + mx); ry2 = Math.min(hCss, y1 + my); };
    fit(); while ((rx2 - rx) * (ry2 - ry) * dpr * dpr > CAP && mx > 1) { mx *= 0.5; my *= 0.5; fit(); }
    let ppc = dpr; const area = (rx2 - rx) * (ry2 - ry) * dpr * dpr; if (area > CAP) ppc = dpr * Math.sqrt(CAP / area);
    return { rx, ry, rw: rx2 - rx, rh: ry2 - ry, ppc, wCss, hCss, tiled: true };
  };
  E.renderPage = function (gi, skipId) {
    const g = typeof gi === 'number' ? E.pgs[gi] : gi; if (!g) return;
    const p = E.doc.pages[g.idx]; if (!p) return;
    const rg = E.region(g), ppc = rg.ppc;
    const cw = Math.max(1, Math.round(rg.rw * ppc)), ch = Math.max(1, Math.round(rg.rh * ppc));
    if (!g.base) {
      g.base = h('canvas'); g.live = h('canvas', { class: 'live' });
      g.el.insertBefore(g.base, g.el.firstChild); g.el.insertBefore(g.live, g.pn);
    }
    if (g.base.width !== cw || g.base.height !== ch) { g.base.width = g.live.width = cw; g.base.height = g.live.height = ch; }
    [g.base, g.live].forEach((c) => { c.style.left = rg.rx + 'px'; c.style.top = rg.ry + 'px'; c.style.width = cw / ppc + 'px'; c.style.height = ch / ppc + 'px'; });
    g.k = ppc * rg.wCss / p.w; g.offX = rg.rx * ppc; g.offY = rg.ry * ppc; g.rgn = rg; g.cssW = rg.wCss;
    const key = p.bg && p.bg.pdf ? [p.bg.pdf.id, p.bg.pdf.n, g.k.toFixed(4), Math.round(g.offX), Math.round(g.offY), cw, ch].join() : null;
    const tile = key && g.tile ? (g.tile.key === key ? g.tile : Object.assign({}, g.tile, { stale: true })) : null;
    R.drawPage(g.base.getContext('2d'), p, g.k, skipId, g.offX, g.offY, tile);
    if (skipId === undefined) E.drawOverlay(g);
    if (key && !tile && g.tileReq !== key && skipId === undefined) E.wantTile(g, p, key, cw, ch);
  };
  E.wantTile = function (g, p, key, cw, ch) {
    if (!IND.pdfr) return;
    if (g.task) g.task.cancel();
    g.tileReq = key; const k0 = g.k, ox0 = g.offX, oy0 = g.offY;
    g.task = IND.pdfr.render(E.doc.id, p.bg.pdf, g.k, g.offX, g.offY, cw, ch, p.w, (canvas) => {
      if (g.tileReq !== key || !g.base) return;
      g.tile = { key, canvas, lx: ox0 / k0, ly: oy0 / k0, lw: canvas.width / k0, lh: canvas.height / k0 }; g.tileReq = null; g.task = null;
      const pg = E.doc.pages[g.idx]; if (!pg) return;
      R.drawPage(g.base.getContext('2d'), pg, g.k, undefined, g.offX, g.offY, g.tile);
      if (!E.sel || E.sel.pi !== g.idx) return; E.drawOverlay(g);
    });
  };
  // after scrolling or zooming, redraw pages whose visible area left their bitmap
  E.refreshTiles = function () {
    E.ensureRendered();
    E.pgs.forEach((g) => {
      if (!g.vis || !g.base || !g.rgn) return;
      const nr = E.region(g), o = g.rgn;
      if (nr.tiled !== o.tiled || !!nr.low !== !!o.low || nr.ppc !== o.ppc || (nr.tiled && (Math.abs(nr.rx - o.rx) > 0.1 * nr.rw || Math.abs(nr.ry - o.ry) > 0.1 * nr.rh))) E.queueRender(g);
    });
  };
  E.freePage = function (g) {
    if (g.task) { g.task.cancel(); g.task = null; } g.tile = null; g.tileReq = null;
    if (!g.base) return;
    g.base.width = g.base.height = g.live.width = g.live.height = 0; g.base.remove(); g.live.remove(); g.base = g.live = null;
  };
  E.clearLive = function (g) { if (!g.live) return; const c = g.live.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, g.live.width, g.live.height); c.setTransform(g.k, 0, 0, g.k, -(g.offX || 0), -(g.offY || 0)); };
  E.liveCtx = function (g) { const c = g.live.getContext('2d'); c.setTransform(g.k, 0, 0, g.k, -(g.offX || 0), -(g.offY || 0)); return c; };
  E.page = (i) => E.doc.pages[i];
  E.setObjs = (i, objs) => { E.doc.pages[i] = Object.assign({}, E.doc.pages[i], { objs }); };
  E.markBookmarks = function () {
    E.pgs.forEach((g, i) => { const p = E.doc.pages[i]; const on = E.doc.bookmarks.includes(p.id); const ex = g.el.querySelector('.bm'); if (on && !ex) g.el.append(h('div', { class: 'bm' })); else if (!on && ex) ex.remove(); });
    const cur = E.doc.pages[E.curIdx]; E.bmBtn.classList.toggle('on', !!cur && E.doc.bookmarks.includes(cur.id));
  };
  E.toggleBookmark = function (i) {
    const p = E.doc.pages[i]; if (!p) return; const b = E.doc.bookmarks, k = b.indexOf(p.id);
    if (k >= 0) { b.splice(k, 1); U.toast('Bookmark removed'); } else { b.push(p.id); U.toast('Page ' + (i + 1) + ' bookmarked'); }
    E.markBookmarks(); E.dirty();
  };
  E.trackPage = function () {
    const st = E.stage; if (!E._offs || E._offs.length !== E.pgs.length) E._offs = E.pgs.map((g) => g.el.offsetTop);
    const y = st.scrollTop + (E._sbm ? E._sbm.view : st.clientHeight) * 0.4; let best = 0, o = E._offs;
    for (let i = 0; i < o.length; i++) { if (o[i] <= y) best = i; else break; }
    if (best !== E.curIdx) { E.curIdx = best; E.updInd(); E.markBookmarks(); }
    E.ensureRendered();
  };
  E.updInd = function () { E.indEl.textContent = (E.curIdx + 1) + '/' + E.doc.pages.length; E.zoomChip.textContent = Math.round(E.zoom * 100) + '%'; };

  // ---------------------------------------------------------------- overlay scrollbars
  E.updSb = function (show) {
    const st = E.stage; if (!st || !E.vsb) return;
    const place = (bar, vert) => {
      const m = E._sbm || (E._sbm = { view: st.clientHeight, vw: st.clientWidth, h: st.scrollHeight, w: st.scrollWidth, lv: E.vsb.clientHeight, lh: E.hsb.clientWidth });
      const view = vert ? m.view : m.vw, total = vert ? m.h : m.w, pos = vert ? st.scrollTop : st.scrollLeft;
      const need = total - view > 4; if (need !== bar._need) { bar.style.display = need ? '' : 'none'; bar._need = need; } if (!need) return;
      const len = vert ? m.lv : m.lh, th = Math.max(46, len * view / total), off = (len - th) * (pos / (total - view));
      const i = bar.firstChild; if (vert) { i.style.height = th + 'px'; i.style.transform = 'translateY(' + off + 'px)'; } else { i.style.width = th + 'px'; i.style.transform = 'translateX(' + off + 'px)'; }
    };
    place(E.vsb, true); place(E.hsb, false);
    if (show) { [E.vsb, E.hsb].forEach((b) => b.classList.add('show')); clearTimeout(E._sbt); E._sbt = setTimeout(() => { if (!E._sbDrag) [E.vsb, E.hsb].forEach((b) => b.classList.remove('show')); E.sbBub.classList.remove('show'); }, 1100); }
  };
  E.dragSb = function (bar, vert) {
    const st = E.stage;
    const move = (e) => {
      const r = bar.getBoundingClientRect(), len = vert ? r.height : r.width, view = vert ? st.clientHeight : st.clientWidth, total = vert ? st.scrollHeight : st.scrollWidth;
      const th = Math.max(46, len * view / total), f = U.clamp(((vert ? e.clientY - r.top : e.clientX - r.left) - th / 2) / Math.max(1, len - th), 0, 1);
      if (vert) st.scrollTop = f * (total - view); else st.scrollLeft = f * (total - view);
      if (vert) { E.sbBub.textContent = 'Page ' + (E.curIdx + 1) + ' / ' + E.doc.pages.length; E.sbBub.classList.add('show'); }
    };
    bar.addEventListener('pointerdown', (e) => { e.stopPropagation(); E._sbDrag = true; bar.classList.add('show', 'drag'); try { bar.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } move(e); });
    bar.addEventListener('pointermove', (e) => { if (E._sbDrag && bar.hasPointerCapture && bar.hasPointerCapture(e.pointerId)) move(e); });
    const end = () => { E._sbDrag = false; bar.classList.remove('drag'); E.updSb(true); };
    bar.addEventListener('pointerup', end); bar.addEventListener('pointercancel', end);
  };

  // ---------------------------------------------------------------- go to page popover
  E.gotoPop = function (btn) {
    const n = E.doc.pages.length, cur = E.doc.pages[E.curIdx];
    const inp = h('input', { type: 'number', min: 1, max: n, value: E.curIdx + 1, inputmode: 'numeric', class: 'gp-in' });
    const go = () => { const v = parseInt(inp.value, 10); if (!(v >= 1 && v <= n)) { U.toast('Enter a page from 1 to ' + n); return; } E.goTo(v - 1); U.closePop(); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    const jump = (i) => () => { E.goTo(i); U.closePop(); };
    const bm = E.doc.bookmarks.includes(cur.id);
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', minWidth: '250px' } },
      h('h4', null, 'Go to page'),
      h('div', { class: 'row' }, h('span', { class: 'lab', style: { flex: 'none' } }, 'Page (1–' + n + ')'), h('div', { class: 'grow' }), inp, h('button', { class: 'btn primary', onclick: go }, 'Go')),
      h('div', { class: 'gp-grid' },
        h('button', { class: 'btn', html: IND.icon('arrowup') + 'First', onclick: jump(0) }), h('button', { class: 'btn', html: IND.icon('arrowdown') + 'Last', onclick: jump(n - 1) }),
        h('button', { class: 'btn', html: IND.icon('left') + 'Previous', onclick: jump(E.curIdx - 1) }), h('button', { class: 'btn', html: IND.icon('right') + 'Next', onclick: jump(E.curIdx + 1) })),
      h('button', { class: 'btn' + (bm ? ' primary' : ''), html: IND.icon('bookmark') + (bm ? 'Remove bookmark' : 'Bookmark this page'), onclick: () => { E.toggleBookmark(E.curIdx); U.closePop(); } }),
      h('button', { class: 'btn', html: IND.icon('layers') + 'All pages', onclick: () => { U.closePop(); IND.panels.viewPages(); } }));
    U.openPop(btn, body, 'below'); setTimeout(() => { inp.focus(); inp.select(); }, 60);
  };
  E.goTo = function (i, instant) {
    i = U.clamp(i, 0, E.pgs.length - 1); const g = E.pgs[i]; if (!g) return;
    E.curIdx = i; E.updInd(); E.markBookmarks();
    E.stage.scrollTo({ top: g.el.offsetTop - 12, behavior: instant ? 'auto' : 'smooth' });
  };

  // ---------------------------------------------------------------- page operations
  E.insertIndex = (where) => where === 'before' ? E.curIdx : where === 'first' ? 0 : where === 'last' ? E.doc.pages.length : E.curIdx + 1;
  E.addPages = function (pages, where) {
    E.push(); const idx = E.insertIndex(where || S.settings.insertAt);
    E.doc.pages.splice(idx, 0, ...pages);
    E.buildPages(); E.goTo(idx, true); E.dirty();
  };
  E.deletePage = function (i) {
    if (E.doc.pages.length <= 1) { U.toast('A note needs at least one page'); return; }
    E.push(); const [p] = E.doc.pages.splice(i, 1); E.doc.bookmarks = E.doc.bookmarks.filter((x) => x !== p.id);
    E.curIdx = Math.min(E.curIdx, E.doc.pages.length - 1); E.buildPages(); E.dirty();
  };
  E.dupPage = function (i) {
    E.push(); const p = E.doc.pages[i];
    E.doc.pages.splice(i + 1, 0, Object.assign({}, p, { id: U.uid(), objs: p.objs.map((o) => Object.assign({}, o, { id: U.uid() })) }));
    E.buildPages(); E.dirty();
  };
  // move page i to position j (0-based); the open page and bookmarks follow their pages
  E.movePageTo = function (i, j) {
    const a = E.doc.pages; j = U.clamp(j, 0, a.length - 1); if (i === j || i < 0 || i >= a.length) return false;
    E.push(); const curId = a[E.curIdx] && a[E.curIdx].id; const [p] = a.splice(i, 1); a.splice(j, 0, p);
    E.curIdx = Math.max(0, a.findIndex((x) => x.id === curId)); E.sel = null; E.buildPages(); E.dirty(); return true;
  };
  E.movePage = (i, d) => E.movePageTo(i, i + d);
  // reorder several pages: ids move together (keeping their order) to start at position `to` of the remaining pages
  E.movePagesTo = function (ids, to) {
    const a = E.doc.pages, set = new Set(ids), moving = a.filter((p) => set.has(p.id)), rest = a.filter((p) => !set.has(p.id));
    if (!moving.length) return; E.push(); const curId = a[E.curIdx] && a[E.curIdx].id;
    rest.splice(U.clamp(to, 0, rest.length), 0, ...moving); E.doc.pages = rest;
    E.curIdx = Math.max(0, rest.findIndex((x) => x.id === curId)); E.sel = null; E.buildPages(); E.dirty();
  };
  E.setBg = function (i, kind) {
    const p = E.doc.pages[i]; if (!p || (p.bg && p.bg.kind === 'img')) { U.toast('Imported pages keep their original background'); return; }
    E.push(); E.doc.pages[i] = Object.assign({}, p, { bg: { kind } }); E.renderPage(i); E.dirty();
  };

  // ---------------------------------------------------------------- zoom
  E.setZoom = function (z, cx, cy) {
    z = U.clamp(z, 0.4, 6); if (Math.abs(z - E.zoom) < 0.001) return;
    const st = E.stage, r = st.getBoundingClientRect();
    cx = cx == null ? r.left + r.width / 2 : cx; cy = cy == null ? r.top + r.height / 2 : cy;
    const lx = cx - r.left, ly = cy - r.top;
    const ax = (st.scrollLeft + lx) / Math.max(1, st.scrollWidth), ay = (st.scrollTop + ly) / Math.max(1, st.scrollHeight);
    E.zoom = z; E.layout();
    st.scrollLeft = ax * st.scrollWidth - lx; st.scrollTop = ay * st.scrollHeight - ly;
    E._sbm = null; E.zoomEl && (E.zoomEl.textContent = Math.round(z * 100) + '%'); E.zoomChip && (E.zoomChip.textContent = Math.round(z * 100) + '%'); E.updSb(true);
    clearTimeout(E._rt); E._rt = setTimeout(E.refreshTiles, 160);
  };

  // animated zoom for buttons and presets: the pages glide (GPU) and are redrawn sharp at the end
  E.animZoom = function (z, cx, cy) {
    z = U.clamp(z, 0.4, 6); if (Math.abs(z - E.zoom) < 0.001) return;
    const r = E.stage.getBoundingClientRect(), inn = E.inner, ir = inn.getBoundingClientRect();
    cx = cx == null ? r.left + r.width / 2 : cx; cy = cy == null ? r.top + r.height / 2 : cy;
    clearTimeout(E._az); inn.style.transition = 'none'; inn.style.transform = ''; inn.style.transformOrigin = (cx - ir.left) + 'px ' + (cy - ir.top) + 'px'; inn.style.willChange = 'transform';
    const f = z / E.zoom; E.zoomChip.textContent = Math.round(z * 100) + '%';
    requestAnimationFrame(() => { inn.style.transition = 'transform 220ms cubic-bezier(.2,.8,.2,1)'; inn.style.transform = 'scale(' + f + ')'; });
    E._az = setTimeout(() => { inn.style.transition = ''; inn.style.transform = ''; inn.style.willChange = ''; inn.style.transformOrigin = ''; E.setZoom(z, cx, cy); }, 250);
  };

  // ---------------------------------------------------------------- history
  const snap = () => E.doc.pages.map((p) => Object.assign({}, p));
  E.push = function () { E.hist.push(snap()); if (E.hist.length > 100) E.hist.shift(); E.redoS = []; E.updUndo(); };
  E.restore = function (s) {
    const old = E.doc.pages, same = s.length === old.length && s.every((p, i) => p.id === old[i].id);
    E.doc.pages = s.map((p) => Object.assign({}, p)); E.sel = null; E.ctx.classList.remove('show');
    if (same) { s.forEach((p, i) => { const o = old[i]; if (p.objs !== o.objs || p.bg !== o.bg || p.w !== o.w || p.h !== o.h) { const g = E.pgs[i]; if (g && g.vis) E.renderPage(g); } }); }
    else { E.curIdx = Math.min(E.curIdx, E.doc.pages.length - 1); E.buildPages(); }
    E.dirty(); E.updUndo();
  };
  E.undo = function () { if (!E.hist.length) return; E.redoS.push(snap()); E.restore(E.hist.pop()); };
  E.redo = function () { if (!E.redoS.length) return; E.hist.push(snap()); E.restore(E.redoS.pop()); };
  E.updUndo = function () {
    document.querySelectorAll('[data-tool="undo"]').forEach((b) => b.classList.toggle('dis', !E.hist.length));
    document.querySelectorAll('[data-tool="redo"]').forEach((b) => b.classList.toggle('dis', !E.redoS.length));
  };

  // ---------------------------------------------------------------- saving
  E.save = async function () {
    if (!E.doc || !E._dirty) return;
    E._dirty = false; clearTimeout(E._st); E._st = 0;
    const d = E.doc; d.modified = Date.now(); d.lastPage = E.curIdx;
    try { d.thumb = R.thumb(d.pages[0], 240).toDataURL('image/jpeg', 0.65); } catch (e) { /* ignore */ }
    try { await S.saveDoc(d); E.savedAt = Date.now(); } catch (e) { U.toast('Could not save: ' + (e.message || e)); E._dirty = true; }
  };
  // changes are written to storage on the autosave timer (Settings: 30 s to 5 min); closing a note or leaving the app saves at once
  E.dirty = function () { E._dirty = true; if (!E._st) E._st = setTimeout(E.save, Math.max(5, S.settings.autosave || 30) * 1000); };

  // ---------------------------------------------------------------- selection overlay
  E.selObj = function () { if (!E.sel) return null; const p = E.doc.pages[E.sel.pi]; return p && p.objs.find((o) => o.id === E.sel.id) || null; };
  E.select = function (pi, id) { const old = E.sel; E.sel = id == null ? null : { pi, id }; if (old && old.pi !== pi && E.pgs[old.pi]) E.drawOverlay(E.pgs[old.pi]); if (E.pgs[pi]) E.drawOverlay(E.pgs[pi]); };
  E.drawOverlay = function (g, objOverride) {
    if (!g.live) return;
    if (!objOverride) E.updCtx();
    E.clearLive(g);
    if (!E.sel || E.sel.pi !== g.idx) return;
    const o = objOverride || E.selObj(); if (!o) return;
    const ctx = E.liveCtx(g), p = E.doc.pages[g.idx], u = (parseFloat(g.el.style.width) || g.el.clientWidth) / p.w;
    const b = R.bbox(o), pad = 4 / u;
    ctx.save(); ctx.lineWidth = 2 / u; ctx.setLineDash([8 / u, 6 / u]); ctx.strokeStyle = '#0a84ff';
    ctx.strokeRect(b.x - pad, b.y - pad, b.w + 2 * pad, b.h + 2 * pad); ctx.setLineDash([]);
    const dot = (x, y, col, glyph) => {
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, 15 / u, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.4 / u; ctx.lineCap = 'round'; ctx.beginPath();
      const s = 5.5 / u;
      if (glyph === 'x') { ctx.moveTo(x - s, y - s); ctx.lineTo(x + s, y + s); ctx.moveTo(x + s, y - s); ctx.lineTo(x - s, y + s); }
      else { ctx.moveTo(x - s, y - s); ctx.lineTo(x + s, y + s); ctx.moveTo(x + s, y + s); ctx.lineTo(x + s, y + s - 7 / u); ctx.moveTo(x + s, y + s); ctx.lineTo(x + s - 7 / u, y + s); ctx.moveTo(x - s, y - s); ctx.lineTo(x - s, y - s + 7 / u); ctx.moveTo(x - s, y - s); ctx.lineTo(x - s + 7 / u, y - s); }
      ctx.stroke();
    };
    dot(b.x - pad, b.y - pad, '#ff453a', 'x');
    dot(b.x + b.w + pad, b.y + b.h + pad, '#0a84ff', 'r');
    if (o.t === 'shape' && R.isLineShape(o.kind)) [[o.x1, o.y1], [o.x2, o.y2]].forEach(([x, y]) => { ctx.fillStyle = '#fff'; ctx.strokeStyle = '#0a84ff'; ctx.lineWidth = 3 / u; ctx.setLineDash([]); ctx.beginPath(); ctx.arc(x, y, 11 / u, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); });
    ctx.restore();
  };
  E.handles = function (g, o) { // logical coordinates of the selection handles
    const b = R.bbox(o), p = E.doc.pages[g.idx], u = (parseFloat(g.el.style.width) || g.el.clientWidth) / p.w, pad = 4 / u;
    const ep = o.t === 'shape' && R.isLineShape(o.kind) ? [[o.x1, o.y1], [o.x2, o.y2]] : null;
    return { del: [b.x - pad, b.y - pad], size: [b.x + b.w + pad, b.y + b.h + pad], r: 22 / u, b, ep };
  };
  // floating bar with the actions for the selected object (text box, shape, table, image, drawing)
  E.updCtx = function () {
    const o = E.selObj(), bar = E.ctx; if (!bar) return;
    if (!o || !E.sel || (IND.input && IND.input.editing)) { bar.classList.remove('show'); E._ctxKey = null; return; }
    const key = o.id + o.t; bar.classList.add('show'); if (E._ctxKey === key) return; E._ctxKey = key;
    bar.innerHTML = '';
    const T = IND.tools, b = (ic, label, fn, cls) => h('button', { class: 'cb ' + (cls || ''), 'aria-label': label, title: label, onclick: (e) => fn(e.currentTarget) }, h('span', { html: IND.icon(ic) }), h('small', null, label));
    if (o.t === 'text') bar.append(b('text', 'Text options', (a) => T.textOpts(a, E.selObj(), true)), b('pen', 'Edit text', () => IND.input.openText(E.sel.pi, E.selObj())));
    else if (o.t === 'shape') bar.append(b('shapes', 'Shape options', (a) => T.shapeOpts(a, E.selObj(), true)));
    else if (o.t === 'table') bar.append(b('table', 'Table options', (a) => T.tableOpts(E.selObj(), a, true)));
    else if (o.t === 'img') bar.append(b('image', 'Crop', () => IND.crop.open(E.selObj(), E.sel.pi)));
    bar.append(b('copy', 'Duplicate', () => E.dupSel()), b('arrowup', 'To front', () => E.orderSel(true)), b('arrowdown', 'To back', () => E.orderSel(false)), b('trash', 'Delete', () => E.deleteSel(), 'danger'));
  };
  E.deleteSel = function () {
    const o = E.selObj(); if (!o) return;
    E.push(); const pi = E.sel.pi; E.setObjs(pi, E.doc.pages[pi].objs.filter((x) => x.id !== o.id)); E.sel = null;
    E.renderPage(pi); E.dirty();
  };
  E.dupSel = function () {
    const o = E.selObj(); if (!o) return;
    E.push(); const pi = E.sel.pi, n = R.transform(o, 0, 0, 1, 1, 40, 40); n.id = U.uid();
    E.setObjs(pi, [...E.doc.pages[pi].objs, n]); E.sel = { pi, id: n.id }; E.renderPage(pi); E.dirty();
  };
  E.orderSel = function (front) {
    const o = E.selObj(); if (!o) return; E.push(); const pi = E.sel.pi, rest = E.doc.pages[pi].objs.filter((x) => x.id !== o.id);
    E.setObjs(pi, front ? [...rest, o] : [o, ...rest]); E.renderPage(pi); E.dirty();
  };
  E.updateObj = function (pi, id, patch, noPush) {
    const p = E.doc.pages[pi]; if (!p) return;
    if (!noPush) E.push();
    E.setObjs(pi, p.objs.map((o) => { if (o.id !== id) return o; const n = Object.assign({}, o, patch); if (n.t === 'text') R.measureText(n); if (n.t === 'table') R.fitTable(n); return n; }));
    E.renderPage(pi); E.dirty();
  };
})();
