// Sharp PDF pages at any zoom: the original PDF is kept and redrawn for the visible area on demand.
(function () {
  const S = IND.store;
  const P = (IND.pdfr = {});
  const docs = new Map();
  P.get = function (docId, id) {
    const key = docId + ':' + id;
    if (!docs.has(key)) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
      docs.set(key, S.getPdf(docId, id).then((buf) => { if (!buf) throw new Error('PDF data missing'); return pdfjsLib.getDocument({ data: new Uint8Array(buf.slice(0)) }).promise; }));
    }
    return docs.get(key);
  };
  P.forget = (docId) => { for (const k of [...docs.keys()]) if (k.startsWith(docId + ':')) docs.delete(k); };
  // k = canvas pixels per logical page unit; (ox, oy) = canvas pixel offset of the tile; pageW = logical page width
  P.render = function (docId, ref, k, ox, oy, cw, ch, pageW, cb) {
    let dead = false, task = null;
    (async () => {
      const pdf = await P.get(docId, ref.id); if (dead) return;
      const pg = await pdf.getPage(ref.n); if (dead) return;
      const v1 = pg.getViewport({ scale: 1 }), s = (k * pageW) / v1.width;
      const vp = pg.getViewport({ scale: s, offsetX: -ox, offsetY: -oy });
      const c = document.createElement('canvas'); c.width = cw; c.height = ch;
      const cx = c.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cw, ch);
      task = pg.render({ canvasContext: cx, viewport: vp });
      await task.promise; if (!dead) cb(c);
    })().catch(() => { /* cancelled or unavailable: the low-resolution preview stays */ });
    return { cancel() { dead = true; try { task && task.cancel(); } catch (e) { /* ignore */ } } };
  };
})();
