// Helpers: DOM builder, toast, popover, sheet, form controls, color picker, file saving.
(function () {
  const U = (IND.u = {});

  U.$ = (s, r) => (r || document).querySelector(s);
  U.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  U.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  U.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  // h('div', {class:'x', onclick:fn, html:'<b>'}, child, 'text')
  U.h = function (tag, attrs, ...kids) {
    const e = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'html') e.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
    return e;
  };
  const h = U.h;

  // ---- toast
  let tt;
  U.toast = (msg) => {
    const t = U.$('#toast'); t.textContent = msg; t.classList.add('on');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2200);
  };

  // ---- popover (anchored glass panel) ----
  const popLayer = () => U.$('#layer-pop');
  U.closePop = () => { popLayer().innerHTML = ''; IND.popOpen = false; if (U._onPopClose) { const f = U._onPopClose; U._onPopClose = null; f(); } };
  U.openPop = function (anchor, content, side, onClose) {
    U.closePop();
    const layer = popLayer();
    const scrim = h('div', { class: 'scrim', onpointerdown: () => U.closePop() });
    const pop = h('div', { class: 'pop glass glass-strong' }, content);
    layer.append(scrim, pop);
    IND.popOpen = true; U._onPopClose = onClose || null;
    const place = () => {
      const vw = innerWidth, vh = innerHeight, m = 10;
      const pw = pop.offsetWidth, ph = pop.offsetHeight;
      let x, y;
      if (anchor) {
        const r = anchor.getBoundingClientRect();
        side = side || 'below';
        if (side === 'right') { x = r.right + 12; y = r.top + r.height / 2 - ph / 2; }
        else if (side === 'left') { x = r.left - pw - 12; y = r.top + r.height / 2 - ph / 2; }
        else if (side === 'above') { x = r.left + r.width / 2 - pw / 2; y = r.top - ph - 12; }
        else { x = r.left + r.width / 2 - pw / 2; y = r.bottom + 12; }
      } else { x = (vw - pw) / 2; y = (vh - ph) / 2; }
      pop.style.left = U.clamp(x, m, Math.max(m, vw - pw - m)) + 'px';
      pop.style.top = U.clamp(y, m, Math.max(m, vh - ph - m)) + 'px';
    };
    place();
    return { el: pop, place };
  };

  // ---- sheet (modal glass dialog) ----
  U.closeSheet = () => { U.$('#layer-sheet').innerHTML = ''; IND.sheetOpen = false; };
  U.openSheet = function (title, body, opts) {
    opts = opts || {};
    U.closeSheet();
    const wrap = h('div', { class: 'sheet-wrap' + (opts.side ? ' side' : ''), onpointerdown: (e) => { if (e.target === wrap) U.closeSheet(); } });
    const head = h('div', { class: 'sheet-head' }, h('h3', null, title),
      opts.actions || null,
      h('button', { class: 'ibtn', html: IND.icon('x'), onclick: U.closeSheet, 'aria-label': 'Close' }));
    const sheet = h('div', { class: 'sheet glass glass-strong' + (opts.side ? ' left' : '') }, head, h('div', { class: 'sheet-body' }, body));
    wrap.append(sheet); U.$('#layer-sheet').append(wrap);
    IND.sheetOpen = true;
    return sheet;
  };
  U.confirm = function (title, text, okLabel, onOk, danger) {
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '16px' } },
      h('div', { style: { color: 'var(--ink-2)', lineHeight: 1.5 } }, text),
      h('div', { class: 'hstack', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn', onclick: U.closeSheet }, 'Cancel'),
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => { U.closeSheet(); onOk(); } }, okLabel)));
    const s = U.openSheet(title, body); s.style.width = 'min(440px,100%)';
  };
  U.prompt = function (title, value, okLabel, onOk) {
    const inp = h('input', { class: 'txt', value: value || '', id: 'prompt-in' });
    const go = () => { const v = inp.value.trim(); if (v) { U.closeSheet(); onOk(v); } };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    const s = U.openSheet(title, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px' } }, inp,
      h('div', { class: 'hstack', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn', onclick: U.closeSheet }, 'Cancel'),
        h('button', { class: 'btn primary', onclick: go }, okLabel))));
    s.style.width = 'min(460px,100%)';
    setTimeout(() => { inp.focus(); inp.select(); }, 60);
  };

  // ---- controls ----
  U.slider = function (label, min, max, step, value, onInput, fmt) {
    const val = h('span', null, fmt ? fmt(value) : value);
    const inp = h('input', { type: 'range', min, max, step, value });
    const fill = () => inp.style.setProperty('--pct', ((parseFloat(inp.value) - min) / (max - min) * 100) + '%');
    fill();
    inp.addEventListener('input', () => { const v = parseFloat(inp.value); fill(); val.textContent = fmt ? fmt(v) : v; onInput(v); });
    return h('div', { class: 'slider' }, h('div', { class: 'top' }, h('span', null, label), val), inp);
  };
  U.toggle = function (label, value, onChange) {
    const t = h('div', { class: 'tgl' + (value ? ' on' : '') });
    const row = h('button', { class: 'row', style: { width: '100%', textAlign: 'left' }, onclick: () => { value = !value; t.classList.toggle('on', value); onChange(value); } },
      h('span', { class: 'lab' }, label), t);
    return row;
  };
  U.segment = function (items, value, onChange) {
    const seg = h('div', { class: 'seg' });
    items.forEach(([v, lab, ic]) => {
      const b = h('button', { class: v === value ? 'on' : '', html: (ic ? IND.icon(ic) : '') + (lab ? '<span>' + lab + '</span>' : ''), onclick: () => {
        [...seg.children].forEach((c) => c.classList.remove('on')); b.classList.add('on'); onChange(v);
      } });
      seg.append(b);
    });
    return seg;
  };
  U.optGrid = function (items, value, onChange) {
    const g = h('div', { class: 'opts' });
    items.forEach(([v, lab, ic]) => {
      const b = h('button', { class: 'opt' + (v === value ? ' on' : ''), html: (ic ? IND.icon(ic) : '') + '<span>' + lab + '</span>', onclick: () => {
        [...g.children].forEach((c) => c.classList.remove('on')); b.classList.add('on'); onChange(v);
      } });
      g.append(b);
    });
    return g;
  };
  U.stepper = function (label, value, min, max, onChange) {
    const n = h('span', null, value);
    const set = (d) => { value = U.clamp(value + d, min, max); n.textContent = value; onChange(value); };
    return h('div', { class: 'row' }, h('span', { class: 'lab' }, label),
      h('div', { class: 'stepper' }, h('button', { onclick: () => set(-1) }, '−'), n, h('button', { onclick: () => set(1) }, '+')));
  };

  // ---- color ----
  U.PALETTE = ['#111827', '#e11d48', '#f97316', '#eab308', '#16a34a', '#0a84ff', '#7c3aed'];
  U.hsl2hex = function (h_, s, l) {
    s /= 100; l /= 100;
    const k = (n) => (n + h_ / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    const x = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
    return '#' + x(f(0)) + x(f(8)) + x(f(4));
  };
  U.hex2hsl = function (hex) {
    let r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let hh = 0, s = 0;
    if (mx !== mn) {
      const d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60;
    }
    return [Math.round(hh), Math.round(s * 100), Math.round(l * 100)];
  };
  // swatches + spectrum row. getter/setter pattern: onChange(hex)
  // colour picker row: editable palette (add / reorder / remove) plus a colour wheel with brightness
  const hsv2rgb = (hh, ss, vv) => { const f = (n) => { const k = (n + hh / 60) % 6; return vv - vv * ss * Math.max(0, Math.min(k, 4 - k, 1)); }; return [f(5), f(3), f(1)].map((x) => Math.round(x * 255)); };
  const rgb2hex = (r) => '#' + r.map((x) => x.toString(16).padStart(2, '0')).join('');
  const hex2hsv = (hex) => { const n = parseInt(hex.slice(1), 16), r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let hh = 0; if (d) hh = mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return [hh * 60, mx ? d / mx : 0, mx]; };
  U.colorRow = function (current, onChange, key) {
    const S = IND.store, st = S.settings; key = key || 'palette';
    const defs = key === 'hlPalette' ? ['#facc15', '#fb7185', '#4ade80', '#38bdf8', '#c084fc', '#fb923c'] : U.PALETTE;
    const list = () => (st[key] && st[key].length ? st[key] : (st[key] = defs.slice()));
    const save = () => S.saveSettings();
    let cur = /^#[0-9a-f]{6}$/i.test(current) ? current.toLowerCase() : null, editing = false, sel = null, [hh, ss, vv] = hex2hsv(cur || '#0a84ff');
    const wrap = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } });
    const row = h('div', { class: 'swatches' }), tools = h('div', { class: 'pal-tools' }), wheelBox = h('div', { class: 'wheel-box', style: { display: 'none' } });
    const pick = (c) => { cur = c; [hh, ss, vv] = hex2hsv(c); onChange(c); draw(); drawWheel(); };
    function draw() {
      row.innerHTML = '';
      list().forEach((c) => row.append(h('button', { class: 'swatch' + (c === cur ? ' on' : '') + (editing && c === sel ? ' sel' : ''), style: { background: c }, 'aria-label': c, onclick: () => { if (editing) { sel = c; draw(); drawTools(); } else pick(c); } })));
      row.append(h('button', { class: 'swatch spec' + (wheelBox.style.display !== 'none' ? ' on' : ''), 'aria-label': 'Colour wheel', onclick: () => { wheelBox.style.display = wheelBox.style.display === 'none' ? 'flex' : 'none'; drawWheel(); draw(); } }));
      drawTools();
    }
    function drawTools() {
      tools.innerHTML = '';
      const L = list(), i = L.indexOf(sel);
      tools.append(h('button', { class: 'chip' + (editing ? ' on' : ''), onclick: () => { editing = !editing; sel = editing ? cur : null; draw(); } }, editing ? 'Done' : 'Edit colours'));
      if (editing) {
        const mv = (d) => () => { const j = i + d; if (i < 0 || j < 0 || j >= L.length) return; [L[i], L[j]] = [L[j], L[i]]; save(); draw(); };
        tools.append(h('button', { class: 'chip', html: IND.icon('left') + 'Move', onclick: mv(-1) }), h('button', { class: 'chip', html: 'Move' + IND.icon('right'), onclick: mv(1) }),
          h('button', { class: 'chip', style: { color: 'var(--danger)' }, html: IND.icon('trash') + 'Remove', onclick: () => { if (i < 0 || L.length <= 1) return; L.splice(i, 1); sel = L[Math.min(i, L.length - 1)]; save(); draw(); } }),
          h('button', { class: 'chip', onclick: () => { st[key] = defs.slice(); sel = null; save(); draw(); } }, 'Reset'));
      }
    }
    // wheel
    const cv = h('canvas', { width: 180, height: 180, class: 'wheel' }), dot = h('i', { class: 'wheel-dot' });
    const wrapCv = h('div', { class: 'wheel-wrap' }, cv, dot), hex = h('b', { class: 'hexv' });
    const bri = h('input', { type: 'range', min: 5, max: 100, value: Math.round(vv * 100), class: 'bri' });
    function drawWheel() {
      if (wheelBox.style.display === 'none') return;
      const x = cv.getContext('2d'), N = 180, img = x.createImageData(N, N), R = N / 2;
      for (let y = 0; y < N; y++) for (let xx = 0; xx < N; xx++) {
        const dx = xx - R + 0.5, dy = y - R + 0.5, d = Math.hypot(dx, dy), o = (y * N + xx) * 4;
        if (d > R) { img.data[o + 3] = 0; continue; }
        const rgb = hsv2rgb((Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360, d / R, vv);
        img.data[o] = rgb[0]; img.data[o + 1] = rgb[1]; img.data[o + 2] = rgb[2]; img.data[o + 3] = 255;
      }
      x.putImageData(img, 0, 0);
      const a = hh * Math.PI / 180; dot.style.left = (R + Math.cos(a) * ss * R) / N * 100 + '%'; dot.style.top = (R + Math.sin(a) * ss * R) / N * 100 + '%';
      const c = rgb2hex(hsv2rgb(hh, ss, vv)); dot.style.background = c; hex.textContent = c.toUpperCase(); bri.value = Math.round(vv * 100);
    }
    const fromPt = (e) => {
      const r = cv.getBoundingClientRect(), R = r.width / 2, dx = e.clientX - r.left - R, dy = e.clientY - r.top - R;
      hh = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360; ss = Math.min(1, Math.hypot(dx, dy) / R); apply();
    };
    const apply = () => { cur = rgb2hex(hsv2rgb(hh, ss, vv)); onChange(cur); drawWheel(); row.querySelectorAll('.swatch:not(.spec)').forEach((b) => b.classList.toggle('on', b.style.backgroundColor && rgb2hex(b.style.backgroundColor.match(/\d+/g).map(Number)) === cur)); };
    let down = false;
    wrapCv.addEventListener('pointerdown', (e) => { down = true; try { wrapCv.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } fromPt(e); });
    wrapCv.addEventListener('pointermove', (e) => { if (down) fromPt(e); });
    wrapCv.addEventListener('pointerup', () => { down = false; }); wrapCv.addEventListener('pointercancel', () => { down = false; });
    bri.addEventListener('input', () => { vv = bri.value / 100; apply(); });
    wheelBox.append(wrapCv, h('div', { style: { flex: 1, display: 'flex', flexDirection: 'column', gap: '10px', justifyContent: 'center' } }, hex, h('div', { class: 'tiny' }, 'Brightness'), bri,
      h('button', { class: 'btn', html: IND.icon('plus') + 'Add to my colours', onclick: () => { const c = rgb2hex(hsv2rgb(hh, ss, vv)), L = list(); if (!L.includes(c)) { L.push(c); save(); } cur = c; draw(); U.toast('Colour added'); } })));
    draw(); wrap.append(row, tools, wheelBox);
    return wrap;
  };

  // ---- misc ----
  U.fmtDate = (ts) => {
    const d = new Date(ts), now = new Date();
    const same = d.toDateString() === now.toDateString();
    return same ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString([], { day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  };
  U.loadImage = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
  U.fileToDataURL = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
  U.fileToBuffer = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsArrayBuffer(f); });
  U.pickFile = (id, cb) => {
    const el = U.$('#' + id); el.value = '';
    el.onchange = () => { const files = [...el.files]; if (files.length) cb(files); };
    el.click();
  };
  U.progress = function (title) {
    const bar = h('i'); const msg = h('div', { style: { color: 'var(--ink-2)', fontSize: '14px' } }, 'Working…');
    const s = U.openSheet(title, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, msg, h('div', { class: 'prog' }, bar)));
    s.style.width = 'min(420px,100%)';
    return { set: (f, t) => { bar.style.width = Math.round(f * 100) + '%'; if (t) msg.textContent = t; }, done: U.closeSheet };
  };

  // Save / share a file. Uses native share sheet inside the Android app, a normal download in a browser.
  // mode 'choose' (default): Android's "Save as" dialog, so the person picks the folder; 'share': the share sheet.
  U.saveFile = async function (name, blob, mode) {
    const cap = window.Capacitor, P = cap && cap.Plugins;
    if (cap && cap.isNativePlatform && cap.isNativePlatform() && P && P.Filesystem) {
      const b64 = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(blob); });
      const w = await P.Filesystem.writeFile({ path: name, data: b64, directory: 'CACHE' });
      if (mode !== 'share') {
        try {
          const SF = cap.registerPlugin ? cap.registerPlugin('SaveFile') : P.SaveFile;
          await SF.save({ name, mime: blob.type || 'application/octet-stream', uri: w.uri });
          U.toast('Saved ' + name); return true;
        } catch (e) { if (String((e && e.message) || e).includes('cancel')) { U.toast('Save cancelled'); return false; } /* plugin missing: fall back to sharing */ }
      }
      if (P.Share) { await P.Share.share({ title: name, url: w.uri, dialogTitle: 'Save or share ' + name }); return true; }
      return false;
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000); return true;
  };
})();
