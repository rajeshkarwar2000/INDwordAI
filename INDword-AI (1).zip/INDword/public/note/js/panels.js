// Panels: pages sheet (thumbnails / bookmarks / outline), import, export, switch note, settings.
(function () {
  const U = IND.u, h = U.h, S = IND.store, R = IND.render, I = IND.imp;
  const P = (IND.panels = {});
  const E = () => IND.editor;
  const col = (...k) => h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } }, ...k);
  const item = (ic, title, sub, fn) => h('button', { class: 'list-item', onclick: fn }, h('span', { html: IND.icon(ic) }), h('span', { class: 'grow' }, title, sub ? h('small', null, sub) : null));
  const side = (btn) => (btn ? IND.tools.side(btn) : undefined);

  // ------------------------------------------------------------ run an import (works from home and from the editor)
  P.runImport = async function (kind, files, target) {
    const pr = U.progress('Importing');
    try {
      let res;
      if (kind === 'pdf') res = await I.pdf(files[0], pr.set);
      else if (kind === 'img') res = await I.images(files, pr.set);
      else res = await I.more(files[0], pr.set);
      pr.done();
      if (target === 'new') {
        const doc = { id: U.uid(), name: res.name || 'Untitled', created: Date.now(), modified: Date.now(), fav: false, pages: res.pages, bookmarks: [], outline: res.outline || [], pdfs: res.pdfId ? [res.pdfId] : [] };
        await S.saveDoc(doc); if (res.pdfBuf) await S.putPdf(doc.id, res.pdfId, res.pdfBuf); const d = await S.getDoc(doc.id); IND.editor.open(d);
      } else {
        const ed = E(); if (res.pdfBuf) { await S.putPdf(ed.doc.id, res.pdfId, res.pdfBuf); ed.doc.pdfs = (ed.doc.pdfs || []).concat(res.pdfId); }
        if (res.outline && res.outline.length) { const off = ed.insertIndex(S.settings.insertAt); ed.doc.outline = (ed.doc.outline || []).concat(res.outline.map((o) => Object.assign({}, o, { page: o.page == null ? null : o.page + off }))); }
        ed.addPages(res.pages); U.toast(res.pages.length + (res.pages.length === 1 ? ' page added' : ' pages added'));
      }
    } catch (err) { pr.done(); U.toast(err.message || 'Import failed'); console.error(err); }
  };
  P.pickImport = function (kind, target) {
    const id = kind === 'pdf' ? 'f-pdf' : kind === 'cam' ? 'f-cam' : kind === 'img' ? 'f-img' : 'f-more';
    U.pickFile(id, (files) => P.runImport(kind === 'cam' ? 'img' : kind, files, target));
  };

  P.importMenu = function (btn) {
    const where = col(h('h4', null, 'Insert new pages'),
      U.segment([['after', 'After this'], ['before', 'Before'], ['first', 'At start'], ['last', 'At end']], S.settings.insertAt, (v) => { S.settings.insertAt = v; S.saveSettings(); }));
    const go = (k) => () => { U.closePop(); P.pickImport(k, 'here'); };
    const body = col(h('h4', null, 'Add to this note'), where,
      item('file', 'PDF', 'Each page becomes a page you can write on', go('pdf')),
      item('image', 'Images', 'One page per picture', go('img')),
      item('camera', 'Camera', 'Photograph a page or board', go('cam')),
      item('file', 'Word, PowerPoint, text', '.docx  .pptx  .txt', go('more')),
      item('pageplus', 'Blank page', null, () => { U.closePop(); E().addPages([I.blankPage('blank')]); }),
      item('pageplus', 'Ruled / grid / dotted page', null, () => { U.closePop(); P.pageView(btn); }));
    U.openPop(btn, body, side(btn));
  };

  // ------------------------------------------------------------ page view (current page templates)
  P.pageView = function (btn) {
    const ed = E(), p = ed.doc.pages[ed.curIdx], isImg = p.bg && p.bg.kind === 'img';
    const add = (kind) => () => { U.closePop(); ed.addPages([I.blankPage(kind)]); };
    const body = col(h('h4', null, 'Page ' + (ed.curIdx + 1) + ' background'),
      isImg ? h('div', { style: { color: 'var(--ink-2)', fontSize: '13.5px' } }, 'This page is imported, so its background stays as it is.') :
        U.optGrid([['blank', 'Blank', 'file'], ['ruled', 'Ruled', 'list'], ['grid', 'Grid', 'table'], ['dots', 'Dotted', 'grid']], p.bg.kind, (v) => { ed.setBg(ed.curIdx, v); }),
      h('h4', null, 'New page'),
      h('div', { class: 'row' }, h('button', { class: 'btn grow', onclick: add('blank') }, 'Blank'), h('button', { class: 'btn grow', onclick: add('ruled') }, 'Ruled'), h('button', { class: 'btn grow', onclick: add('grid') }, 'Grid'), h('button', { class: 'btn grow', onclick: add('dots') }, 'Dots')),
      h('div', { class: 'row' }, h('button', { class: 'btn grow', onclick: () => { U.closePop(); ed.dupPage(ed.curIdx); } }, 'Duplicate page'), h('button', { class: 'btn danger grow', onclick: () => { U.closePop(); ed.deletePage(ed.curIdx); } }, 'Delete page')));
    U.openPop(btn, body, side(btn));
  };

  // ------------------------------------------------------------ pages sheet
  P.viewPages = function (tab, select) {
    const ed = E(); tab = tab || 'thumbs'; let selMode = !!select; const picked = new Set();
    const holder = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } });
    const tabs = U.segment([['thumbs', 'Pages', 'layers'], ['marks', 'Bookmarks', 'bookmark'], ['outline', 'Outline', 'outline']], tab, (v) => { tab = v; draw(); });
    function draw() {
      holder.innerHTML = '';
      if (tab === 'thumbs') {
        const n = ed.doc.pages.length;
        const bar = h('div', { class: 'row', style: { gap: '8px', flexWrap: 'wrap' } },
          h('button', { class: 'chip' + (selMode ? ' on' : ''), html: IND.icon('check') + (selMode ? 'Selecting' : 'Select pages'), onclick: () => { selMode = !selMode; picked.clear(); draw(); } }),
          h('button', { class: 'chip', html: IND.icon('pageplus') + 'Add blank', onclick: () => { ed.addPages([I.blankPage('blank')]); draw(); } }),
          h('div', { class: 'grow' }), h('small', { style: { color: 'var(--ink-2)' } }, selMode ? picked.size + ' selected' : 'Hold a page and drag to reorder'));
        const grid = h('div', { class: 'thumbs pgrid' });
        ed.doc.pages.forEach((pg, i) => {
          const c = R.thumb(pg, 220);
          const t = h('div', { class: 't' + (i === ed.curIdx ? ' cur' : '') + (picked.has(pg.id) ? ' picked' : '') }, c, h('div', { class: 'n' }, String(i + 1)),
            ed.doc.bookmarks.includes(pg.id) ? h('div', { class: 'star', html: IND.icon('bookmark') }) : null,
            selMode ? h('div', { class: 'chk', html: picked.has(pg.id) ? IND.icon('check') : '' }) : null);
          const btn = (ic, label, fn, cls) => h('button', { class: 'pa ' + (cls || ''), html: IND.icon(ic), 'aria-label': label, title: label, onclick: (e) => { e.stopPropagation(); fn(); } });
          const acts = selMode ? null : h('div', { class: 'pacts' },
            btn('bookmark', 'Bookmark', () => { ed.toggleBookmark(i); draw(); }),
            btn('left', 'Move earlier', () => { ed.movePage(i, -1); draw(); }),
            btn('right', 'Move later', () => { ed.movePage(i, 1); draw(); }),
            btn('copy', 'Duplicate', () => { ed.dupPage(i); draw(); }),
            btn('trash', 'Delete', () => { ed.deletePage(i); draw(); }, 'danger'));
          const card = h('div', { class: 'pcard', 'data-i': i }, t, acts);
          // tap opens (or toggles selection); press and hold then drag reorders
          let timer = 0, drag = null, sx = 0, sy = 0;
          const endDrag = (commit, e) => {
            clearTimeout(timer);
            if (!drag) return;
            const d = drag; drag = null; d.ghost.remove(); card.classList.remove('lifting'); grid.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'));
            if (commit && d.to != null && d.to !== i) {
              const ids = selMode && picked.has(pg.id) && picked.size > 1 ? [...picked] : null;
              if (ids) ed.movePagesTo(ids, d.to - ids.filter((id) => ed.doc.pages.findIndex((p) => p.id === id) < d.to).length); else ed.movePageTo(i, d.to);
              draw();
            }
          };
          t.addEventListener('pointerdown', (e) => {
            sx = e.clientX; sy = e.clientY; t.setPointerCapture && t.setPointerCapture(e.pointerId);
            timer = setTimeout(() => {
              const r = card.getBoundingClientRect(), ghost = card.cloneNode(true); ghost.classList.add('ghost'); ghost.style.width = r.width + 'px'; ghost.style.left = r.left + 'px'; ghost.style.top = r.top + 'px';
              document.body.append(ghost); card.classList.add('lifting'); drag = { ghost, ox: sx - r.left, oy: sy - r.top, to: null }; if (navigator.vibrate) navigator.vibrate(12);
            }, 280);
          });
          t.addEventListener('pointermove', (e) => {
            if (!drag) { if (Math.hypot(e.clientX - sx, e.clientY - sy) > 10) clearTimeout(timer); return; }
            e.preventDefault(); drag.ghost.style.left = e.clientX - drag.ox + 'px'; drag.ghost.style.top = e.clientY - drag.oy + 'px';
            const el = document.elementFromPoint(e.clientX, e.clientY), tgt = el && el.closest && el.closest('.pcard');
            grid.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'));
            if (tgt && tgt !== card) { tgt.classList.add('drop'); drag.to = +tgt.dataset.i; } else drag.to = null;
            const sh = grid.closest('.sheet-body, .sheet') || grid.parentNode, sr = sh.getBoundingClientRect();
            if (e.clientY < sr.top + 70) sh.scrollTop -= 14; else if (e.clientY > sr.bottom - 70) sh.scrollTop += 14;
          });
          t.addEventListener('pointerup', (e) => {
            if (drag) { endDrag(true, e); return; } clearTimeout(timer);
            if (Math.hypot(e.clientX - sx, e.clientY - sy) > 10) return;
            if (selMode) { if (picked.has(pg.id)) picked.delete(pg.id); else picked.add(pg.id); draw(); } else { U.closeSheet(); ed.goTo(i, true); }
          });
          t.addEventListener('pointercancel', (e) => endDrag(false, e));
          t.style.touchAction = 'pan-y';
          grid.append(card);
        });
        const holderKids = [bar, grid];
        if (selMode) {
          const ids = () => ed.doc.pages.map((p, i) => (picked.has(p.id) ? i : -1)).filter((i) => i >= 0);
          holderKids.push(h('div', { class: 'selbar glass' },
            h('button', { class: 'btn', onclick: () => { ed.doc.pages.forEach((p) => picked.add(p.id)); draw(); } }, 'All'),
            h('button', { class: 'btn', onclick: () => { picked.clear(); draw(); } }, 'None'),
            h('button', { class: 'btn primary', html: IND.icon('export') + 'Save PDF', onclick: () => { if (!picked.size) return U.toast('Select pages first'); P.exportPages(ids()); } }),
            h('button', { class: 'btn', html: IND.icon('copy') + 'Duplicate', onclick: () => { ids().reverse().forEach((i) => ed.dupPage(i)); picked.clear(); draw(); } }),
            h('button', { class: 'btn danger', html: IND.icon('trash') + 'Delete', onclick: () => { const k = ids(); if (!k.length) return; if (k.length >= n) return U.toast('A note needs at least one page'); U.confirm('Delete pages', 'Delete ' + k.length + ' page' + (k.length > 1 ? 's' : '') + '?', 'Delete', () => { k.reverse().forEach((i) => ed.deletePage(i)); picked.clear(); draw(); }, true); } })));
        }
        holder.append(...holderKids);
      } else if (tab === 'marks') {
        const ids = ed.doc.bookmarks, rows = [];
        ed.doc.pages.forEach((pg, i) => { if (ids.includes(pg.id)) rows.push(item('bookmark', 'Page ' + (i + 1), null, () => { U.closeSheet(); ed.goTo(i); })); });
        holder.append(rows.length ? col(...rows) : h('div', { class: 'empty', style: { margin: '30px auto' } }, 'No bookmarks yet. Tap the bookmark button in the top bar to mark a page.'));
      } else {
        const ol = ed.doc.outline || [];
        holder.append(ol.length ? col(...ol.map((o) => h('button', { class: 'list-item', style: { paddingLeft: 12 + o.level * 18 + 'px', opacity: o.page == null ? 0.5 : 1 }, onclick: () => { if (o.page != null) { U.closeSheet(); ed.goTo(o.page); } } },
          h('span', { class: 'grow' }, o.title), o.page != null ? h('small', null, 'p. ' + (o.page + 1)) : null)))
          : h('div', { class: 'empty', style: { margin: '30px auto' } }, 'This note has no outline. PDFs with a table of contents show it here.'));
      }
    }
    draw();
    U.openSheet('Pages', col(tabs, holder), { side: true });
  };

  // ------------------------------------------------------------ switch note
  P.switchNote = async function (btn) {
    const metas = (await S.listMeta()).sort((a, b) => b.modified - a.modified);
    const cur = E().doc.id;
    const rows = metas.filter((m) => m.id !== cur).slice(0, 8).map((m) => item('file', m.name, U.fmtDate(m.modified) + ' · ' + m.pageCount + ' pages', () => { U.closePop(); E().switchTo(m.id); }));
    U.openPop(btn, col(h('h4', null, 'Open another note'), ...(rows.length ? rows : [h('div', { style: { color: 'var(--ink-2)' } }, 'No other notes yet.')]),
      item('home', 'All notes', null, () => { U.closePop(); E().close(); })), side(btn));
  };

  // ------------------------------------------------------------ images
  P.imageMenu = function (btn) {
    const go = (id) => () => { U.closePop(); U.pickFile(id, async (files) => {
      try {
        const ed = E(), pi = ed.curIdx;
        for (const f of files) {
          const r = await I.fitImage(f, 9000), pg = ed.doc.pages[pi], w = Math.min(pg.w * 0.6, r.w), hh = w * r.h / r.w;
          const st = ed.stage, g = ed.pgs[pi], u = g.el.clientWidth / pg.w, vis = (st.scrollTop + st.clientHeight / 2 - g.el.offsetTop) / u;
          const o = { id: U.uid(), t: 'img', x: (pg.w - w) / 2, y: U.clamp(vis - hh / 2, 20, Math.max(20, pg.h - hh - 20)), w, h: hh, src: r.src };
          await U.loadImage(r.src); IND.input.insertObject(o, pi); if (IND.crop) await IND.crop.open(o, pi, true);
        }
      } catch (err) { U.toast('Could not add image'); }
    }); };
    U.openPop(btn, col(h('h4', null, 'Add image'), item('image', 'Photo library', null, go('f-img')), item('camera', 'Take photo', null, go('f-cam'))), side(btn));
  };

  // ------------------------------------------------------------ export
  P.exportPages = async function (idx) {
    const ed = E(); await ed.save(); const pr = U.progress('Exporting ' + idx.length + ' page' + (idx.length > 1 ? 's' : ''));
    try { const blob = await I.exportPdf(ed.doc, pr.set, idx); pr.done(); await U.saveFile(I.safeName(ed.doc.name) + '-pages.pdf', blob); } catch (e) { pr.done(); U.toast('Export failed'); console.error(e); }
  };
  P.exportMenu = function (btn) {
    const ed = E();
    const pdf = (mode) => async () => {
      U.closePop(); await ed.save(); const pr = U.progress('Exporting PDF');
      try { const blob = await I.exportPdf(ed.doc, pr.set); pr.done(); await U.saveFile(I.safeName(ed.doc.name) + '.pdf', blob, mode); } catch (e) { pr.done(); U.toast('Export failed'); console.error(e); }
    };
    const body = col(h('h4', null, 'Export'),
      item('file', 'Save PDF…', 'Choose the folder on your tablet', pdf('choose')),
      item('export', 'Share PDF', 'Send through another app', pdf('share')),
      item('layers', 'Save selected pages…', 'Pick pages, then save them as a PDF', () => { U.closePop(); P.viewPages('thumbs', true); }),
      item('import', 'INDnote backup…', 'Keeps everything editable', async () => { U.closePop(); await ed.save(); await U.saveFile(I.safeName(ed.doc.name) + '.indnote', await I.backupBlob(ed.doc), 'choose'); }));
    U.openPop(btn, body, side(btn));
  };

  // ------------------------------------------------------------ glass style picker
  P.glassSection = function () {
    const st = S.settings, names = { frosted: 'Frosted', crystal: 'Crystal', liquid: 'Liquid', matte: 'Matte', aurora: 'Aurora', tint: 'Tint' };
    const grid = h('div', { class: 'opts', style: { gridTemplateColumns: 'repeat(3,1fr)' } });
    Object.keys(names).forEach((k) => grid.append(h('button', { class: 'glass-opt' + (st.glass === k ? ' on' : ''), 'data-g': k, onclick: () => {
      st.glass = k; S.saveSettings(); S.applyGlass(); [...grid.children].forEach((b) => b.classList.toggle('on', b.dataset.g === k));
    } }, h('i', null, h('b', { class: 'glass', 'data-gp': k })), names[k])));
    const cur = () => getComputedStyle(document.documentElement);
    const blur = U.slider('Blur', 0, 60, 1, st.glassBlur == null ? parseInt(cur().getPropertyValue('--blur-px')) || 28 : st.glassBlur, (v) => { st.glassBlur = v; S.saveSettings(); S.applyGlass(); }, (v) => v + ' px');
    const alpha = U.slider('Transparency', 5, 95, 1, Math.round((st.glassAlpha == null ? parseFloat(cur().getPropertyValue('--g-a')) || 0.55 : st.glassAlpha) * 100), (v) => { st.glassAlpha = v / 100; S.saveSettings(); S.applyGlass(); }, (v) => v + '% opaque');
    return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, h('h4', null, 'Glass style'), grid, blur, alpha,
      h('button', { class: 'btn', onclick: () => { st.glassBlur = null; st.glassAlpha = null; S.saveSettings(); S.applyGlass(); U.toast('Glass reset to the style defaults'); } }, 'Reset blur and transparency'));
  };

  // ------------------------------------------------------------ settings
  P.settings = function (btn) {
    const ed = E(); const inNote = !!ed.doc, names = { pages: 'Pages', view: 'Page view', import: 'Import', switch: 'Switch note', move: 'Move toolbar', undo: 'Undo', redo: 'Redo', mode: 'Stylus / finger', pen: 'Pen', brush: 'Brush', laser: 'Laser', highlighter: 'Highlighter', eraser: 'Eraser', select: 'Select', shapes: 'Shapes', text: 'Text', table: 'Table', image: 'Image', zoom: 'Zoom' };
    const order = col();
    const drawOrder = () => {
      order.innerHTML = '';
      S.settings.toolOrder.forEach((id, i) => {
        const hid = S.settings.hidden.includes(id);
        order.append(h('div', { class: 'tool-reorder' }, h('span', { html: IND.icon(IND.tools.defs[id][0]), style: { opacity: hid ? 0.35 : 1 } }), h('span', { class: 'nm', style: { opacity: hid ? 0.4 : 1 } }, names[id]),
          h('button', { class: 'ibtn', style: { width: '36px', height: '36px' }, html: IND.icon('arrowup'), onclick: () => mv(i, -1) }),
          h('button', { class: 'ibtn', style: { width: '36px', height: '36px' }, html: IND.icon('arrowdown'), onclick: () => mv(i, 1) }),
          id === 'move' ? h('span', { style: { width: '36px' } }) : h('button', { class: 'ibtn' + (hid ? '' : ' on'), style: { width: '36px', height: '36px' }, html: IND.icon('check'), onclick: () => { const a = S.settings.hidden, k = a.indexOf(id); if (k >= 0) a.splice(k, 1); else a.push(id); S.saveSettings(); IND.tools.renderToolbar(); drawOrder(); } })));
      });
    };
    const mv = (i, d) => { const a = S.settings.toolOrder, j = i + d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; S.saveSettings(); IND.tools.renderToolbar(); drawOrder(); };
    drawOrder();
    const pos = [['top', 'Top', 'arrowup'], ['left', 'Left', 'left'], ['right', 'Right', 'right'], ['bottom', 'Bottom', 'arrowdown'], ['both', 'Both sides', 'split']];
    const body = col(h('h4', null, 'Toolbar position'), IND.tools.posPicker(S.settings.toolbarPos, (v) => IND.tools.setPos(v)),
      h('h4', null, 'Appearance'), U.segment([['auto', 'Auto'], ['light', 'Light'], ['dark', 'Dark']], S.settings.theme, (v) => { S.settings.theme = v; S.saveSettings(); S.applyTheme(); }),
      P.glassSection(),
      h('h4', null, 'Performance'),
      U.segment([['smooth', 'Smooth'], ['sharp', 'Sharp']], S.settings.quality || 'smooth', (v) => { S.settings.quality = v; S.saveSettings(); if (ed.doc) { ed.renderVisible(); } }),
      h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Smooth keeps drawing and scrolling lag-free (zoomed-in detail is always sharp). Sharp draws every page at full screen resolution.'),
      h('h4', null, 'Autosave timer'),
      U.segment([[30, '30 s'], [60, '1 min'], [120, '2 min'], [180, '3 min'], [300, '5 min']], S.settings.autosave || 30, (v) => { S.settings.autosave = v; S.saveSettings(); }),
      h('div', { class: 'row' }, h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)', flex: 1 } }, 'Notes are saved automatically at this interval, and always when you close a note or leave the app.'),
        inNote ? h('button', { class: 'btn', onclick: async () => { await ed.save(); U.toast('Saved'); } }, 'Save now') : null),
      h('h4', null, 'Input'), U.toggle('Finger can draw', S.settings.fingerDraw, (v) => { S.settings.fingerDraw = v; S.saveSettings(); IND.tools.updMode(); }),
      h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Off: the stylus writes while your finger scrolls and pinches to zoom.'),
      h('h4', null, 'Pen smoothing'), U.segment([['off', 'Off'], ['low', 'Low'], ['med', 'Medium'], ['high', 'High']], S.settings.smooth || 'med', (v) => { S.settings.smooth = v; S.saveSettings(); }),
      h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Steadies shaky or jittery lines. Higher is smoother but follows the pen a little later.'),
      h('h4', null, 'Tools in toolbar'), order);
    U.openSheet('Settings', body, { side: false }).style.width = 'min(520px,100%)';
  };
})();
