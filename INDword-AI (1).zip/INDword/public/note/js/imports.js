// Importing PDFs / images / Word / PowerPoint / text, and exporting PDF + backup files.
(function () {
  const I = (IND.imp = {});
  const U = IND.u;
  const W = 1240;
  const tick = () => new Promise((r) => setTimeout(r, 0));

  I.blankPage = (kind) => ({ id: U.uid(), w: W, h: 1754, bg: { kind: kind || 'blank' }, objs: [] });
  const imgPage = (src, iw, ih) => ({ id: U.uid(), w: W, h: Math.round((W * ih) / iw), bg: { kind: 'img', src }, objs: [] });

  // ---------- PDF ----------
  I.pdf = async function (file, prog) {
    if (!window.pdfjsLib) throw new Error('PDF engine not loaded');
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
    const data = await U.fileToBuffer(file);
    const pdfId = U.uid();
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(data.slice(0)) }).promise;
    const pages = new Array(pdf.numPages);
    const one = async (i) => {
      const pg = await pdf.getPage(i);
      const v1 = pg.getViewport({ scale: 1 });
      const vp = pg.getViewport({ scale: Math.min((i === 1 ? 700 : 320) / v1.width, 1.5) }); // tiny preview only; sharp pages are drawn from the PDF itself on demand
      const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
      const cx = c.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height);
      await pg.render({ canvasContext: cx, viewport: vp }).promise;
      const page = imgPage(c.toDataURL('image/jpeg', 0.6), c.width, c.height);
      page.bg.pdf = { id: pdfId, n: i };
      pages[i - 1] = page; pg.cleanup(); c.width = c.height = 0;
    };
    let done = 0; const BATCH = 4; // several pages at once keep the PDF worker busy
    for (let i = 1; i <= pdf.numPages; i += BATCH) {
      const idx = []; for (let k = i; k < i + BATCH && k <= pdf.numPages; k++) idx.push(k);
      await Promise.all(idx.map(one)); done += idx.length;
      if (prog) prog(done / pdf.numPages, 'Importing page ' + done + ' of ' + pdf.numPages);
      await tick();
    }
    let outline = [];
    try {
      const walkOl = async (items, level) => {
        for (const it of items || []) {
          let idx = null;
          try {
            let dest = it.dest;
            if (typeof dest === 'string') dest = await pdf.getDestination(dest);
            if (Array.isArray(dest)) idx = await pdf.getPageIndex(dest[0]);
          } catch (e) { /* ignore */ }
          outline.push({ title: it.title || 'Untitled', page: idx, level });
          if (level < 3) await walkOl(it.items, level + 1);
        }
      };
      await walkOl(await pdf.getOutline(), 0);
    } catch (e) { outline = []; }
    return { pages, outline, name: file.name.replace(/\.pdf$/i, ''), pdfId, pdfBuf: data };
  };

  // ---------- images ----------
  I.fitImage = async function (file, max) {
    const src = await U.fileToDataURL(file);
    const im = await U.loadImage(src);
    const w = im.naturalWidth || im.width, hh = im.naturalHeight || im.height, lim = max || 9000;
    if (Math.max(w, hh) <= lim) return { src, w, h: hh };   // untouched original pixels
    const k = lim / Math.max(w, hh);
    const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(hh * k);
    const cx = c.getContext('2d'); cx.imageSmoothingQuality = 'high'; cx.drawImage(im, 0, 0, c.width, c.height);
    return { src: c.toDataURL('image/jpeg', 0.95), w: c.width, h: c.height };
  };
  I.images = async function (files, prog) {
    const pages = [];
    for (let i = 0; i < files.length; i++) {
      const r = await I.fitImage(files[i], 9000);
      pages.push(imgPage(r.src, r.w, r.h));
      if (prog) prog((i + 1) / files.length, 'Importing image ' + (i + 1) + ' of ' + files.length);
      await tick();
    }
    return { pages, name: files[0].name.replace(/\.[^.]+$/, '') };
  };

  // ---------- Word / PowerPoint / text ----------
  function textPages(text, o) {
    o = Object.assign({ w: W, h: 1754, margin: 96, size: 30 }, o || {});
    const c = document.createElement('canvas').getContext('2d'); c.font = '400 ' + o.size + 'px Inter,sans-serif';
    const maxW = o.w - o.margin * 2, lineH = o.size * 1.25, perPage = Math.floor((o.h - o.margin * 2) / lineH);
    const lines = [];
    String(text).replace(/\r/g, '').split('\n').forEach((para) => {
      if (!para.trim()) { lines.push(''); return; }
      let line = '';
      para.split(/\s+/).forEach((word) => {
        const t = line ? line + ' ' + word : word;
        if (c.measureText(t).width > maxW && line) { lines.push(line); line = word; } else line = t;
      });
      lines.push(line);
    });
    const pages = [];
    for (let i = 0; i < Math.max(1, lines.length); i += perPage) {
      const t = { id: U.uid(), t: 'text', x: o.margin, y: o.margin, text: lines.slice(i, i + perPage).join('\n'), size: o.size, color: '#111827', font: 'Inter', b: false, i: false, u: false };
      IND.render.measureText(t);
      pages.push({ id: U.uid(), w: o.w, h: o.h, bg: { kind: 'blank' }, objs: t.text.trim() ? [t] : [] });
    }
    return pages;
  }
  const xmlDecode = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');

  I.more = async function (file, prog) {
    const name = file.name.replace(/\.[^.]+$/, ''), ext = (file.name.split('.').pop() || '').toLowerCase();
    if (ext === 'docx') {
      const r = await mammoth.extractRawText({ arrayBuffer: await U.fileToBuffer(file) });
      return { pages: textPages(r.value), name };
    }
    if (ext === 'pptx') {
      const zip = await JSZip.loadAsync(await U.fileToBuffer(file));
      const names = Object.keys(zip.files).filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
        .sort((a, b) => parseInt(a.match(/(\d+)\.xml/)[1], 10) - parseInt(b.match(/(\d+)\.xml/)[1], 10));
      const pages = [];
      for (let i = 0; i < names.length; i++) {
        const xml = await zip.files[names[i]].async('string');
        const paras = (xml.match(/<a:p>[\s\S]*?<\/a:p>|<a:p [\s\S]*?<\/a:p>/g) || []).map((p) => xmlDecode((p.match(/<a:t>([^<]*)<\/a:t>/g) || []).map((t) => t.replace(/<\/?a:t>/g, '')).join(''))).filter((t) => t.trim());
        const objs = []; let y = 90;
        paras.forEach((t, k) => {
          const o = { id: U.uid(), t: 'text', x: 90, y, text: t, size: k === 0 ? 56 : 34, color: '#111827', font: 'Inter', b: k === 0, i: false, u: false };
          IND.render.measureText(o);
          // keep long lines inside the slide
          if (o.w > 1060) { o.size = Math.max(18, Math.floor(o.size * 1060 / o.w)); IND.render.measureText(o); }
          objs.push(o); y += o.h + (k === 0 ? 40 : 18);
        });
        pages.push({ id: U.uid(), w: W, h: 698, bg: { kind: 'blank' }, objs });
        if (prog) prog((i + 1) / names.length, 'Importing slide ' + (i + 1) + ' of ' + names.length);
      }
      return { pages: pages.length ? pages : [I.blankPage()], name };
    }
    if (ext === 'txt' || ext === 'md' || ext === 'csv') {
      return { pages: textPages(await file.text()), name };
    }
    throw new Error('Old .doc / .ppt files are not supported. Please save as .docx / .pptx and try again.');
  };

  // ---------- export ----------
  const b64 = (buf) => { const u = new Uint8Array(buf); let out = ''; for (let i = 0; i < u.length; i += 0x8000) out += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(out); };
  const unb64 = (str) => { const bin = atob(str), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };
  const waitImg = (src) => new Promise((r) => { const t = setInterval(() => { if (IND.render.getImg(src)) { clearInterval(t); r(); } }, 30); setTimeout(() => { clearInterval(t); r(); }, 4000); });
  const toPng = (c) => new Promise((r) => c.toBlob(r, 'image/png')).then((b) => b.arrayBuffer());
  const hexRgb = (hex) => { const n = parseInt(String(hex).replace('#', '').padEnd(6, '0').slice(0, 6), 16); return PDFLib.rgb((n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255); };
  const dataUrl = (src) => { const i = String(src).indexOf(','); if (!/^data:/.test(src) || i < 0) return null; const mime = src.slice(5, i).split(';')[0], bin = atob(src.slice(i + 1)), u = new Uint8Array(bin.length); for (let k = 0; k < bin.length; k++) u[k] = bin.charCodeAt(k); return { mime, bytes: u }; };
  const f2 = (v) => (Math.round(v * 100) / 100).toString();
  // Strokes that can be written as real PDF vectors: crisp at any zoom, no halo, tiny and fast. Everything else is rasterised.
  const isVec = (o) => o.t === 's' && (o.tool === 'hl' || (o.tool === 'pen' && (o.pen || 'ball') === 'ball' && (o.line || 'solid') === 'solid'));
  const smoothPath = (pts, sx) => {
    let d = 'M' + f2(pts[0][0] * sx) + ' ' + f2(pts[0][1] * sx);
    if (pts.length === 1) return d + ' L' + f2(pts[0][0] * sx + 0.01) + ' ' + f2(pts[0][1] * sx);
    for (let i = 1; i < pts.length - 1; i++) d += ' Q' + f2(pts[i][0] * sx) + ' ' + f2(pts[i][1] * sx) + ' ' + f2((pts[i][0] + pts[i + 1][0]) / 2 * sx) + ' ' + f2((pts[i][1] + pts[i + 1][1]) / 2 * sx);
    return d + ' L' + f2(pts[pts.length - 1][0] * sx) + ' ' + f2(pts[pts.length - 1][1] * sx);
  };
  // indices (optional): export only these pages, in the given order
  I.exportPdf = async function (doc, prog, indices) {
    const out = await PDFLib.PDFDocument.create(), R = IND.render, srcs = new Map(), jpgCache = new Map();
    const list = indices && indices.length ? indices : doc.pages.map((_, i) => i);
    // 1) copy every original PDF page in one call per source file
    const copied = new Map();
    for (const i of list) {
      const p = doc.pages[i]; if (!(p.bg && p.bg.pdf)) continue;
      const id = p.bg.pdf.id; if (!srcs.has(id)) { try { const buf = await IND.store.getPdf(doc.id, id); srcs.set(id, buf ? await PDFLib.PDFDocument.load(buf.slice(0), { updateMetadata: false }) : null); } catch (e) { srcs.set(id, null); } }
    }
    for (const [id, src] of srcs) {
      if (!src) continue;
      const need = [...new Set(list.map((i) => doc.pages[i]).filter((p) => p.bg && p.bg.pdf && p.bg.pdf.id === id).map((p) => p.bg.pdf.n - 1))];
      try { const cps = await out.copyPages(src, need); need.forEach((n, k) => copied.set(id + ':' + n, cps[k])); } catch (e) { console.warn('copy failed', e); }
    }
    const jpegOf = async (src) => { // original JPEG bytes embedded as they are (no re-encoding)
      if (jpgCache.has(src)) return jpgCache.get(src); const d = dataUrl(src); let im = null;
      if (d && /jpe?g/.test(d.mime)) im = await out.embedJpg(d.bytes); jpgCache.set(src, im); return im;
    };
    // everything drawn on top of the page background, in z-order
    const overlay = async (page, p, sx, H) => {
      const ops = PDFLib; page.pushOperators(ops.pushGraphicsState(), ops.setLineJoin(ops.LineJoinStyle.Round));
      let grp = [];
      const flush = async () => {
        if (!grp.length) return; const objs = grp; grp = [];
        let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for (const o of objs) { const b = R.bbox(o), pad = o.t === 's' ? 30 + (o.size || 0) : 6; x0 = Math.min(x0, b.x - pad); y0 = Math.min(y0, b.y - pad); x1 = Math.max(x1, b.x + b.w + pad); y1 = Math.max(y1, b.y + b.h + pad); }
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(p.w, x1); y1 = Math.min(p.h, y1);
        const bw = x1 - x0, bh = y1 - y0; if (bw < 1 || bh < 1) return;
        const k = Math.min(2.2, 2600 / Math.max(bw, bh)), c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(bw * k)); c.height = Math.max(1, Math.ceil(bh * k));
        R.drawObjList(c.getContext('2d'), objs, k, x0, y0);
        const png = await out.embedPng(await toPng(c)); c.width = c.height = 0;
        page.drawImage(png, { x: x0 * sx, y: H - y1 * sx, width: bw * sx, height: bh * sx });
      };
      for (const o of p.objs) {
        if (isVec(o)) {
          await flush();
          const hl = o.tool === 'hl', col = hexRgb(o.color), alpha = hl ? (o.alpha == null ? 0.45 : o.alpha) : 1, blend = hl ? { blendMode: ops.BlendMode.Multiply } : {};
          if (hl && o.tip === 'flat') {
            const a = -Math.PI / 4, nx = Math.cos(a) * o.size / 2, ny = Math.sin(a) * o.size / 2, q = o.pts.length === 1 ? [o.pts[0], [o.pts[0][0] + 0.01, o.pts[0][1]]] : o.pts; let d = '';
            for (let i = 1; i < q.length; i++) { const A = q[i - 1], B = q[i]; d += 'M' + f2((A[0] - nx) * sx) + ' ' + f2((A[1] - ny) * sx) + ' L' + f2((A[0] + nx) * sx) + ' ' + f2((A[1] + ny) * sx) + ' L' + f2((B[0] + nx) * sx) + ' ' + f2((B[1] + ny) * sx) + ' L' + f2((B[0] - nx) * sx) + ' ' + f2((B[1] - ny) * sx) + ' Z '; }
            page.drawSvgPath(d, Object.assign({ x: 0, y: H, color: col, opacity: alpha }, blend));
          } else page.drawSvgPath(smoothPath(o.pts, sx), Object.assign({ x: 0, y: H, borderColor: col, borderWidth: o.size * sx, borderOpacity: alpha, borderLineCap: hl && o.tip === 'square' ? ops.LineCapStyle.Butt : ops.LineCapStyle.Round }, blend));
        } else if (o.t === 'img') {
          const im = await jpegOf(o.src);
          if (im) { await flush(); page.drawImage(im, { x: o.x * sx, y: H - (o.y + o.h) * sx, width: o.w * sx, height: o.h * sx }); } else { const r = R.getImg(o.src); if (!r) await waitImg(o.src); grp.push(o); }
        } else grp.push(o);
      }
      await flush(); page.pushOperators(ops.popGraphicsState());
    };
    for (let li = 0; li < list.length; li++) {
      const p = doc.pages[list[li]];
      const imgs = p.objs.filter((o) => o.t === 'img' && !/^data:image\/jpe?g/.test(o.src)); if (imgs.length) await Promise.all(imgs.map((o) => { R.getImg(o.src); return waitImg(o.src); }));
      const cp = p.bg && p.bg.pdf && copied.get(p.bg.pdf.id + ':' + (p.bg.pdf.n - 1));
      if (cp) {
        const page = out.addPage(cp), sz = page.getSize();
        try { await overlay(page, p, sz.width / p.w, sz.height); } catch (e) { console.warn('overlay failed', e); }
      } else {
        const pw = 595.28, sx = pw / p.w, H = p.h * sx, page = out.addPage([pw, H]), kind = p.bg && p.bg.kind;
        if (kind === 'img') {
          const im = await jpegOf(p.bg.src);
          if (im) page.drawImage(im, { x: 0, y: 0, width: pw, height: H });
          else { await waitImg(p.bg.src); const el = R.getImg(p.bg.src); const k = Math.max(1.5, Math.min(2.4, el ? el.naturalWidth / p.w : 2)), c = document.createElement('canvas'); c.width = Math.round(p.w * k); c.height = Math.round(p.h * k); const cx = c.getContext('2d'); cx.setTransform(k, 0, 0, k, 0, 0); R.drawBg(cx, p); const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.9)); c.width = c.height = 0; page.drawImage(await out.embedJpg(await blob.arrayBuffer()), { x: 0, y: 0, width: pw, height: H }); }
        } else if (kind === 'ruled' || kind === 'grid' || kind === 'dots') {
          const g = R.GRID, lc = hexRgb('#cdd6ea'), th = 1.4 * sx, line = (x1, y1, x2, y2, col) => page.drawLine({ start: { x: x1 * sx, y: H - y1 * sx }, end: { x: x2 * sx, y: H - y2 * sx }, thickness: th, color: col || lc });
          if (kind === 'ruled') { for (let y = g * 2; y < p.h; y += g) line(0, y, p.w, y); line(g * 1.6, 0, g * 1.6, p.h, hexRgb('#f2a7a7')); }
          else if (kind === 'grid') { for (let y = g; y < p.h; y += g) line(0, y, p.w, y); for (let x = g; x < p.w; x += g) line(x, 0, x, p.h); }
          else { const dc = hexRgb('#b7c2dc'); for (let y = g; y < p.h; y += g) for (let x = g; x < p.w; x += g) page.drawCircle({ x: x * sx, y: H - y * sx, size: 2.2 * sx, color: dc }); }
        }
        await overlay(page, p, sx, H);
      }
      if (prog) prog((li + 1) / list.length, 'Exporting page ' + (li + 1) + ' of ' + list.length);
      if (li % 4 === 3) await tick();
    }
    out.setTitle(doc.name); out.setProducer('INDnote');
    return new Blob([await out.save({ useObjectStreams: true })], { type: 'application/pdf' });
  };
  I.backupBlob = async function (doc) {
    const pdfData = {};
    for (const id of doc.pdfs || []) { const buf = await IND.store.getPdf(doc.id, id); if (buf) pdfData[id] = b64(buf); }
    return new Blob([JSON.stringify(Object.assign({}, doc, { pdfData }))], { type: 'application/json' });
  };
  I.restoreBackup = async function (d) {
    const old = d.id; d.id = U.uid(); d.modified = Date.now(); const pd = d.pdfData || {}; delete d.pdfData;
    await IND.store.saveDoc(d);
    for (const id in pd) await IND.store.putPdf(d.id, id, unb64(pd[id]));
    void old;
  };
  I.safeName = (n) => (n || 'note').replace(/[^\w\- ]+/g, '_').slice(0, 60);
})();
