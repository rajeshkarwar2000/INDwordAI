// Home: note library with search, sort, favourites, grid/list, multi-select, import and restore.
(function () {
  const U = IND.u, h = U.h, S = IND.store;
  const H = (IND.home = {});
  let metas = [], query = '', selMode = false; const picked = new Set();

  H.init = function () {
    const root = U.$('#home');
    root.innerHTML = '';
    H.grid = h('div', { class: 'docs grid' });
    H.searchIn = h('input', { type: 'search', placeholder: 'Search notes', id: 'search', oninput: (e) => { query = e.target.value.toLowerCase(); H.draw(); } });
    H.bar = h('div', { class: 'home-bar' });
    H.dock = h('div', { class: 'dock glass' });
    root.append(
      h('div', { class: 'home-top' },
        h('div', { class: 'brand' }, h('img', { src: 'img/logo.png', alt: '', width: 46, height: 46 }), h('span', null, 'IND', h('b', null, 'note'))),
        window.parent !== window ? h('button', { class: 'btn', style: { marginLeft: '10px' }, onclick: () => IND.toWord() }, '✍ Word mode') : null,
        h('div', { class: 'grow' }),
        h('div', { class: 'search glass', html: IND.icon('search') }, H.searchIn),
        h('button', { class: 'ibtn glass', html: IND.icon('settings'), 'aria-label': 'Settings', onclick: () => H.homeSettings() })),
      H.bar,
      h('div', { class: 'home-scroll' }, H.grid),
      H.dock);
    H.refresh();
  };

  H.refresh = async function () {
    metas = await S.listMeta(); H.draw();
  };

  H.draw = function () {
    const st = S.settings;
    let list = metas.filter((m) => (!query || m.name.toLowerCase().includes(query)) && (!st.favOnly || m.fav));
    const by = { modified: (a, b) => b.modified - a.modified, created: (a, b) => b.created - a.created, name: (a, b) => a.name.localeCompare(b.name) }[st.homeSort] || ((a, b) => b.modified - a.modified);
    list.sort((a, b) => (b.fav - a.fav) || by(a, b));

    H.bar.innerHTML = '';
    H.bar.append(
      h('button', { class: 'chip glass' + (st.favOnly ? ' on' : ''), html: IND.icon('star') + 'Favourites', onclick: () => { st.favOnly = !st.favOnly; S.saveSettings(); H.draw(); } }),
      h('button', { class: 'chip glass', html: IND.icon('list') + ({ modified: 'Recent', created: 'Created', name: 'Name' }[st.homeSort]), onclick: (e) => H.sortPop(e.currentTarget) }),
      h('button', { class: 'chip glass', html: IND.icon(st.homeView === 'grid' ? 'list' : 'grid') + (st.homeView === 'grid' ? 'List' : 'Grid'), onclick: () => { st.homeView = st.homeView === 'grid' ? 'list' : 'grid'; S.saveSettings(); H.draw(); } }),
      h('button', { class: 'chip glass' + (selMode ? ' on' : ''), html: IND.icon('check') + 'Select', onclick: () => { selMode = !selMode; picked.clear(); H.draw(); } }));

    H.grid.className = 'docs ' + st.homeView; H.grid.innerHTML = '';
    if (!list.length) {
      H.grid.className = '';
      H.grid.append(h('div', { class: 'empty' }, h('div', { html: IND.icon('file'), style: { fontSize: '44px', opacity: 0.6 } }),
        h('h2', null, metas.length ? 'Nothing matches' : 'Your notes live here'),
        h('div', null, metas.length ? 'Try another search or turn off the favourites filter.' : 'Create a blank note, or import a PDF, images or a Word or PowerPoint file to write on top of it.')));
    }
    list.forEach((m) => {
      const thumb = h('div', { class: 'thumb', style: m.thumb ? { backgroundImage: 'url(' + m.thumb + ')' } : {} });
      const fav = h('button', { class: 'fav' + (m.fav ? ' on' : ''), html: IND.icon('star'), 'aria-label': 'Favourite', onclick: async (e) => { e.stopPropagation(); m.fav = !m.fav; await S.saveMetaOnly(m); H.draw(); } });
      const card = h('div', { class: 'card glass' + (picked.has(m.id) ? ' sel' : ''), onclick: () => (selMode ? toggle(m.id) : H.openNote(m.id)) },
        selMode ? h('div', { class: 'chk', html: picked.has(m.id) ? IND.icon('check') : '' }) : null, thumb,
        h('div', { class: 'meta' }, h('div', { class: 'nm' }, m.name), h('div', { class: 'sub' }, m.pageCount + (m.pageCount === 1 ? ' page' : ' pages') + ' · ' + U.fmtDate(m.modified))),
        selMode ? null : fav);
      H.grid.append(card);
    });
    drawDock();
  };
  const toggle = (id) => { if (picked.has(id)) picked.delete(id); else picked.add(id); H.draw(); };

  function drawDock() {
    H.dock.innerHTML = '';
    if (selMode) {
      const n = picked.size;
      H.dock.append(
        h('button', { class: 'btn', onclick: () => { selMode = false; picked.clear(); H.draw(); } }, 'Done'),
        h('button', { class: 'btn', onclick: async () => { for (const id of picked) { const m = metas.find((x) => x.id === id); m.fav = !m.fav; await S.saveMetaOnly(m); } H.draw(); } }, 'Favourite'),
        h('button', { class: 'btn', onclick: () => { if (n === 1) { const m = metas.find((x) => x.id === [...picked][0]); U.prompt('Rename note', m.name, 'Rename', async (v) => { m.name = v; await S.saveMetaOnly(m); H.draw(); }); } else U.toast('Select one note to rename'); } }, 'Rename'),
        h('button', { class: 'btn danger', onclick: () => { if (!n) return; U.confirm('Delete notes', 'Delete ' + n + (n === 1 ? ' note' : ' notes') + '? This cannot be undone.', 'Delete', async () => { for (const id of picked) await S.deleteDoc(id); selMode = false; picked.clear(); H.refresh(); }, true); } }, 'Delete (' + n + ')'));
      return;
    }
    H.dock.append(
      h('button', { class: 'btn primary', html: IND.icon('plus') + 'New note', onclick: () => H.newNote() }),
      h('button', { class: 'btn', html: IND.icon('import') + 'Import', onclick: (e) => H.importPop(e.currentTarget) }));
  }

  H.openNote = async (id) => { const d = await S.getDoc(id); if (d) IND.editor.open(d); else U.toast('Could not open note'); };
  H.newNote = async function () {
    const n = metas.length + 1;
    const doc = { id: U.uid(), name: 'Note ' + n, created: Date.now(), modified: Date.now(), fav: false, pages: [IND.imp.blankPage('ruled')], bookmarks: [], outline: [] };
    await S.saveDoc(doc); IND.editor.open(await S.getDoc(doc.id));
  };
  H.importPop = function (btn) {
    const P = IND.panels;
    const it = (ic, t, s, fn) => h('button', { class: 'list-item', onclick: () => { U.closePop(); fn(); } }, h('span', { html: IND.icon(ic) }), h('span', { class: 'grow' }, t, s ? h('small', null, s) : null));
    U.openPop(btn, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } }, h('h4', null, 'Import as new note'),
      it('file', 'PDF', 'Write and annotate on every page', () => P.pickImport('pdf', 'new')),
      it('image', 'Images', 'Several pictures become several pages', () => P.pickImport('img', 'new')),
      it('camera', 'Camera', 'Scan a page with the camera', () => P.pickImport('cam', 'new')),
      it('file', 'Word, PowerPoint, text', '.docx  .pptx  .txt', () => P.pickImport('more', 'new')),
      it('import', 'INDnote backup', 'Restore a .indnote file', () => U.pickFile('f-backup', async (files) => {
        try { const d = JSON.parse(await files[0].text()); if (!d.pages) throw new Error('bad'); await IND.imp.restoreBackup(d); H.refresh(); U.toast('Note restored'); } catch (e) { U.toast('That file is not an INDnote backup'); }
      }))), 'above');
  };
  H.sortPop = function (btn) {
    const st = S.settings;
    U.openPop(btn, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, h('h4', null, 'Sort by'),
      U.optGrid([['modified', 'Recent', 'file'], ['created', 'Created', 'pageplus'], ['name', 'Name', 'text']], st.homeSort, (v) => { st.homeSort = v; S.saveSettings(); U.closePop(); H.draw(); })));
  };
  H.homeSettings = function () { IND.panels.settings(); }; // same settings screen as inside a note
})();
