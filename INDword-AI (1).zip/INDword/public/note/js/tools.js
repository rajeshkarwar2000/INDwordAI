// Toolbar (top / left / right / bottom / both sides) and per-tool option popovers.
(function () {
  const U = IND.u, h = U.h, S = IND.store, R = IND.render;
  const T = (IND.tools = {});
  T.active = 'pen';

  T.cfg = {
    pen: { color: '#111827', size: 4, pen: 'ball', line: 'solid', space: 10, nib: 'chisel', angle: 40 },
    brush: { color: '#e11d48', size: 18, brush: 'pencil' },
    highlighter: { color: '#facc15', size: 26, alpha: 0.45, tip: 'round', straight: false },
    laser: { color: '#ff0000', size: 10, mode: 'line', delay: 3, trail: 650 },
    eraser: { size: 28, mode: 'stroke' },
    shapes: { kind: 'rect', color: '#0a84ff', bw: 4, fill: false, fillColor: null, dash: 'solid', op: 1 },
    text: { font: 'Inter', size: 40, color: '#111827', b: false, i: false, u: false, align: 'left', lh: 1.25, bg: null },
    table: Object.assign({}, R.TABLE_DEFAULTS, { color: '#0a84ff', header: true }),
  };
  try { const saved = JSON.parse(localStorage.getItem('indnote.tools') || 'null'); if (saved) for (const k in saved) Object.assign(T.cfg[k] || (T.cfg[k] = {}), saved[k]); } catch (e) { /* ignore */ }
  T.saveCfg = U.debounce(() => { try { localStorage.setItem('indnote.tools', JSON.stringify(T.cfg)); } catch (e) { /* ignore */ } }, 400);
  const set = (tool, patch) => { Object.assign(T.cfg[tool], patch); T.saveCfg(); T.refreshSwatches(); };

  // id -> [icon, label, kind]   kind: 'draw' selectable tool, 'act' action
  T.defs = {
    pages: ['layers', 'Pages', 'act'], view: ['grid', 'Page view', 'act'], import: ['import', 'Import', 'act'], switch: ['file', 'Switch note', 'act'],
    move: ['move', 'Move toolbar', 'act'], undo: ['undo', 'Undo', 'act'], redo: ['redo', 'Redo', 'act'], mode: ['hand', 'Stylus / finger', 'act'],
    pen: ['pen', 'Pen', 'draw'], brush: ['brush', 'Brush', 'draw'], laser: ['laser', 'Laser pointer', 'draw'], highlighter: ['highlighter', 'Highlighter', 'draw'],
    eraser: ['eraser', 'Eraser', 'draw'], select: ['select', 'Select / move', 'draw'], shapes: ['shapes', 'Shapes', 'draw'], text: ['text', 'Text', 'draw'],
    table: ['table', 'Table', 'draw'], image: ['image', 'Image', 'act'], zoom: ['zoin', 'Zoom', 'act'],
  };
  T.defs.zoom[0] = 'zin';
  const LEFT_GROUP = ['pages', 'view', 'import', 'switch', 'move', 'undo', 'redo', 'mode'];
  const SEP_BEFORE = { undo: 1, pen: 1, zoom: 1, mode: 1 };

  T.posLabel = { top: 'Top', left: 'Left', right: 'Right', bottom: 'Bottom', both: 'Both sides' };

  // ------------------------------------------------------------ toolbar
  function button(id) {
    const d = T.defs[id], b = h('button', { class: 'ibtn', 'data-tool': id, 'aria-label': d[1], title: d[1], html: IND.icon(d[0]) });
    if (T.cfg[id] && T.cfg[id].color) b.append(h('i', { class: 'sw', style: { background: T.cfg[id].color } }));
    if (d[2] === 'draw') b.insertAdjacentHTML('beforeend', IND.icon('down', 'caret'));
    b.addEventListener('click', () => T.tap(id, b));
    return b;
  }
  function bar(ids, vertical) {
    const el = h('div', { class: 'tb glass ' + (vertical ? 'v' : 'h') });
    ids.forEach((id, i) => { if (i && SEP_BEFORE[id]) el.append(h('div', { class: 'sep' })); el.append(button(id)); });
    return el;
  }
  T.renderToolbar = function () {
    const E = IND.editor; if (!E.slots) return;
    const pos = S.settings.toolbarPos, hidden = S.settings.hidden;
    const ids = S.settings.toolOrder.filter((t) => !hidden.includes(t) || t === 'move');
    Object.values(E.slots).forEach((s) => (s.innerHTML = ''));
    if (pos === 'both') {
      E.slots.left.append(bar(ids.filter((t) => LEFT_GROUP.includes(t)), true));
      E.slots.right.append(bar(ids.filter((t) => !LEFT_GROUP.includes(t)), true));
    } else E.slots[pos].append(bar(ids, pos === 'left' || pos === 'right'));
    T.markActive(); E.updUndo(); T.updMode();
  };
  T.setPos = function (pos) { S.settings.toolbarPos = pos; S.saveSettings(); T.renderToolbar(); U.toast('Toolbar: ' + T.posLabel[pos]); };
  T.markActive = function () {
    document.querySelectorAll('.tb [data-tool]').forEach((b) => b.classList.toggle('on', b.dataset.tool === T.active));
    T.refreshSwatches();
  };
  T.refreshSwatches = function () {
    document.querySelectorAll('.tb [data-tool] .sw').forEach((s) => { const id = s.parentNode.dataset.tool; if (T.cfg[id]) s.style.background = T.cfg[id].color; });
  };
  T.updMode = function () {
    document.querySelectorAll('[data-tool="mode"]').forEach((b) => { b.innerHTML = IND.icon(S.settings.fingerDraw ? 'hand' : 'pen'); b.title = S.settings.fingerDraw ? 'Finger draws' : 'Stylus draws, finger scrolls'; });
  };

  T.setTool = function (id) {
    if (IND.input) { IND.input.finishText(); if (T.active === 'laser' && id !== 'laser') IND.input.laserStop(); }
    T.active = id; if (id !== 'select') IND.editor.select(IND.editor.sel ? IND.editor.sel.pi : 0, null);
    T.markActive();
  };
  T.tap = function (id, btn) {
    const E = IND.editor, P = IND.panels, d = T.defs[id];
    if (d[2] === 'draw') {
      if (T.active === id) { T.options(id, btn); return; }
      T.setTool(id); return;
    }
    if (id === 'undo') return E.undo();
    if (id === 'redo') return E.redo();
    if (id === 'pages') return P.viewPages();
    if (id === 'view') return P.pageView(btn);
    if (id === 'import') return P.importMenu(btn);
    if (id === 'switch') return P.switchNote(btn);
    if (id === 'move') return T.movePop(btn);
    if (id === 'zoom') return T.zoomPop(btn);
    if (id === 'image') return P.imageMenu(btn);
    if (id === 'mode') { S.settings.fingerDraw = !S.settings.fingerDraw; S.saveSettings(); T.updMode(); U.toast(S.settings.fingerDraw ? 'Finger draws too' : 'Stylus draws, finger scrolls'); }
  };
  const sideOf = (btn) => { const p = S.settings.toolbarPos; const r = btn.getBoundingClientRect(); return p === 'bottom' ? 'above' : (p === 'left' || (p === 'both' && r.left < innerWidth / 2)) ? 'right' : (p === 'right' || p === 'both') ? 'left' : 'below'; };
  T.side = sideOf;

  // ------------------------------------------------------------ move toolbar
  // tablet diagrams showing where the toolbar sits
  T.posPicker = function (cur, onPick) {
    const bar = (k) => ({ top: '<rect x="4" y="4" width="52" height="7" rx="3.5"/>', bottom: '<rect x="4" y="33" width="52" height="7" rx="3.5"/>', left: '<rect x="4" y="4" width="7" height="36" rx="3.5"/>', right: '<rect x="49" y="4" width="7" height="36" rx="3.5"/>', both: '<rect x="4" y="4" width="7" height="36" rx="3.5"/><rect x="49" y="4" width="7" height="36" rx="3.5"/>' }[k]);
    const g = h('div', { class: 'pos-grid' });
    ['top', 'left', 'right', 'bottom', 'both'].forEach((k) => {
      g.append(h('button', { class: 'pos' + (k === cur ? ' on' : ''), onclick: () => { [...g.children].forEach((x) => x.classList.remove('on')); g.querySelector('[data-k=' + k + ']').classList.add('on'); onPick(k); }, 'data-k': k },
        h('span', { class: 'tab', html: '<svg viewBox="0 0 60 44"><rect x="1" y="1" width="58" height="42" rx="7" fill="none" stroke="currentColor" stroke-width="1.6" opacity=".55"/><g fill="currentColor">' + bar(k) + '</g></svg>' }),
        h('span', null, T.posLabel[k])));
    });
    return g;
  };
  T.movePop = function (btn) {
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
      h('h4', null, 'Move toolbar'),
      T.posPicker(S.settings.toolbarPos, (v) => { T.setPos(v); setTimeout(U.closePop, 160); }),
      h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)', lineHeight: 1.4 } }, 'Both sides puts note and page tools on the left and drawing tools on the right.'));
    U.openPop(btn || null, body, btn ? sideOf(btn) : undefined);
  };

  // ------------------------------------------------------------ zoom
  T.zoomPop = function (btn, side) {
    const E = IND.editor;
    E.zoomEl = h('span', { style: { fontWeight: 700, minWidth: '56px', textAlign: 'center' } }, Math.round(E.zoom * 100) + '%');
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
      h('h4', null, 'Zoom'),
      h('div', { class: 'row', style: { justifyContent: 'center' } },
        h('button', { class: 'ibtn', html: IND.icon('zout'), onclick: () => E.animZoom(E.zoom / 1.25) }), E.zoomEl,
        h('button', { class: 'ibtn', html: IND.icon('zin'), onclick: () => E.animZoom(E.zoom * 1.25) })),
      h('div', { class: 'row' }, ...[[1, '100%'], [2, '200%'], [4, '400%'], [6, '600%']].map(([z, l]) => h('button', { class: 'btn grow', onclick: () => E.animZoom(z) }, l))),
      h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Zoom stays sharp: pages, text and images are redrawn at full detail.'));
    U.openPop(btn, body, side || sideOf(btn));
  };

  // ------------------------------------------------------------ options
  const sizeSlider = (tool, min, max, label) => U.slider(label || 'Size', min, max, 1, T.cfg[tool].size, (v) => set(tool, { size: v }), (v) => v + ' px');
  const colorBlock = (tool) => [h('h4', null, 'Color'), U.colorRow(T.cfg[tool].color, (c) => set(tool, { color: c }))];

  T.options = function (id, btn) {
    const c = T.cfg[id]; let body;
    const wrap = (...k) => h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '74vh', overflowY: 'auto', overscrollBehavior: 'contain' } }, ...k);
    if (id === 'pen') {
      if (c.pen === 'fountain') c.pen = 'calligraphy';
      const spaceRow = h('div', { style: { display: c.line === 'solid' ? 'none' : 'block' } }, U.slider('Spacing', 2, 40, 1, c.space, (v) => set('pen', { space: v }), (v) => v + ' px'));
      const calRow = h('div', { style: { display: c.pen === 'calligraphy' ? 'flex' : 'none', flexDirection: 'column', gap: '12px' } },
        h('h4', null, 'Calligraphy nib'),
        U.segment([['chisel', 'Broad nib'], ['pointed', 'Pointed']], c.nib, (v) => { set('pen', { nib: v }); angRow.style.display = v === 'chisel' ? 'block' : 'none'; }));
      const angRow = h('div', { style: { display: c.nib === 'chisel' ? 'block' : 'none' } }, U.slider('Nib angle', 0, 90, 1, c.angle, (v) => set('pen', { angle: v }), (v) => v + '°'));
      calRow.append(angRow);
      body = wrap(h('h4', null, 'Pen'),
        U.optGrid([['ball', 'Ball', 'pen'], ['natural', 'Natural', 'brush'], ['calligraphy', 'Calligraphy', 'highlighter']], c.pen, (v) => { set('pen', { pen: v }); calRow.style.display = v === 'calligraphy' && c.line === 'solid' ? 'flex' : 'none'; }),
        calRow,
        sizeSlider('pen', 1, 40, 'Thickness'),
        h('h4', null, 'Line style'),
        U.segment([['solid', 'Solid'], ['dotted', 'Dotted'], ['dashdot', 'Dash']], c.line, (v) => { set('pen', { line: v }); spaceRow.style.display = v === 'solid' ? 'none' : 'block'; calRow.style.display = v === 'solid' && c.pen === 'calligraphy' ? 'flex' : 'none'; }),
        spaceRow, ...colorBlock('pen'));
    } else if (id === 'brush') {
      body = wrap(h('h4', null, 'Brush'),
        U.optGrid([['pencil', 'Pencil', 'pen'], ['oil', 'Oil', 'brush'], ['spill', 'Spill', 'palette'], ['watercolor', 'Watercolor', 'palette'], ['crayon', 'Crayon', 'highlighter']], c.brush, (v) => set('brush', { brush: v })),
        sizeSlider('brush', 4, 90, 'Size'), ...colorBlock('brush'));
    } else if (id === 'highlighter') {
      const tipPrev = (k) => { const cv = h('canvas', { width: 90, height: 40, style: { width: '56px', height: '26px' } }); const cx = cv.getContext('2d'); R.drawStroke(cx, { t: 's', tool: 'hl', tip: k, color: '#facc15', size: 16, alpha: 0.7, pts: [[14, 26, 0.5], [34, 12, 0.5], [54, 26, 0.5], [76, 12, 0.5]] }, 0, null, true); return cv; };
      const tips = h('div', { class: 'opts', style: { gridTemplateColumns: 'repeat(3,1fr)' } });
      [['round', 'Round'], ['flat', 'Flat nib'], ['square', 'Square']].forEach(([k, l]) => tips.append(h('button', { class: 'opt' + (k === (c.tip || 'round') ? ' on' : ''), 'data-k': k, onclick: () => { set('highlighter', { tip: k }); [...tips.children].forEach((b) => b.classList.toggle('on', b.dataset.k === k)); } }, tipPrev(k), h('span', null, l))));
      body = wrap(h('h4', null, 'Highlighter'), h('h4', null, 'Tip'), tips,
        U.toggle('Straight line', !!c.straight, (v) => set('highlighter', { straight: v })),
        sizeSlider('highlighter', 8, 80, 'Thickness'),
        U.slider('Opacity', 15, 90, 1, Math.round(c.alpha * 100), (v) => set('highlighter', { alpha: v / 100 }), (v) => v + '%'),
        h('h4', null, 'Color'), U.colorRow(c.color, (x) => set('highlighter', { color: x }), 'hlPalette'),
        h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Straight line draws a ruler-straight highlight that snaps to horizontal. Highlights stay readable over text, also in exported PDFs.'));
    } else if (id === 'laser') {
      const cv = h('canvas', { width: 640, height: 150, style: { width: '100%', height: '78px', borderRadius: '14px', background: 'repeating-linear-gradient(0deg,transparent 0 15px,rgba(120,130,160,.12) 15px 16px)' } });
      const drawPrev = () => {
        const cx = cv.getContext('2d'); cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, 640, 150);
        const k = T.cfg.laser, pts = [];
        for (let i = 0; i <= 40; i++) { const t = i / 40; pts.push({ x: 60 + t * 520, y: 75 + Math.sin(t * Math.PI * 2) * 34 }); }
        const sz = k.size * 0.8, hd = { x: pts[pts.length - 1].x, y: pts[pts.length - 1].y, a: 1 };
        if (k.mode === 'dot') R.drawLaser(cx, [], null, k.color, sz, { head: { x: pts[26].x, y: pts[26].y, a: 1 } });
        else if (k.mode === 'line') R.drawLaser(cx, pts, pts.map((_, i) => Math.pow(i / (pts.length - 1), 1.25)), k.color, sz, { taper: true, head: hd });
        else R.drawLaser(cx, pts, null, k.color, sz, { head: hd });
      };
      const trailRow = h('div', { style: { display: c.mode === 'line' ? 'block' : 'none' } }, U.slider('Trail length', 300, 2500, 50, c.trail || 650, (v) => set('laser', { trail: v }), (v) => (v / 1000).toFixed(2) + ' s'));
      const delayRow = h('div', { style: { display: c.mode === 'delay' ? 'block' : 'none' } }, U.slider('Hold time', 1, 5, 1, c.delay, (v) => set('laser', { delay: v }), (v) => v + ' s'));
      const modes = h('div', { class: 'opts', style: { gridTemplateColumns: 'repeat(3,1fr)' } });
      [['dot', 'Dot', '<i style="width:9px;height:9px;border-radius:5px;background:currentColor;display:block;margin:8px 0"></i>'], ['line', 'Trail', '<i style="width:28px;height:5px;border-radius:3px;background:currentColor;display:block;margin:10px 0"></i>'], ['delay', 'Hold', '<i style="width:28px;height:5px;border-radius:3px;background:linear-gradient(90deg,currentColor,transparent);display:block;margin:10px 0"></i>']].forEach(([m, l, ic]) => {
        modes.append(h('button', { class: 'opt' + (m === c.mode ? ' on' : ''), html: ic + '<span>' + l + '</span>', onclick: () => {
          set('laser', { mode: m }); [...modes.children].forEach((b) => b.classList.remove('on')); modes.children[['dot', 'line', 'delay'].indexOf(m)].classList.add('on');
          delayRow.style.display = m === 'delay' ? 'block' : 'none'; trailRow.style.display = m === 'line' ? 'block' : 'none'; drawPrev();
        } }));
      });
      const lcol = ['#ff0000', '#0a84ff', '#00e676', '#ffd600', '#ff9100', '#d500f9', '#111111'];
      const sw = h('div', { class: 'swatches' });
      lcol.forEach((x) => sw.append(h('button', { class: 'swatch' + (x === c.color ? ' on' : ''), style: { background: x }, onclick: () => { set('laser', { color: x }); [...sw.children].forEach((b) => b.classList.remove('on')); sw.children[lcol.indexOf(x)].classList.add('on'); drawPrev(); } })));
      body = wrap(h('h4', null, 'Laser pointer'), cv, modes, trailRow, delayRow, U.slider('Size', 3, 30, 1, c.size, (v) => { set('laser', { size: v }); drawPrev(); }, (v) => v + ' px'),
        h('h4', null, 'Color'), sw, h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)' } }, 'Trail: the line fades as you move. Hold: it stays for the hold time, then fades. Laser marks are never saved.'));
      requestAnimationFrame(drawPrev);
    } else if (id === 'eraser') {
      body = wrap(h('h4', null, 'Eraser'),
        U.segment([['stroke', 'Whole stroke'], ['pixel', 'Part of stroke']], c.mode, (v) => set('eraser', { mode: v })),
        sizeSlider('eraser', 8, 120, 'Eraser size'),
        h('button', { class: 'btn danger', onclick: () => { U.closePop(); U.confirm('Clear page', 'Remove everything you drew on this page?', 'Clear page', () => { const E = IND.editor; E.push(); E.setObjs(E.curIdx, []); E.sel = null; E.renderPage(E.curIdx); E.dirty(); }, true); } }, 'Clear this page'));
    } else if (id === 'shapes') {
      T.shapeOpts(btn); return;
    } else if (id === 'text') {
      T.textOpts(btn); return;
    } else if (id === 'table') {
      T.tableOpts(null, btn); return;
    } else if (id === 'select') {
      const so = IND.editor.selObj();
      if (so && so.t === 'table') { U.closePop(); T.tableOpts(so, btn); return; }
      if (so && so.t === 'shape') { U.closePop(); T.shapeOpts(btn, so); return; }
      if (so && so.t === 'text') { U.closePop(); T.textOpts(btn, so); return; }
      if (so && so.t === 'img') { U.closePop(); IND.crop.open(so, IND.editor.sel.pi); return; }
      body = wrap(h('h4', null, 'Select'), h('div', { style: { fontSize: '13.5px', color: 'var(--ink-2)', lineHeight: 1.5 } }, 'Tap an object to select it. Drag to move. Use the blue corner to resize and the red corner to delete.'),
        h('div', { class: 'row' }, h('button', { class: 'btn grow', onclick: () => IND.editor.dupSel() }, 'Duplicate'), h('button', { class: 'btn grow', onclick: () => IND.editor.orderSel(true) }, 'To front'), h('button', { class: 'btn grow', onclick: () => IND.editor.orderSel(false) }, 'To back')));
    }
    if (body) U.openPop(btn, body, sideOf(btn));
  };

  // live-apply text options to the object being edited or selected
  function applyTextSel(patch) {
    const E = IND.editor, o = E.selObj(); const t = IND.input && IND.input.editing;
    if (t) { IND.input.restyleText(patch); return; }
    if (o && o.t === 'text') E.updateObj(E.sel.pi, o.id, patch);
  }
  T.applyTextSel = applyTextSel;
  const note = (t) => h('div', { style: { fontSize: '12.5px', color: 'var(--ink-2)', lineHeight: 1.4 } }, t);
  const col = (...k) => h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '70vh', overflowY: 'auto' } }, ...k);
  // shared "apply to defaults and, when editing, to the selected object"
  const targetApi = (tool, sel, type) => {
    const E = IND.editor, pi = sel ? E.sel.pi : 0;
    const cur = () => (sel ? (E.selObj() || sel) : T.cfg[tool]);
    const upd = (p) => { Object.assign(T.cfg[tool], p); T.saveCfg(); T.refreshSwatches(); if (sel) E.updateObj(pi, sel.id, p); };
    return { cur, upd, E, pi };
  };

  T.shapeOpts = function (btn, sel, below) {
    const { cur, upd } = targetApi('shapes', sel);
    const c = cur();
    const g = h('div', { class: 'opts', style: { gridTemplateColumns: 'repeat(4,1fr)' } });
    R.SHAPES.forEach(([k, l]) => {
      const cv = h('canvas', { width: 48, height: 48, style: { width: '34px', height: '34px' } });
      R.drawObj(cv.getContext('2d'), { t: 'shape', kind: k, x1: 7, y1: 9, x2: 41, y2: 39, color: '#6b7280', bw: 3, fill: false });
      g.append(h('button', { class: 'opt' + (k === c.kind ? ' on' : ''), title: l, onclick: () => { upd({ kind: k }); [...g.children].forEach((b) => b.classList.remove('on')); g.children[R.SHAPES.findIndex((s) => s[0] === k)].classList.add('on'); } }, cv));
    });
    const fillRow = h('div', { style: { display: c.fill ? 'flex' : 'none', flexDirection: 'column', gap: '8px' } }, h('h4', null, 'Fill color'), U.colorRow(c.fillColor || c.color, (v) => upd({ fillColor: v })));
    const body = col(h('h4', null, sel ? 'Edit shape' : 'Shape'), g,
      U.slider('Border width', 1, 24, 1, c.bw, (v) => upd({ bw: v }), (v) => v + ' px'),
      h('h4', null, 'Line style'), U.segment([['solid', 'Solid'], ['dashed', 'Dashed'], ['dotted', 'Dotted']], c.dash || 'solid', (v) => upd({ dash: v })),
      U.slider('Opacity', 10, 100, 1, Math.round((c.op == null ? 1 : c.op) * 100), (v) => upd({ op: v / 100 }), (v) => v + '%'),
      U.toggle('Fill shape', !!c.fill, (v) => { upd({ fill: v }); fillRow.style.display = v ? 'flex' : 'none'; }), fillRow,
      h('h4', null, 'Border color'), U.colorRow(c.color, (v) => upd({ color: v })),
      note(sel ? 'Drag the white dots on a line to change its ends. Blue corner resizes.' : 'Drag to draw, or tap to place a shape. Lines snap to straight angles. The tool stays on so you can draw more.'));
    U.openPop(btn || null, body, below ? 'below' : btn ? sideOf(btn) : undefined);
  };

  T.textOpts = function (btn, sel, below) {
    const E = IND.editor;
    const inEdit = () => IND.input && IND.input.editing;
    const so = sel || null, c = so || T.cfg.text;
    const upd = (p) => { Object.assign(T.cfg.text, p); T.saveCfg(); T.refreshSwatches(); applyTextSel(p); };
    const fonts = ['Inter', 'Merriweather', 'Caveat', 'JetBrains Mono', 'Poppins'];
    const fsel = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px' } });
    fonts.forEach((f) => fsel.append(h('button', { class: 'chip' + (f === c.font ? ' on' : ''), style: { fontFamily: f + ',sans-serif' }, onclick: () => { upd({ font: f }); [...fsel.children].forEach((x) => x.classList.toggle('on', x.textContent === f)); } }, f)));
    const sty = (k, ic) => { const b = h('button', { class: 'ibtn' + (c[k] ? ' on' : ''), html: IND.icon(ic), onclick: () => { const v = !(so ? (E.selObj() || so)[k] : T.cfg.text[k]); upd({ [k]: v }); b.classList.toggle('on', v); } }); return b; };
    const bgOn = !!c.bg;
    const bgRow = h('div', { style: { display: bgOn ? 'flex' : 'none', flexDirection: 'column', gap: '8px' } }, U.colorRow(c.bg || '#fff3b0', (v) => upd({ bg: v })));
    const body = col(h('h4', null, so ? 'Edit text box' : 'Text'), fsel,
      U.slider('Size', 14, 200, 1, c.size, (v) => upd({ size: v }), (v) => v + ' px'),
      h('div', { class: 'row', style: { justifyContent: 'center' } }, sty('b', 'bold'), sty('i', 'italic'), sty('u', 'underline')),
      h('h4', null, 'Alignment'), U.segment([['left', '', 'alignl'], ['center', '', 'alignc'], ['right', '', 'alignr']], c.align || 'left', (v) => upd({ align: v })),
      U.slider('Line spacing', 100, 220, 5, Math.round((c.lh || 1.25) * 100), (v) => upd({ lh: v / 100 }), (v) => (v / 100).toFixed(2) + '×'),
      U.toggle('Box background', bgOn, (v) => { upd({ bg: v ? (c.bg || '#fff3b0') : null }); bgRow.style.display = v ? 'flex' : 'none'; }), bgRow,
      so && so.fw ? U.toggle('Auto width', false, (v) => { if (v) { E.updateObj(E.sel.pi, so.id, { fw: null }); U.closePop(); } }) : null,
      h('h4', null, 'Text color'), U.colorRow(c.color, (v) => upd({ color: v })),
      note(so ? 'Drag the blue corner to change the box width.' : 'Tap to type, or drag a box on the page to set its width. Changes also apply to the selected text.'));
    void inEdit;
    U.openPop(btn || null, body, below ? 'below' : btn ? sideOf(btn) : undefined);
  };

  // table options: used for the defaults (sel == null) and for a selected table
  T.tableOpts = function (sel, anchor, below) {
    const E = IND.editor, pi = sel ? E.sel.pi : 0;
    const cur = () => (sel ? (E.selObj() || sel) : T.cfg.table);
    const upd = (p) => { Object.assign(T.cfg.table, p); T.saveCfg(); T.refreshSwatches(); if (sel) E.updateObj(pi, sel.id, p); };
    const c = cur(), pt = (v) => Math.round(v / R.PT * 2) / 2;
    const size = (rows, cols) => { if (!sel) return upd({ rows, cols }); const n = R.resizeTable(cur(), rows, cols); upd({ rows: n.rows, cols: n.cols, cells: n.cells }); };
    const styles = h('div', { class: 'opts', style: { gridTemplateColumns: 'repeat(4,1fr)' } });
    [['grid', 'Grid'], ['banded', 'Banded'], ['minimal', 'Minimal'], ['plain', 'Plain']].forEach(([k, l]) => {
      styles.append(h('button', { class: 'opt' + ((c.style || 'grid') === k ? ' on' : ''), onclick: () => { upd({ style: k }); [...styles.children].forEach((b) => b.classList.toggle('on', b.dataset.k === k)); }, 'data-k': k },
        h('span', { class: 'tstyle t-' + k, html: '<i></i><i></i><i></i>' }), h('span', null, l)));
    });
    const body = col(h('h4', null, 'Table'),
      h('h4', null, 'Table style'), styles,
      h('h4', null, 'Color'), U.colorRow(c.color, (v) => upd({ color: v })),
      U.slider('Spacing', 2, 40, 1, c.spacing, (v) => upd({ spacing: v }), (v) => v + ' px'),
      U.slider('Font size', 8, 48, 0.5, pt(c.fs), (v) => upd({ fs: v * R.PT }), (v) => v + ' pt'),
      U.slider('Border width', 0.5, 8, 0.5, pt(c.bw), (v) => upd({ bw: v * R.PT }), (v) => v + ' pt'),
      U.segment([['left', '', 'alignl'], ['center', '', 'alignc'], ['right', '', 'alignr']], c.align || 'left', (v) => upd({ align: v })),
      U.toggle('Header row', !!c.header, (v) => upd({ header: v })), U.toggle('Banded rows', !!c.band, (v) => upd({ band: v })),
      U.stepper('Rows', c.rows, 1, 30, (v) => size(v, cur().cols)), U.stepper('Columns', c.cols, 1, 14, (v) => size(cur().rows, v)),
      note(sel ? 'Drag the blue corner to resize. Double tap a cell to type.' : 'Tap the page to insert. Tap a cell to type.'));
    U.openPop(anchor || null, body, below ? 'below' : anchor ? sideOf(anchor) : undefined);
  };
})();
