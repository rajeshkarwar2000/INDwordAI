// Crop dialog for images. Works on the full-resolution pixels, so a cropped picture stays sharp.
(function () {
  const U = IND.u, h = U.h;
  const C = (IND.crop = {});

  // o: the image object, pi: its page index, fresh: true right after inserting (the button says Skip)
  C.open = function (o, pi, fresh) {
    return new Promise(async (resolve) => {
      const E = IND.editor;
      let im;
      try { im = await U.loadImage(o.src); } catch (e) { U.toast('Could not open the image'); resolve(); return; }
      let bc = document.createElement('canvas'); bc.width = im.naturalWidth || im.width; bc.height = im.naturalHeight || im.height;
      bc.getContext('2d').drawImage(im, 0, 0);
      let rect = { x: 0, y: 0, w: bc.width, h: bc.height }, ratio = 0, drag = null, scale = 1;

      const view = h('canvas', { style: { touchAction: 'none', borderRadius: '10px', background: '#222', maxWidth: '100%' } });
      const vctx = view.getContext('2d');
      const fit = () => {
        const maxW = Math.min(innerWidth - 80, 1000), maxH = innerHeight - 280;
        scale = Math.min(maxW / bc.width, maxH / bc.height, 1.5);
        view.width = Math.round(bc.width * scale); view.height = Math.round(bc.height * scale);
        view.style.width = view.width + 'px'; view.style.height = view.height + 'px';
      };
      const draw = () => {
        const w = view.width, hh = view.height, r = rect, s = scale;
        vctx.clearRect(0, 0, w, hh); vctx.drawImage(bc, 0, 0, w, hh);
        vctx.fillStyle = 'rgba(8,10,20,.62)';
        vctx.fillRect(0, 0, w, r.y * s); vctx.fillRect(0, (r.y + r.h) * s, w, hh - (r.y + r.h) * s);
        vctx.fillRect(0, r.y * s, r.x * s, r.h * s); vctx.fillRect((r.x + r.w) * s, r.y * s, w - (r.x + r.w) * s, r.h * s);
        vctx.strokeStyle = '#fff'; vctx.lineWidth = 2; vctx.strokeRect(r.x * s, r.y * s, r.w * s, r.h * s);
        vctx.lineWidth = 1; vctx.strokeStyle = 'rgba(255,255,255,.45)'; vctx.beginPath();
        for (let i = 1; i < 3; i++) { vctx.moveTo((r.x + (r.w * i) / 3) * s, r.y * s); vctx.lineTo((r.x + (r.w * i) / 3) * s, (r.y + r.h) * s); vctx.moveTo(r.x * s, (r.y + (r.h * i) / 3) * s); vctx.lineTo((r.x + r.w) * s, (r.y + (r.h * i) / 3) * s); }
        vctx.stroke();
        vctx.fillStyle = '#0a84ff'; vctx.strokeStyle = '#fff'; vctx.lineWidth = 2.5;
        for (const [cx, cy] of corners()) { vctx.beginPath(); vctx.arc(cx * s, cy * s, 11, 0, Math.PI * 2); vctx.fill(); vctx.stroke(); }
        info.textContent = Math.round(r.w) + ' × ' + Math.round(r.h) + ' px';
      };
      const corners = () => [[rect.x, rect.y], [rect.x + rect.w, rect.y], [rect.x, rect.y + rect.h], [rect.x + rect.w, rect.y + rect.h]];
      const pos = (e) => { const b = view.getBoundingClientRect(); return { x: ((e.clientX - b.left) / b.width) * bc.width, y: ((e.clientY - b.top) / b.height) * bc.height }; };
      const MIN = 24;
      const clampRect = () => {
        rect.w = U.clamp(rect.w, MIN, bc.width); rect.h = U.clamp(rect.h, MIN, bc.height);
        rect.x = U.clamp(rect.x, 0, bc.width - rect.w); rect.y = U.clamp(rect.y, 0, bc.height - rect.h);
      };
      const setRatio = (r) => {
        ratio = r; if (!r) return draw();
        let w = bc.width, hh = w / r; if (hh > bc.height) { hh = bc.height; w = hh * r; }
        rect = { x: (bc.width - w) / 2, y: (bc.height - hh) / 2, w, h: hh }; draw();
      };

      view.addEventListener('pointerdown', (e) => {
        const p = pos(e), reach = 30 / scale; let hit = -1;
        corners().forEach(([cx, cy], i) => { if (hit < 0 && Math.hypot(p.x - cx, p.y - cy) < reach) hit = i; });
        if (hit >= 0) drag = { mode: 'corner', i: hit, anchor: corners()[3 - hit] };
        else if (p.x > rect.x && p.x < rect.x + rect.w && p.y > rect.y && p.y < rect.y + rect.h) drag = { mode: 'move', dx: p.x - rect.x, dy: p.y - rect.y };
        else {
          // edges: grab the nearest side
          const dl = Math.abs(p.x - rect.x), dr = Math.abs(p.x - rect.x - rect.w), dt = Math.abs(p.y - rect.y), db = Math.abs(p.y - rect.y - rect.h);
          const m = Math.min(dl, dr, dt, db);
          if (m < reach && !ratio) drag = { mode: 'edge', side: m === dl ? 'l' : m === dr ? 'r' : m === dt ? 't' : 'b' };
        }
        if (drag) { try { view.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } }
      });
      view.addEventListener('pointermove', (e) => {
        if (!drag) return; const p = pos(e);
        if (drag.mode === 'move') { rect.x = p.x - drag.dx; rect.y = p.y - drag.dy; clampRect(); }
        else if (drag.mode === 'corner') {
          let [ax, ay] = drag.anchor, px = U.clamp(p.x, 0, bc.width), py = U.clamp(p.y, 0, bc.height);
          let w = Math.abs(px - ax), hh = Math.abs(py - ay);
          if (ratio) { hh = w / ratio; if (py < ay ? ay - hh < 0 : ay + hh > bc.height) { hh = py < ay ? ay : bc.height - ay; w = hh * ratio; } if (px < ax ? ax - w < 0 : ax + w > bc.width) { w = px < ax ? ax : bc.width - ax; hh = w / ratio; } }
          w = Math.max(MIN, w); hh = Math.max(MIN, hh);
          rect = { x: px < ax ? ax - w : ax, y: py < ay ? ay - hh : ay, w, h: hh }; clampRect();
        } else if (drag.mode === 'edge') {
          const r = rect;
          if (drag.side === 'l') { const nx = U.clamp(p.x, 0, r.x + r.w - MIN); r.w += r.x - nx; r.x = nx; }
          if (drag.side === 'r') r.w = U.clamp(p.x - r.x, MIN, bc.width - r.x);
          if (drag.side === 't') { const ny = U.clamp(p.y, 0, r.y + r.h - MIN); r.h += r.y - ny; r.y = ny; }
          if (drag.side === 'b') r.h = U.clamp(p.y - r.y, MIN, bc.height - r.y);
        }
        draw();
      });
      const end = () => { drag = null; };
      view.addEventListener('pointerup', end); view.addEventListener('pointercancel', end);

      const rotate = () => {
        const n = document.createElement('canvas'); n.width = bc.height; n.height = bc.width;
        const cx = n.getContext('2d'); cx.translate(n.width, 0); cx.rotate(Math.PI / 2); cx.drawImage(bc, 0, 0);
        rect = { x: bc.height - rect.y - rect.h, y: rect.x, w: rect.h, h: rect.w }; bc = n; if (ratio) ratio = 1 / ratio; fit(); draw();
      };
      const reset = async () => {
        const src = o.orig || o.src; const im2 = await U.loadImage(src);
        bc = document.createElement('canvas'); bc.width = im2.naturalWidth || im2.width; bc.height = im2.naturalHeight || im2.height;
        bc.getContext('2d').drawImage(im2, 0, 0); rect = { x: 0, y: 0, w: bc.width, h: bc.height }; ratio = 0; fit(); draw();
      };

      const info = h('span', { style: { fontSize: '13px', fontWeight: 600, color: 'var(--ink-2)', fontVariantNumeric: 'tabular-nums' } });
      const finish = (apply) => {
        wrap.remove(); IND.sheetOpen = false;
        if (apply) {
          const out = document.createElement('canvas'); out.width = Math.round(rect.w); out.height = Math.round(rect.h);
          out.getContext('2d').drawImage(bc, Math.round(rect.x), Math.round(rect.y), out.width, out.height, 0, 0, out.width, out.height);
          const png = /^data:image\/png/.test(o.src), src = png ? out.toDataURL('image/png') : out.toDataURL('image/jpeg', 0.95);
          const pg = E.doc.pages[pi]; let w = Math.max(60, o.w), hh = w * out.height / out.width;
          const maxH = pg.h * 0.9; if (hh > maxH) { hh = maxH; w = hh * out.width / out.height; }
          if (w > pg.w * 0.95) { w = pg.w * 0.95; hh = w * out.height / out.width; }
          U.loadImage(src).then(() => { E.updateObj(pi, o.id, { src, orig: o.orig || o.src, w, h: hh }); IND.render.getImg(src); resolve(); });
        } else resolve();
      };
      const chip = (label, fn) => h('button', { class: 'chip', onclick: fn }, label);
      const wrap = h('div', { class: 'sheet-wrap', onpointerdown: (e) => { if (e.target === wrap) finish(false); } },
        h('div', { class: 'sheet glass glass-strong', style: { width: 'auto', maxWidth: '100%', alignItems: 'stretch' } },
          h('div', { class: 'sheet-head' }, h('h3', null, 'Crop image'), info),
          h('div', { class: 'sheet-body', style: { alignItems: 'center' } }, view,
            h('div', { class: 'row', style: { flexWrap: 'wrap', justifyContent: 'center', gap: '8px' } },
              chip('Free', () => setRatio(0)), chip('1:1', () => setRatio(1)), chip('4:3', () => setRatio(4 / 3)), chip('3:4', () => setRatio(3 / 4)), chip('16:9', () => setRatio(16 / 9)), chip('9:16', () => setRatio(9 / 16)),
              h('button', { class: 'chip', html: IND.icon('rot') + 'Rotate', onclick: rotate }),
              o.orig ? h('button', { class: 'chip', onclick: reset }, 'Reset') : null),
            h('div', { class: 'row', style: { justifyContent: 'flex-end', width: '100%' } },
              h('button', { class: 'btn', onclick: () => finish(false) }, fresh ? 'Skip' : 'Cancel'),
              h('button', { class: 'btn primary', html: IND.icon('check') + 'Apply crop', onclick: () => finish(true) })))));
      U.closePop(); U.$('#layer-sheet').append(wrap); IND.sheetOpen = true;
      const mo = new MutationObserver(() => { if (!wrap.isConnected) { mo.disconnect(); resolve(); } }); mo.observe(U.$('#layer-sheet'), { childList: true });
      fit(); draw();
    });
  };
})();
