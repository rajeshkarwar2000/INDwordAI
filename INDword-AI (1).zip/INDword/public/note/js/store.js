// Storage: IndexedDB for notes (large), localStorage for settings.
(function () {
  const S = (IND.store = {});
  let db;

  S.open = () => new Promise((res, rej) => {
    const r = indexedDB.open('indnote', 2);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('body')) d.createObjectStore('body', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('pdf')) d.createObjectStore('pdf');
    };
    r.onsuccess = () => { db = r.result; res(); };
    r.onerror = () => rej(r.error);
  });
  const tx = (stores, mode, fn) => new Promise((res, rej) => {
    const t = db.transaction(stores, mode); let out;
    t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    out = fn(t);
  });
  const req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

  S.listMeta = () => req(db.transaction('meta').objectStore('meta').getAll());
  S.getDoc = async (id) => {
    const t = db.transaction(['meta', 'body']);
    const [meta, body] = await Promise.all([req(t.objectStore('meta').get(id)), req(t.objectStore('body').get(id))]);
    if (!meta || !body) return null;
    return Object.assign({}, meta, { pages: body.pages });
  };
  S.saveDoc = (doc) => {
    const { pages, ...meta } = doc;
    meta.pageCount = pages.length;
    return tx(['meta', 'body'], 'readwrite', (t) => {
      t.objectStore('meta').put(meta);
      t.objectStore('body').put({ id: doc.id, pages });
    });
  };
  S.saveMetaOnly = (meta) => tx(['meta'], 'readwrite', (t) => { t.objectStore('meta').put(meta); });
  S.deleteDoc = (id) => tx(['meta', 'body', 'pdf'], 'readwrite', (t) => { t.objectStore('meta').delete(id); t.objectStore('body').delete(id); t.objectStore('pdf').delete(IDBKeyRange.bound(id + ':', id + ':\uffff')); });
  // original PDF files are kept untouched so pages can be redrawn sharply at any zoom
  S.putPdf = (docId, id, buf) => tx(['pdf'], 'readwrite', (t) => { t.objectStore('pdf').put(buf, docId + ':' + id); });
  S.getPdf = (docId, id) => req(db.transaction('pdf').objectStore('pdf').get(docId + ':' + id));

  // ---- settings ----
  const DEF = {
    toolbarPos: 'right',            // top | left | right | bottom | both
    toolOrder: ['pages', 'view', 'import', 'switch', 'move', 'undo', 'redo', 'mode', 'pen', 'brush', 'laser', 'highlighter', 'eraser', 'select', 'shapes', 'text', 'table', 'image', 'zoom'],
    hidden: [],
    theme: 'auto',                  // auto | light | dark
    glass: 'frosted', glassBlur: null, glassAlpha: null,
    palette: null, hlPalette: null, // user-arranged colour lists (null = defaults)
    quality: 'smooth',              // smooth: lighter rendering for lag-free drawing | sharp: full device resolution
    autosave: 30,                   // seconds between automatic saves (30 - 300)
    smooth: 'med',                  // pen smoothing: off | low | med | high
    fingerDraw: false,              // false: finger scrolls, stylus draws
    insertAt: 'after',              // after | before | first | last
    homeView: 'grid', homeSort: 'modified', favOnly: false,
    tools: null,                    // per-tool options (filled by editor)
    recent: [],
  };
  S.settings = Object.assign({}, DEF);
  S.loadSettings = () => {
    try { Object.assign(S.settings, JSON.parse(localStorage.getItem('indnote.settings') || '{}')); } catch (e) { /* ignore */ }
    // make sure newly added tools appear
    DEF.toolOrder.forEach((t) => { if (!S.settings.toolOrder.includes(t)) S.settings.toolOrder.push(t); });
    S.settings.toolOrder = S.settings.toolOrder.filter((t) => DEF.toolOrder.includes(t));
  };
  S.saveSettings = () => { try { localStorage.setItem('indnote.settings', JSON.stringify(S.settings)); } catch (e) { /* ignore */ } };
  // glass look: style preset plus optional blur / transparency overrides
  S.applyGlass = () => {
    const r = document.documentElement, st = S.settings;
    r.setAttribute('data-glass', st.glass || 'frosted');
    if (st.glassBlur == null) r.style.removeProperty('--blur-px'); else r.style.setProperty('--blur-px', st.glassBlur + 'px');
    if (st.glassAlpha == null) { r.style.removeProperty('--g-a'); r.style.removeProperty('--g-a2'); }
    else { r.style.setProperty('--g-a', st.glassAlpha); r.style.setProperty('--g-a2', Math.min(0.97, st.glassAlpha + 0.22)); }
  };
  S.applyTheme = () => {
    const t = S.settings.theme;
    if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t);
  };
})();
