// Boot
(function () {
  const U = IND.u, S = IND.store;
  IND.show = (name) => { U.$('#home').hidden = name !== 'home'; U.$('#editor').hidden = name !== 'editor'; IND.screen = name; };

  async function boot() {
    S.loadSettings(); S.applyTheme(); S.applyGlass();
    try { await S.open(); } catch (e) { document.body.textContent = 'Storage is unavailable: ' + e.message; return; }
    IND.home.init(); IND.show('home');

    // save when the app goes to the background
    document.addEventListener('visibilitychange', () => { if (document.hidden && IND.editor.doc) { IND.input.finishText(); IND.editor.save(); } });
    addEventListener('pagehide', () => { if (IND.editor.doc) IND.editor.save(); });

    // Android back button
    const cap = window.Capacitor, App = cap && cap.Plugins && cap.Plugins.App;
    // inside INDword the back button is shared: this app handles it only while Note mode is showing
    const inWord = window.parent !== window;
    const toWord = () => { try { window.parent.postMessage({ type: 'ind-switch', to: 'word' }, '*'); } catch (e) { /* ignore */ } };
    IND.toWord = toWord;
    if (App && App.addListener) App.addListener('backButton', () => {
      if (inWord && window.parent.__indMode !== 'note') return;
      if (IND.popOpen) return U.closePop();
      if (IND.sheetOpen) return U.closeSheet();
      if (IND.screen === 'editor') return IND.editor.close();
      if (inWord) return toWord();
      App.exitApp();
    });
    // INDword tells this page when it is hidden so unsaved work is stored
    addEventListener('message', (e) => { if (e.data && e.data.type === 'ind-hide' && IND.editor.doc) { IND.input.finishText(); IND.editor.save(); } });
    // keyboard shortcuts (useful with a keyboard cover)
    addEventListener('keydown', (e) => {
      if (IND.screen !== 'editor' || /TEXTAREA|INPUT/.test((e.target || {}).tagName || '')) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? IND.editor.redo() : IND.editor.undo(); }
      if (e.key === 'Delete' || e.key === 'Backspace') IND.editor.deleteSel();
    });
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  }
  boot();
})();
