// Pointer input: stylus drawing, finger pan / pinch zoom, eraser, select, shapes, text, table, laser.
(function () {
  const U = IND.u, h = U.h, S = IND.store, R = IND.render, T = IND.tools, E = IND.editor;
  const I = (IND.input = {});
  I.editing = null;

  const touches = new Map();
  let cur = null, lastPen = 0, pinch = null, lastTap = { t: 0, id: null }, raf = 0, flingRaf = 0;
  const vel = { vx: 0, vy: 0, t: 0 }, pan = { x: 0, y: 0, raf: 0 };
  function applyPan() { pan.raf = 0; E.stage.scrollLeft -= pan.x; E.stage.scrollTop -= pan.y; pan.x = pan.y = 0; }
  const laser = { g: null, strokes: [], cur: null, raf: 0 };

  const pageAt = (x, y) => {
    for (const g of E.pgs) { if (!g.live) continue; const r = g.el.getBoundingClientRect(); if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return g; }
    return null;
  };
  const toLogical = (g, e) => { const r = (cur && cur.g === g && cur.rect) || g.el.getBoundingClientRect(), p = E.doc.pages[g.idx], u = r.width / p.w; return { x: (e.clientX - r.left) / u, y: (e.clientY - r.top) / u, u }; };
  const cap = (id) => { try { E.stage.setPointerCapture(id); } catch (err) { /* synthetic or released pointer */ } };
  const pres = (e) => (e.pointerType === 'pen' && e.pressure > 0 ? e.pressure : 0.5);

  I.attach = function (stage) {
    stage.style.touchAction = 'none';
    stage.addEventListener('pointerdown', down);
    stage.addEventListener('pointermove', move);
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
    stage.addEventListener('contextmenu', (e) => e.preventDefault());
    stage.addEventListener('wheel', (e) => { if (e.ctrlKey) { e.preventDefault(); E.setZoom(E.zoom * (e.deltaY < 0 ? 1.1 : 0.9), e.clientX, e.clientY); } }, { passive: false });
  };

  // ============================================================ pointer down
  function down(e) {
    if (!E.doc) return;
    flingStop();
    if (e.target.closest && e.target.closest('.texted, .cell-in')) return;
    if (I.editing) I.finishText();
    if (I.cell) I.finishCell();
    if (IND.popOpen) U.closePop();

    if (e.pointerType === 'pen') lastPen = performance.now();
    const fingerOK = e.pointerType !== 'touch' || S.settings.fingerDraw;
    if (e.pointerType === 'touch') {
      if (!S.settings.fingerDraw && performance.now() - lastPen < 700) return; // palm rejection
      touches.set(e.pointerId, { x: e.clientX, y: e.clientY }); vel.vx = vel.vy = 0; vel.t = 0;
      if (touches.size >= 2) { cancelDraw(); startPinch(); return; }
      if (!fingerOK) { cap(e.pointerId); return; }
    }
    if (touches.size >= 2) return;
    let tool = T.active;
    if (e.pointerType === 'pen' && (e.buttons & 32 || e.button === 5)) tool = 'eraser';
    if (tool === 'laser') { cap(e.pointerId); beginLaser(e); return; }
    const g = pageAt(e.clientX, e.clientY); if (!g) return;
    cap(e.pointerId);
    begin(tool, g, e);
  }

  function begin(tool, g, e) {
    E.busy();
    const p = toLogical(g, e), cfg = T.cfg[tool] || {};
    E.curIdx = g.idx; E.updInd();
    cur = { tool, g, pi: g.idx, id: e.pointerId, u: p.u, x0: p.x, y0: p.y, moved: false, rect: g.el.getBoundingClientRect(), q: [] };
    if (tool === 'pen' || tool === 'brush' || tool === 'highlighter') {
      const kind = tool === 'highlighter' ? 'hl' : tool;
      const s = { id: U.uid(), t: 's', tool: kind, pts: [[p.x, p.y, pres(e)]], size: cfg.size, color: cfg.color, seed: (Math.random() * 1e9) | 0 };
      if (tool === 'pen') Object.assign(s, { pen: cfg.pen, line: cfg.line, space: cfg.space, nib: cfg.nib, angle: cfg.angle });
      if (tool === 'brush') s.brush = cfg.brush;
      if (tool === 'highlighter') { s.alpha = cfg.alpha; s.tip = cfg.tip || 'round'; s.straight = !!cfg.straight; g.live.style.mixBlendMode = 'multiply'; }
      cur.s = s; cur.st = R.newStrokeState(s); cur.drawn = 0; cur.f = { x: p.x, y: p.y, t: e.timeStamp || performance.now(), dx: 0, dy: 0 }; cur.lastRaw = { x: p.x, y: p.y };
      E.select(g.idx, null); E.clearLive(g);
      liveStroke();
    } else if (tool === 'eraser') {
      cur.pushed = false; eraseAt(p, false); drawEraserCursor(p);
    } else if (tool === 'select') {
      selectDown(g, p);
    } else if (tool === 'shapes' || tool === 'table' || tool === 'text') {
      cur.x1 = p.x; cur.y1 = p.y; cur.x2 = p.x; cur.y2 = p.y;
    }
  }

  // ============================================================ pen smoothing (One-Euro filter)
  // Removes sensor and hand jitter on slow strokes while staying responsive on fast ones.
  const SMOOTH = { off: null, low: { min: 6, beta: 0.03 }, med: { min: 3.2, beta: 0.02 }, high: { min: 1.8, beta: 0.012 } };
  const lpa = (cut, dt) => 1 / (1 + 1 / (2 * Math.PI * cut) / dt);
  function smoothPt(f, x, y, t, u) {
    const k = SMOOTH[S.settings.smooth || 'med'];
    if (!k || f.x == null) { f.x = x; f.y = y; f.t = t; f.dx = 0; f.dy = 0; return [x, y]; }
    const dt = Math.min(0.1, Math.max(0.002, (t - f.t) / 1000)); f.t = t;
    const a0 = lpa(1.2, dt), vx = (x - f.x) * u / dt, vy = (y - f.y) * u / dt;
    f.dx += a0 * (vx - f.dx); f.dy += a0 * (vy - f.dy);
    const a = lpa(k.min + k.beta * Math.hypot(f.dx, f.dy), dt);
    f.x += a * (x - f.x); f.y += a * (y - f.y);
    return [f.x, f.y];
  }

  // ============================================================ move
  function move(e) {
    if (e.pointerType === 'touch' && touches.has(e.pointerId)) {
      const prev = touches.get(e.pointerId); touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch) { updatePinch(); return; }
      if (!cur) {
        const dx = e.clientX - prev.x, dy = e.clientY - prev.y, now = performance.now(), dt = Math.max(1, now - (vel.t || now - 16));
        pan.x += dx; pan.y += dy; if (!pan.raf) pan.raf = requestAnimationFrame(applyPan);
        vel.vx = vel.vx * 0.55 + (dx / dt) * 0.45; vel.vy = vel.vy * 0.55 + (dy / dt) * 0.45; vel.t = now; return;
      }
    }
    if (!cur || cur.id !== e.pointerId) return;
    E.busy();
    const g = cur.g, evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [];
    const list = evs.length ? evs : [e];
    if (cur.tool === 'laser') { const ls = laser.cur, r = laser.rect, now = performance.now(); if (ls) for (const ev of list) { const q = { x: ev.clientX - r.left, y: ev.clientY - r.top, t: now }; if (ls.mode === 'dot') ls.pts = [q]; else { const l = ls.pts[ls.pts.length - 1]; if (Math.hypot(q.x - l.x, q.y - l.y) >= 1.2) ls.pts.push(q); else l.t = now; } } return; }
    for (const ev of list) step(g, ev);
  }
  function step(g, ev) {
    const p = toLogical(g, ev), t = cur.tool;
    if (!cur.moved && Math.hypot(p.x - cur.x0, p.y - cur.y0) * cur.u > 4) cur.moved = true;
    if (cur.s) {
      const s = cur.s;
      if (s.straight) { // keep only the start and the current end, snapped to horizontal / vertical when close
        let x = p.x, y = p.y; const a = s.pts[0], dx = x - a[0], dy = y - a[1], L = Math.hypot(dx, dy);
        if (L > 8 / cur.u) { const ang = Math.abs(Math.atan2(dy, dx)); if (ang < 0.07 || ang > Math.PI - 0.07) y = a[1]; else if (Math.abs(ang - Math.PI / 2) < 0.07) x = a[0]; }
        s.pts = [a, [x, y, 0.5]];
      } else {
        cur.lastRaw = { x: p.x, y: p.y };
        const q = smoothPt(cur.f, p.x, p.y, ev.timeStamp || performance.now(), cur.u);
        const l = s.pts[s.pts.length - 1];
        if (s.pts.length < 2 || Math.hypot(q[0] - l[0], q[1] - l[1]) * cur.u >= 1.4) s.pts.push([q[0], q[1], pres(ev)]);
      }
      sched();
    }
    else if (t === 'eraser') { cur.q.push(p); sched(); }
    else if (t === 'select') { cur.last = p; sched(); }
    else if (t === 'shapes' || t === 'table' || t === 'text') { cur.x2 = p.x; cur.y2 = p.y; sched(); }
  }
  // draw at most once per screen frame, however many pen samples arrived
  function sched() { if (!raf) raf = requestAnimationFrame(frame); }
  function frame() {
    raf = 0; if (!cur) return; const t = cur.tool;
    if (cur.s) liveStroke();
    else if (t === 'eraser') {
      const q = cur.q; cur.q = []; for (const p of q) eraseAt(p, true);
      if (cur.dirtyPage) { E.renderPage(cur.pi); cur.dirtyPage = false; }
      if (q.length) drawEraserCursor(q[q.length - 1]);
    } else if (t === 'select') { if (cur.last) selectMove(cur.g, cur.last); }
    else if (t === 'shapes' || t === 'table' || t === 'text') drawCreating(cur.g);
  }

  // ============================================================ up
  function up(e) {
    if (e.pointerType === 'touch') {
      touches.delete(e.pointerId);
      if (pinch && touches.size < 2) { applyPinch(); vel.vx = vel.vy = 0; }
      else if (!cur && touches.size === 0 && performance.now() - vel.t < 90 && Math.hypot(vel.vx, vel.vy) > 0.25) fling();
    }
    if (!cur || cur.id !== e.pointerId) return;
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    frame();
    const c = cur; cur = null;
    const g = c.g, t = c.tool;
    if (c.s && c.lastRaw && !c.s.straight) { const l = c.s.pts[c.s.pts.length - 1]; if (Math.hypot(c.lastRaw.x - l[0], c.lastRaw.y - l[1]) * c.u > 0.6) c.s.pts.push([c.lastRaw.x, c.lastRaw.y, l[2]]); }
    if (c.s) commitStroke(c);
    else if (t === 'eraser') { E.clearLive(g); if (c.pushed) { E.dirty(); } }
    else if (t === 'laser') { if (laser.cur) { laser.cur.end = performance.now(); laser.cur = null; } }
    else if (t === 'select') selectUp(c);
    else if (t === 'shapes') commitShape(c);
    else if (t === 'table') commitTable(c);
    else if (t === 'text') { E.clearLive(g); if (!c.moved || (c.x2 - c.x1) * c.u < 40) openTextAt(g, c.x0, c.y0); else openTextEdit(g, null, Math.min(c.x1, c.x2), Math.min(c.y1, c.y2), Math.abs(c.x2 - c.x1)); }
  }
  function cancelDraw() {
    if (!cur) return; const g = cur.g; const wasLaser = cur.tool === 'laser'; cur = null;
    if (wasLaser && laser.cur) { laser.cur.end = performance.now(); laser.cur = null; return; }
    if (g && g.live) { E.clearLive(g); g.live.style.mixBlendMode = ''; E.renderPage(g); }
  }

  // ============================================================ strokes
  function liveStroke() {
    const g = cur.g, s = cur.s, ctx = E.liveCtx(g);
    if (s.tool === 'hl' || (s.tool === 'pen' && s.line && s.line !== 'solid')) {
      // clear only the area the stroke covers (not the whole page-sized canvas) before redrawing it
      const bb = cur.bb || (cur.bb = [1e9, 1e9, -1e9, -1e9]), pad = s.size + 4;
      for (let i = cur.drawn || 0; i < s.pts.length; i++) { const q = s.pts[i]; if (q[0] < bb[0]) bb[0] = q[0]; if (q[1] < bb[1]) bb[1] = q[1]; if (q[0] > bb[2]) bb[2] = q[0]; if (q[1] > bb[3]) bb[3] = q[1]; }
      const pv = cur.pb || bb; cur.pb = bb.slice();
      const x0 = Math.min(pv[0], bb[0]) - pad, y0 = Math.min(pv[1], bb[1]) - pad, x1 = Math.max(pv[2], bb[2]) + pad, y1 = Math.max(pv[3], bb[3]) + pad;
      if (s.straight) { ctx.clearRect(x0 - pad * 2, y0 - pad * 2, x1 - x0 + pad * 4, y1 - y0 + pad * 4); } else ctx.clearRect(x0, y0, x1 - x0, y1 - y0);
      cur.drawn = s.pts.length; R.drawStroke(ctx, s, 0, null, true); return;
    }
    R.drawStroke(ctx, s, cur.drawn, cur.st, true); cur.drawn = s.pts.length;
  }
  function commitStroke(c) {
    const s = c.s, g = c.g;
    if (s.pts.length === 1 && s.pen) s.pts.push([s.pts[0][0] + 0.01, s.pts[0][1], s.pts[0][2]]);
    E.push(); E.setObjs(c.pi, [...E.doc.pages[c.pi].objs, s]);
    // paint the finished stroke straight onto the page bitmap and clear the live layer in the same frame: no flash or blink
    if (g.base && g.live) {
      const bc = g.base.getContext('2d'); bc.save(); bc.setTransform(g.k, 0, 0, g.k, -(g.offX || 0), -(g.offY || 0)); R.drawStroke(bc, s, 0, null, false); bc.restore();
      E.clearLive(g); g.live.style.mixBlendMode = '';
    } else E.renderPage(g);
    E.dirty();
  }

  // ============================================================ eraser
  const densify = (pts, gap) => {
    const out = [pts[0]];
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i], d = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.ceil(d / gap);
      for (let k = 1; k <= n; k++) { const f = k / n; out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f]); }
    }
    return out;
  };
  function eraseAt(p, defer) {
    const cfg = T.cfg.eraser, r = cfg.size / 2, objs = E.doc.pages[cur.pi].objs; let changed = false; const out = [];
    for (const o of objs) {
      if (!R.hit(o, p.x, p.y, r)) { out.push(o); continue; }
      if (cfg.mode === 'pixel' && o.t === 's') {
        const lim = r + o.size / 2, dp = densify(o.pts, Math.max(2, o.size / 3)), runs = []; let run = [];
        for (const q of dp) { if (Math.hypot(q[0] - p.x, q[1] - p.y) <= lim) { if (run.length) runs.push(run); run = []; } else run.push(q); }
        if (run.length) runs.push(run);
        if (runs.length === 1 && runs[0].length === dp.length) { out.push(o); continue; }
        runs.forEach((rn) => out.push(Object.assign({}, o, { id: U.uid(), pts: rn })));
        changed = true;
      } else changed = true;
    }
    if (changed) {
      if (!cur.pushed) { E.push(); cur.pushed = true; }
      E.setObjs(cur.pi, out); cur.dirtyPage = true; if (!defer) { E.renderPage(cur.pi); cur.dirtyPage = false; }
    }
  }
  function drawEraserCursor(p) {
    const g = cur.g, ctx = E.liveCtx(g), rr = T.cfg.eraser.size / 2 + 6;
    if (cur.ec) ctx.clearRect(cur.ec.x - rr, cur.ec.y - rr, rr * 2, rr * 2); else E.clearLive(g);
    cur.ec = { x: p.x, y: p.y };
    ctx.save(); ctx.strokeStyle = 'rgba(60,70,90,.85)'; ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2 / cur.u;
    ctx.beginPath(); ctx.arc(p.x, p.y, T.cfg.eraser.size / 2, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ============================================================ laser pointer
  // Like Notewise: a glowing dot follows the pen and leaves a neon trail.
  //  trail: the trail fades from its tail while you move, and what is left disappears after you lift
  //  hold : the drawn line stays for a few seconds after you lift, then fades; every stroke has its own timer
  //  dot  : just the glowing dot
  // It lives on its own screen-space canvas above the pages, so nothing else can wipe it.
  function beginLaser(e) {
    const lc = T.cfg.laser, r = E.stage.getBoundingClientRect(), now = performance.now();
    cur = { tool: 'laser', id: e.pointerId, g: null, u: 1, moved: false, x0: e.clientX, y0: e.clientY, q: [] };
    laser.rect = r;
    const ls = { pts: [{ x: e.clientX - r.left, y: e.clientY - r.top, t: now }], end: 0, mode: lc.mode === 'delay' ? 'hold' : lc.mode === 'line' ? 'trail' : lc.mode, color: lc.color, size: lc.size, delay: lc.delay, trail: lc.trail || 650 };
    laser.strokes.push(ls); laser.cur = ls; laserLoop();
  }
  function laserLoop() {
    if (laser.raf) return;
    const cv = E.laserCv; if (!cv) return;
    const tick = () => {
      laser.raf = 0;
      const dpr = Math.min(window.devicePixelRatio || 1, 2), w = E.stage.clientWidth, hh = E.stage.clientHeight;
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(hh * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr); }
      const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const now = performance.now(), live = [];
      for (const st of laser.strokes) {
        const down = !st.end, since = now - st.end, sz = st.size * 0.8, last = st.pts[st.pts.length - 1];
        if (st.mode === 'dot') {
          if (!down && since > 220) continue; live.push(st);
          R.drawLaser(ctx, [], null, st.color, sz, { head: { x: last.x, y: last.y, a: down ? 1 : 1 - since / 220 } });
        } else if (st.mode === 'hold') {
          const fade = down ? 1 : (since - st.delay * 1000 <= 0 ? 1 : 1 - (since - st.delay * 1000) / 650);
          if (fade <= 0) continue; live.push(st);
          R.drawLaser(ctx, st.pts, null, st.color, sz, { alpha: fade, head: down ? { x: last.x, y: last.y, a: 1 } : null });
        } else { // trail
          const TRAIL = st.trail; if (!down && since > TRAIL + 60) continue; live.push(st);
          while (st.pts.length > 2 && now - st.pts[0].t > TRAIL + 60) st.pts.shift();
          const al = st.pts.map((q) => { const a = 1 - (now - q.t) / TRAIL; return a <= 0 ? 0 : Math.pow(a, 1.25); });
          R.drawLaser(ctx, st.pts, al, st.color, sz, { taper: true, head: down ? { x: last.x, y: last.y, a: 1 } : (since < 150 ? { x: last.x, y: last.y, a: 1 - since / 150 } : null) });
        }
      }
      laser.strokes = live;
      if (live.length) laser.raf = requestAnimationFrame(tick); else ctx.clearRect(0, 0, w, hh);
    };
    laser.raf = requestAnimationFrame(tick);
  }
  I.laserStop = function () { laser.strokes = []; laser.cur = null; if (E.laserCv) { const c = E.laserCv.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, E.laserCv.width, E.laserCv.height); } };

  // ============================================================ finger momentum
  function flingStop() { if (flingRaf) { cancelAnimationFrame(flingRaf); flingRaf = 0; } }
  function fling() {
    flingStop(); let last = performance.now();
    const tick = (t) => {
      const dt = Math.min(40, t - last); last = t;
      E.stage.scrollLeft -= vel.vx * dt; E.stage.scrollTop -= vel.vy * dt;
      const f = Math.exp(-dt / 330); vel.vx *= f; vel.vy *= f;
      flingRaf = Math.hypot(vel.vx, vel.vy) > 0.02 ? requestAnimationFrame(tick) : 0;
    };
    flingRaf = requestAnimationFrame(tick);
  }

  // ============================================================ shapes / tables
  const snapLine = (c) => { // lines snap to horizontal / vertical / 45 degrees when close
    let dx = c.x2 - c.x1, dy = c.y2 - c.y1; const L = Math.hypot(dx, dy); if (!L) return;
    const a = Math.atan2(dy, dx), q = Math.PI / 4, n = Math.round(a / q);
    if (Math.abs(a - n * q) < 0.09) { c.x2 = c.x1 + L * Math.cos(n * q); c.y2 = c.y1 + L * Math.sin(n * q); }
  };
  const shapeObj = (c, id) => {
    const k = T.cfg.shapes;
    return { id, t: 'shape', kind: k.kind, x1: c.x1, y1: c.y1, x2: c.x2, y2: c.y2, color: k.color, bw: k.bw, fill: k.fill, fillColor: k.fillColor || null, dash: k.dash, op: k.op };
  };
  function drawCreating(g) {
    E.clearLive(g); const ctx = E.liveCtx(g), c = cur;
    if (c.tool === 'shapes') { if (R.isLineShape(T.cfg.shapes.kind)) snapLine(c); R.drawObj(ctx, shapeObj(c)); }
    else {
      const x = Math.min(c.x1, c.x2), y = Math.min(c.y1, c.y2), w = Math.abs(c.x2 - c.x1), hh = Math.abs(c.y2 - c.y1);
      ctx.save(); ctx.strokeStyle = c.tool === 'text' ? '#0a84ff' : T.cfg.table.color; ctx.lineWidth = 3 / c.u; ctx.setLineDash([10 / c.u, 7 / c.u]);
      ctx.strokeRect(x, y, c.tool === 'text' ? w : w, c.tool === 'text' ? Math.max(hh, T.cfg.text.size * 1.25) : hh); ctx.restore();
    }
  }
  function commitShape(c) {
    const g = c.g; E.clearLive(g);
    const pg = E.doc.pages[c.pi];
    if (Math.hypot(c.x2 - c.x1, c.y2 - c.y1) * c.u < 10) { // a tap places a default-size shape
      const d = 220, k = T.cfg.shapes.kind;
      c.x1 = Math.max(10, Math.min(pg.w - d - 10, c.x0 - (R.isLineShape(k) ? d / 2 : d / 2))); c.y1 = c.y0 - d / 2 + (R.isLineShape(k) ? d / 2 : 0);
      c.x2 = c.x1 + d; c.y2 = R.isLineShape(k) ? c.y1 : c.y1 + d * 0.7;
    } else if (R.isLineShape(T.cfg.shapes.kind)) snapLine(c);
    const o = shapeObj(c, U.uid());
    E.push(); E.setObjs(c.pi, [...pg.objs, o]); E.dirty(); E.renderPage(c.pi);
    // the shape tool stays active so several shapes can be drawn; double-tap with Select to edit
  }
  function commitTable(c) {
    const k = T.cfg.table, g = c.g; E.clearLive(g);
    const pg = E.doc.pages[c.pi];
    let x = Math.min(c.x1, c.x2), y = Math.min(c.y1, c.y2), w = Math.abs(c.x2 - c.x1), h_ = Math.abs(c.y2 - c.y1);
    if (w * c.u < 30 || h_ * c.u < 30) { x = c.x0; y = c.y0; w = Math.min(760, pg.w - x - 20); h_ = 0; }
    const o = R.newTable(Math.max(0, x), Math.max(0, y), Math.max(120, w), Math.max(60, h_), k);
    E.push(); E.setObjs(c.pi, [...pg.objs, o]); E.dirty(); finishCreate(c.pi, o);
  }
  function finishCreate(pi, o) { T.setTool('select'); E.sel = { pi, id: o.id }; E.renderPage(pi); }
  I.insertObject = function (o, pi) { E.push(); E.setObjs(pi, [...E.doc.pages[pi].objs, o]); E.dirty(); finishCreate(pi, o); };

  // ============================================================ select
  function selectDown(g, p) {
    const sel = E.selObj(), pi = g.idx;
    if (sel && E.sel.pi === pi) {
      const hd = E.handles(g, sel);
      if (Math.hypot(p.x - hd.del[0], p.y - hd.del[1]) <= hd.r) { cur.mode = 'delete'; return; }
      if (hd.ep) for (let i = 0; i < 2; i++) if (Math.hypot(p.x - hd.ep[i][0], p.y - hd.ep[i][1]) <= hd.r) { cur.mode = 'endpoint'; cur.ei = i; cur.o0 = sel; startDrag(g, sel); return; }
      if (Math.hypot(p.x - hd.size[0], p.y - hd.size[1]) <= hd.r) { cur.mode = 'resize'; cur.o0 = sel; cur.b0 = R.bbox(sel); startDrag(g, sel); return; }
    }
    const objs = E.doc.pages[pi].objs; let hit = null;
    for (let i = objs.length - 1; i >= 0; i--) if (R.hit(objs[i], p.x, p.y, 10 / p.u)) { hit = objs[i]; break; }
    if (!hit) { cur.mode = 'none'; cur.wasSel = !!sel; E.select(pi, null); return; }
    const wasSame = sel && sel.id === hit.id;
    E.select(pi, hit.id); cur.mode = 'move'; cur.o0 = hit; cur.wasSame = wasSame; startDrag(g, hit);
  }
  function startDrag(g, o) { cur.dragging = false; cur.g = g; cur.baseDone = false; cur.cur = o; }
  function selectMove(g, p) {
    const m = cur.mode; if (m !== 'move' && m !== 'resize' && m !== 'endpoint') return;
    if (!cur.moved) return;
    if (!cur.baseDone) { E.renderPage(g, cur.o0.id); cur.baseDone = true; }
    const o0 = cur.o0; let o;
    if (m === 'move') o = R.transform(o0, 0, 0, 1, 1, p.x - cur.x0, p.y - cur.y0);
    else if (m === 'endpoint') { o = Object.assign({}, o0); const k = cur.ei ? ['x2', 'y2'] : ['x1', 'y1']; o[k[0]] = p.x; o[k[1]] = p.y; const f = cur.ei ? [o.x1, o.y1] : [o.x2, o.y2]; const dx = o.x2 - o.x1, dy = o.y2 - o.y1, L = Math.hypot(dx, dy), q = Math.PI / 4, n = Math.round(Math.atan2(dy, dx) / q); if (L && Math.abs(Math.atan2(dy, dx) - n * q) < 0.09) { if (cur.ei) { o.x2 = o.x1 + L * Math.cos(n * q); o.y2 = o.y1 + L * Math.sin(n * q); } else { o.x1 = o.x2 - L * Math.cos(n * q); o.y1 = o.y2 - L * Math.sin(n * q); } } void f; }
    else if (o0.t === 'text') { o = Object.assign({}, o0, { fw: Math.max(40, p.x - o0.x) }); R.measureText(o); }
    else if (o0.t === 'table') { const b = cur.b0; o = Object.assign({}, o0, { w: Math.max(60, p.x - b.x), h: Math.max(R.minTableHeight(o0), p.y - b.y) }); }
    else {
      const b = cur.b0; let sx = Math.max(0.1, (p.x - b.x) / b.w), sy = Math.max(0.1, (p.y - b.y) / b.h);
      if (o0.t === 's' || o0.t === 'text' || o0.t === 'img') { sx = sy = Math.max(0.1, (sx + sy) / 2); }
      o = R.transform(o0, b.x, b.y, sx, sy, 0, 0);
    }
    cur.cur = o;
    E.drawOverlay(g, o); const ctx = E.liveCtx(g); ctx.save(); ctx.globalCompositeOperation = 'destination-over'; R.drawObj(ctx, o); ctx.restore();
  }
  function selectUp(c) {
    const g = c.g, pi = c.pi;
    if (c.mode === 'delete') { E.deleteSel(); return; }
    if (c.mode === 'none') return;
    if (c.moved && c.cur && c.baseDone) {
      E.push(); E.setObjs(pi, E.doc.pages[pi].objs.map((x) => (x.id === c.o0.id ? c.cur : x))); E.renderPage(pi); E.dirty(); return;
    }
    // simple tap on an object
    const o = c.o0, now = performance.now();
    const dbl = lastTap.id === o.id && now - lastTap.t < 420; lastTap = { t: now, id: o.id };
    if (c.mode === 'move' && (dbl || c.wasSame)) {
      if (o.t === 'text') { openTextEdit(g, o); return; }
      if (o.t === 'table') { editCell(g, o, c.x0, c.y0); return; }
      if (o.t === 'img' && IND.crop) { IND.crop.open(o, pi); return; }
    }
    E.drawOverlay(g);
  }

  // ============================================================ text
  function openTextAt(g, x, y) {
    const pi = g.idx, objs = E.doc.pages[pi].objs;
    for (let i = objs.length - 1; i >= 0; i--) if (objs[i].t === 'text' && R.hit(objs[i], x, y, 6)) { openTextEdit(g, objs[i]); return; }
    openTextEdit(g, null, x, y);
  }
  function openTextEdit(g, o, x, y, fw) {
    const pi = g.idx, st = o ? { size: o.size, color: o.color, font: o.font, b: o.b, i: o.i, u: o.u, align: o.align, lh: o.lh, bg: o.bg, bgA: o.bgA, fw: o.fw } : Object.assign({}, T.cfg.text, { fw: fw || null });
    if (!o && !st.bg) st.bg = null;
    const u = (parseFloat(g.el.style.width) || g.el.clientWidth) / E.doc.pages[pi].w;
    const ta = h('textarea', { class: 'texted', wrap: 'off', spellcheck: 'false', rows: 1, id: 'text-edit' });
    ta.value = o ? o.text : '';
    I.editing = { g, pi, o, ta, st, x: o ? o.x : x, y: o ? o.y : y, u };
    if (o) { E.sel = null; E.renderPage(pi, o.id); E.clearLive(g); }
    g.el.append(ta); styleTA(); ta.focus();
    ta.addEventListener('input', styleTA);
    ta.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') ta.blur(); });
    ta.addEventListener('blur', () => setTimeout(() => { if (I.editing && I.editing.ta === ta) I.finishText(); }, 80));
  }
  function styleTA() {
    const ed = I.editing; if (!ed) return; const { ta, st, u } = ed;
    ta.style.left = ed.x * u + 'px'; ta.style.top = ed.y * u + 'px';
    ta.style.font = R.fontStr(st).replace(/^(italic )?(700 |400 )?\d+(\.\d+)?px/, (m, a, b) => (a || '') + (b || '') + st.size * u + 'px');
    ta.style.color = st.color; ta.style.textDecoration = st.u ? 'underline' : 'none'; ta.style.textAlign = st.align || 'left';
    const pad = st.bg ? st.size * 0.35 : 0, lh = st.lh || 1.25;
    ta.style.padding = pad * u + 'px'; ta.style.boxSizing = 'border-box'; ta.style.lineHeight = lh;
    ta.style.background = st.bg ? st.bg : 'rgba(255,255,255,.7)';
    ta.style.whiteSpace = st.fw ? 'pre-wrap' : 'pre'; ta.setAttribute('wrap', st.fw ? 'soft' : 'off');
    const tmp = { text: ta.value || ' ', size: st.size, font: st.font, b: st.b, i: st.i, fw: st.fw, bg: st.bg, lh: st.lh }; R.measureText(tmp);
    ta.style.width = (st.fw ? st.fw : tmp.w + st.size * 0.8) * u + 'px'; ta.style.height = (tmp.h + st.size * 0.1) * u + 'px';
  }
  I.openText = (pi, o) => { const g = E.pgs[pi]; if (g) openTextEdit(g, o); };
  I.restyleText = function (patch) { if (!I.editing) return; Object.assign(I.editing.st, patch); styleTA(); };
  I.finishText = function () {
    const ed = I.editing; if (!ed) return; I.editing = null;
    const { g, pi, o, ta, st } = ed, text = ta.value.replace(/\s+$/, ''); ta.remove();
    if (!E.doc) return;
    if (!text.trim()) { if (o) { E.push(); E.setObjs(pi, E.doc.pages[pi].objs.filter((x) => x.id !== o.id)); E.dirty(); } E.renderPage(pi); return; }
    const n = Object.assign({}, o || { id: U.uid(), t: 'text' }, { x: ed.x, y: ed.y, text }, st); if (!n.fw) delete n.fw; if (!n.bg) delete n.bg; R.measureText(n);
    E.push();
    E.setObjs(pi, o ? E.doc.pages[pi].objs.map((x) => (x.id === o.id ? n : x)) : [...E.doc.pages[pi].objs, n]);
    E.sel = { pi, id: n.id }; E.renderPage(pi); E.dirty();
  };

  // ============================================================ table cell editing
  function editCell(g, o, x, y) {
    const pi = g.idx, u = (parseFloat(g.el.style.width) || g.el.clientWidth) / E.doc.pages[pi].w;
    const cw = o.w / o.cols, rh = o.h / o.rows;
    const c = U.clamp(Math.floor((x - o.x) / cw), 0, o.cols - 1), r = U.clamp(Math.floor((y - o.y) / rh), 0, o.rows - 1);
    const inp = h('textarea', { class: 'cell-in', id: 'cell-edit', spellcheck: 'false' });
    inp.value = o.cells[r][c];
    inp.style.left = (o.x + c * cw) * u + 'px'; inp.style.top = (o.y + r * rh) * u + 'px'; inp.style.width = cw * u + 'px'; inp.style.height = rh * u + 'px';
    inp.style.fontSize = o.fs * u + 'px'; inp.style.padding = o.spacing * u + 'px'; inp.style.fontFamily = 'Inter,sans-serif'; inp.style.textAlign = o.align;
    g.el.append(inp); inp.focus();
    I.cell = { g, pi, id: o.id, r, c, inp };
    inp.addEventListener('blur', () => setTimeout(() => { if (I.cell && I.cell.inp === inp) I.finishCell(); }, 80));
  }
  I.finishCell = function () {
    const k = I.cell; if (!k) return; I.cell = null; const v = k.inp.value; k.inp.remove();
    const o = E.doc.pages[k.pi].objs.find((x) => x.id === k.id); if (!o || o.cells[k.r][k.c] === v) return;
    const cells = o.cells.map((row) => row.slice()); cells[k.r][k.c] = v; E.updateObj(k.pi, k.id, { cells });
  };

  // ============================================================ pinch zoom (two fingers)
  // While the fingers move, the pages are only scaled by the GPU (no layout, no redraw, no lag). The sharp redraw happens once when the fingers lift.
  function startPinch() {
    const pts = [...touches.values()]; if (pts.length < 2) return;
    const [a, b] = pts, r = E.inner.getBoundingClientRect(), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
    if (pan.raf) { cancelAnimationFrame(pan.raf); applyPan(); }
    pinch = { d: Math.max(10, Math.hypot(a.x - b.x, a.y - b.y)), z0: E.zoom, z: E.zoom, cx0: cx, cy0: cy, cx, cy, ox: cx - r.left, oy: cy - r.top, raf: 0 };
    E.inner.style.transformOrigin = pinch.ox + 'px ' + pinch.oy + 'px'; E.inner.style.willChange = 'transform';
  }
  function updatePinch() {
    const pts = [...touches.values()]; if (pts.length < 2 || !pinch) return; const [a, b] = pts;
    const d = Math.hypot(a.x - b.x, a.y - b.y); pinch.cx = (a.x + b.x) / 2; pinch.cy = (a.y + b.y) / 2;
    pinch.z = U.clamp(pinch.z0 * d / pinch.d, 0.4, 6);
    if (!pinch.raf) pinch.raf = requestAnimationFrame(() => { if (!pinch) return; pinch.raf = 0; E.inner.style.transform = 'translate(' + (pinch.cx - pinch.cx0) + 'px,' + (pinch.cy - pinch.cy0) + 'px) scale(' + pinch.z / pinch.z0 + ')'; E.zoomChip.textContent = Math.round(pinch.z * 100) + '%'; });
  }
  function applyPinch() {
    if (!pinch) return; const p = pinch; pinch = null; if (p.raf) cancelAnimationFrame(p.raf);
    E.inner.style.transform = ''; E.inner.style.willChange = ''; E.inner.style.transformOrigin = '';
    E.stage.scrollLeft -= p.cx - p.cx0; E.stage.scrollTop -= p.cy - p.cy0;
    E.setZoom(p.z, p.cx, p.cy);
  }
})();
