# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.
