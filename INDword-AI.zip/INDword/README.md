# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Needs a free Gemini API key and internet. Generated PYQ labels must be verified.
