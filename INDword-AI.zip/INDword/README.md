# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.

## Notes pages
Notes documents use a real paged layout (Notes tab > Notes Page): A4 cards with gaps, dashed border, header, footer, page numbers and the indIAS logo background. Text fills column 1, then column 2, then the next page. PDF export renders page by page.

## Save to…
Export (PDF, Word, etc.) opens Android's own "Save to" window so you choose the folder. The small native plugin is copied in automatically by the `capacitor:*:after` scripts in package.json (see scripts-native.cjs and resources/native). If it is missing, the app falls back to the share sheet.
