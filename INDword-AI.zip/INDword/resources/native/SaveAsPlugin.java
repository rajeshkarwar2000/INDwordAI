package com.indword.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

@CapacitorPlugin(name = "SaveAs")
public class SaveAsPlugin extends Plugin {

    // the file waits here until the user has chosen where to save it
    private File pendingFile = null;

    @PluginMethod
    public void saveFromFile(PluginCall call) {
        String path = call.getString("path");
        String name = call.getString("name", "document");
        String mime = call.getString("mime", "application/octet-stream");
        if (path == null) {
            call.reject("No file path");
            return;
        }
        File f = new File(path);
        if (!f.exists() || f.length() == 0) {
            call.reject("The file is empty");
            return;
        }
        pendingFile = f;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "saveResult");
    }

    @ActivityCallback
    private void saveResult(PluginCall call, ActivityResult result) {
        File f = pendingFile;
        pendingFile = null;
        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null || f == null) {
            ret.put("saved", false);
            if (call != null) {
                call.resolve(ret);
            }
            return;
        }
        try {
            Uri uri = result.getData().getData();
            FileInputStream in = new FileInputStream(f);
            OutputStream out = getContext().getContentResolver().openOutputStream(uri, "wt");
            byte[] buf = new byte[65536];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            out.flush();
            out.close();
            in.close();
            ret.put("saved", true);
            ret.put("bytes", total);
            if (call != null) {
                call.resolve(ret);
            }
        } catch (Exception e) {
            if (call != null) {
                call.reject("Could not save: " + e.getMessage());
            }
        }
    }
}
