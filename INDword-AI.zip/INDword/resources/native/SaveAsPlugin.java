package com.indword.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;

@CapacitorPlugin(name = "SaveAs")
public class SaveAsPlugin extends Plugin {

    // the file content is kept here until the user has chosen where to save it
    private byte[] pending = null;

    @PluginMethod
    public void save(PluginCall call) {
        String name = call.getString("name", "document");
        String mime = call.getString("mime", "application/octet-stream");
        String data = call.getString("data");
        if (data == null || data.length() == 0) {
            call.reject("No data");
            return;
        }
        try {
            pending = Base64.decode(data, Base64.DEFAULT);
        } catch (Exception e) {
            call.reject("Bad data: " + e.getMessage());
            return;
        }
        if (pending.length == 0) {
            call.reject("The file is empty");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "saveResult");
    }

    @ActivityCallback
    private void saveResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }
        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null || pending == null) {
            pending = null;
            ret.put("saved", false);
            call.resolve(ret);
            return;
        }
        try {
            Uri uri = result.getData().getData();
            OutputStream os = getContext().getContentResolver().openOutputStream(uri, "wt");
            os.write(pending);
            os.flush();
            os.close();
            ret.put("saved", true);
            ret.put("bytes", pending.length);
            pending = null;
            call.resolve(ret);
        } catch (Exception e) {
            pending = null;
            call.reject("Could not save: " + e.getMessage());
        }
    }
}
