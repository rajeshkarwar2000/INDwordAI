const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
let lastLevels = 3;

export function headings(editor, lv) {
  const out = [];
  editor.state.doc.descendants((n) => {
    if (n.type.name === 'toc') return false;
    if (n.type.name === 'heading' && n.attrs.level <= lv && n.textContent.trim()) out.push({ level: n.attrs.level, text: n.textContent });
    return true;
  });
  return out;
}
const tocHtml = (items) => `<div data-toc><p><strong>Table of Contents</strong></p>${(items.length ? items : [{ level: 1, text: 'Add headings, then choose Update Table' }]).map((h) => `<p style="margin-left:${(h.level - 1) * 24}px">${esc(h.text)}</p>`).join('')}</div>`;

export function insertToc(editor, lv = 3) { lastLevels = lv; editor.chain().focus().insertContent(tocHtml(headings(editor, lv))).run(); }
function findToc(editor) { let f = null; editor.state.doc.descendants((n, pos) => { if (n.type.name === 'toc') { f = { from: pos, to: pos + n.nodeSize }; return false; } return true; }); return f; }
export function updateToc(editor) { const f = findToc(editor); if (!f) return false; editor.chain().focus().insertContentAt(f, tocHtml(headings(editor, lastLevels))).run(); return true; }
export function removeToc(editor) { const f = findToc(editor); if (!f) return false; editor.chain().focus().deleteRange(f).run(); return true; }

/* Footnotes: numbered [n] markers and notes appended at the end of the document */
export function footnoteMarkers(editor) {
  const out = [];
  editor.state.doc.descendants((n, pos) => {
    if (n.isText && n.marks.some((m) => m.type.name === 'superscript') && /^\[\d+\]$/.test(n.text)) out.push(pos);
    return true;
  });
  return out;
}
export function insertNote(editor, text, kind) {
  const count = Math.floor(footnoteMarkers(editor).length / 2) + 1;
  editor.chain().focus().insertContent(`<sup>[${count}]</sup> `).run();
  const first = count === 1;
  editor.chain().insertContentAt(editor.state.doc.content.size, `${first ? `<hr><p><strong>${kind === 'endnote' ? 'Endnotes' : 'Footnotes'}</strong></p>` : ''}<p><sup>[${count}]</sup> ${esc(text)}</p>`).run();
}
export function gotoNote(editor, dir) {
  const marks = footnoteMarkers(editor); if (!marks.length) return false;
  const cur = editor.state.selection.from;
  const target = dir > 0 ? marks.find((p) => p > cur) ?? marks[0] : [...marks].reverse().find((p) => p < cur - 1) ?? marks[marks.length - 1];
  editor.chain().focus().setTextSelection(target).scrollIntoView().run();
  return true;
}

/* Citations & bibliography */
const last = (a) => (a.split(',')[0] || a).trim();
export const inText = (s, style, i) => ({
  APA: `(${last(s.author)}, ${s.year})`, MLA: `(${last(s.author)})`, Chicago: `(${last(s.author)} ${s.year})`,
  Harvard: `(${last(s.author)} ${s.year})`, IEEE: `[${i + 1}]`,
}[style]);
export const bibEntry = (s, style, i) => {
  const pub = s.publisher ? ` ${s.publisher}.` : ''; const url = s.url ? ` ${s.url}` : '';
  switch (style) {
    case 'MLA': return `${s.author}. <em>${esc(s.title)}</em>.${s.publisher ? ` ${esc(s.publisher)},` : ''} ${s.year}.${url}`;
    case 'Chicago': return `${s.author}. ${s.year}. <em>${esc(s.title)}</em>.${pub}${url}`;
    case 'Harvard': return `${s.author} (${s.year}) <em>${esc(s.title)}</em>.${pub}${url}`;
    case 'IEEE': return `[${i + 1}] ${s.author}, “${esc(s.title)},”${s.publisher ? ` ${esc(s.publisher)},` : ''} ${s.year}.${url}`;
    default: return `${s.author} (${s.year}). <em>${esc(s.title)}</em>.${pub}${url}`;
  }
};
export function insertBibliography(editor, sources, style, heading) {
  const body = [...sources].sort((a, b) => a.author.localeCompare(b.author)).map((s, i) => `<p>${bibEntry(s, style, i)}</p>`).join('');
  editor.chain().focus().insertContent(`<h2>${heading}</h2>${body}`).run();
}
export function nextCaption(editor, label) {
  const m = editor.getText().match(new RegExp(`^${label} \\d+`, 'gm'));
  return (m ? m.length : 0) + 1;
}
