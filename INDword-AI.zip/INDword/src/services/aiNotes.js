import { LOGO, BRAND } from '../brand.js';

const dateStr = () => new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
export const todayStr = dateStr;
/** header carries today's date; it is read at the moment the meta is spread into a document */
export const NOTES_META = {
  get header() { return `${BRAND.header}  ·  ${dateStr()}`; },
  paged: true, size: 'A4', orientation: 'portrait', columns: 2, fontSet: 'office',
  margins: { top: 52, right: 44, bottom: 52, left: 44 },
  marginBorder: { style: 'dashed', color: '#000000', width: 2, gap: 12 },
  footer: BRAND.footer, pageNumbers: true,
  watermark: { text: '', image: LOGO, imageWidth: 420, opacity: 0.07 },
};
const COL_W = 339, FULL_W = 706;

/* ---------------- prompt ---------------- */
export const DEFAULT_OPTS = { pyqPrelims: true, pyqMains: true, mockPrelims: true, mockMains: true, keywords: true, related: true, images: true, cover: false };

const SEC = '{"level":1,"title":"","body":["paragraph"],"points":["short point"]}';
export function buildPrompt(o = DEFAULT_OPTS, part = 'all') {
  const p1 = part !== '2', p2 = part !== '1';
  const k = [];
  if (p1) { k.push('"title":"short topic title"', '"syllabus":["GS2 · Polity & Governance · Prelims + Mains"]', `"dynamic":[${SEC}]`); if (o.keywords) k.push('"keywords":[{"term":"","meaning":"one line, exam oriented"}]'); }
  if (p2) {
    if (part === '2') k.push('"title":"same short topic title"');
    k.push(`"static":[${SEC}]`);
    if (o.related) k.push(`"related_facts":[${SEC}]`);
    k.push('"revision":["crisp revision point"]');
    if (o.pyqPrelims) k.push('"pyq_prelims":[{"q":"","options":["(A) ","(B) ","(C) ","(D) "],"answer":"(B)","explanation":"","exam":"UPSC Prelims","year":2019,"syllabus":"GS1 · History · Prelims"}]');
    if (o.pyqMains) k.push('"pyq_mains":[{"q":"","exam":"UPSC Mains GS2","year":2018,"marks":15,"syllabus":"GS2 · Polity · Mains"}]');
    if (o.mockPrelims) k.push('"mock_prelims":[{"q":"","options":["(A) ","(B) ","(C) ","(D) "],"answer":"(C)","explanation":"","syllabus":"GS2 · Polity · Prelims"}]');
    if (o.mockMains) k.push('"mock_mains":[{"q":"","marks":15,"words":250,"syllabus":"GS2 · Polity · Mains","structure":["Introduction: ...","Body: ...","Way forward: ...","Conclusion: ..."]}]');
    if (o.images) k.push('"images":[{"title":"","caption":"","prompt":"detailed prompt to generate a clear, labelled explanatory diagram"}]');
  }
  const rules = [];
  if (p1) rules.push(
    'DYNAMIC (what the article says): include ONLY what a UPSC / State PSC aspirant must know, about 600-1000 words in total. No story-telling, no repetition, no opinions, no trivia: every line must be exam-relevant (facts, figures, provisions, arguments, impact, suggestions). Use the article first; search the internet only to confirm or complete key facts. Cover briefly: Why in News; what happened; key provisions/features; arguments in favour and against; impact; challenges; suggestions and solutions; way forward; conclusion. Skip any part that does not apply.',
    'SYLLABUS: tag the topic to the exact UPSC syllabus (paper, subject, stage), for example "GS1 · History · Prelims", "GS2 · International Relations · Mains", "GS3 · Economy · Prelims + Mains".');
  if (p1 && o.keywords) rules.push('KEYWORDS: 10-15 terms from the article and its context that are useful for the exam, each with a one-line meaning.');
  if (p2) rules.push('STATIC (background syllabus knowledge): about 700-1200 words, only what is directly connected to this topic: definitions, articles, acts, institutions, schemes, committees, judgments, reports and indices, geography, history. If (and ONLY if) the article is about a policy, scheme, law, judgment, treaty, index, institution or international development, add one level-1 section titled "Why this is important for India and UPSC" with 4-6 sharp points; otherwise do not add it.');
  if (p2 && o.related) rules.push('RELATED FACTS: 8-12 facts NOT in the article that are likely to be asked in UPSC / State PSC (data, firsts, lists, places, organisations, dates). Search the internet and verify.');
  if (p2) rules.push('REVISION: 10-15 crisp, fact-packed points.');
  if (p2 && (o.pyqPrelims || o.pyqMains)) rules.push('PYQ: include ONLY questions that were genuinely asked in UPSC Prelims / UPSC Mains (or a named State PSC) and are related to this topic. Give the exact exam and year. If you are not certain a question was really asked, leave it out. Never invent, never modify. Return [] if none. Every PYQ needs a syllabus tag.');
  if (p2 && o.mockPrelims) rules.push('MOCK PRELIMS: 5 statement-based UPSC-style MCQs from the article and its static context, with answer and explanation.');
  if (p2 && o.mockMains) rules.push('MOCK MAINS: 2 questions (one 150 words, one 250 words) with a proper answer structure.');
  if (p2 && o.images) rules.push('IMAGES: only if a diagram, flowchart, map or infographic would explain the article more simply, give up to 2 entries. Each "prompt" must be a complete instruction that I can paste into Gemini directly, starting with "Generate an image:", describing a clean, labelled, 16:9 educational diagram with readable text labels. Do NOT generate the images now.');
  rules.push('HIGHLIGHTING: inside strings wrap important terms in **double asterisks** (shown bold) and must-remember facts, numbers, dates and names in ==double equals== (shown highlighted). Use them on roughly one in six or seven phrases, never on whole sentences.');
  return `You are a senior UPSC CSE and State PSC mentor and current-affairs analyst. The attached image is a newspaper article. Prepare complete exam-oriented notes.

Reply with ONLY one JSON object inside ONE code block. No text before or after.${part === 'all' ? '' : `\nThis is PART ${part} of 2; I will send the other part separately.`}

JSON shape (use only these keys):
{${k.join(',\n')}}

Rules:
- "level" is 1 (main heading), 2 (sub-heading) or 3 (sub-sub-heading). Use all three levels where the content needs them.
- Plain text inside strings, except the ** and == highlighting marks described below. No other markdown, no line breaks inside a string, no trailing commas.
${rules.map((r) => `- ${r}`).join('\n')}`;
}

/* ---------------- reply parsing (accepts several JSON objects, e.g. Part 1 + Part 2) ---------------- */
function objectsIn(text) {
  const out = []; let depth = 0; let start = -1; let inStr = false; let esc = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true;
    else if (ch === '{') { if (depth === 0) start = i; depth += 1; }
    else if (ch === '}' && depth > 0) { depth -= 1; if (depth === 0) out.push(text.slice(start, i + 1)); }
  }
  return out;
}
export function parseReply(text) {
  const t = String(text).replace(/[\u201C\u201D]/g, '"');
  const parts = objectsIn(t); if (!parts.length) throw new Error('No JSON found. Copy the whole reply from Gemini, including the { and } symbols.');
  const merged = {};
  parts.forEach((s) => {
    let o; try { o = JSON.parse(s); } catch { throw new Error('A reply is cut off or not valid JSON. Ask Gemini: "Continue and give the complete JSON again."'); }
    Object.keys(o).forEach((key) => {
      if (Array.isArray(o[key])) merged[key] = (merged[key] || []).concat(o[key]);
      else if (!merged[key]) merged[key] = o[key];
    });
  });
  return merged;
}

/* ---------------- block builders ---------------- */
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const plain = (s) => esc(String(s ?? '').replace(/\*\*|==/g, ''));
/** **bold** and ==highlight== marks from Gemini */
const fm = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/==(.+?)==/g, '<mark data-color="#FFF200" style="background-color:#FFF200">$1</mark>');
const bar = (tag, bg, text, extra = '') => `<${tag} style="background-color:${bg};${extra}"><span style="color:#ffffff">${plain(text)}</span></${tag}>`;
const TONES = { peach: '#FBE4D5', mint: '#C6EFCE', amber: '#FFC000', sky: '#D3EEFA' };
export const BLOCKS = {
  banner: (t) => bar('h1', '#C00000', t, 'text-align:center'),
  section: (t) => bar('h2', '#104818', t),
  sub: (t, tone = 'peach') => `<h3 style="background-color:${TONES[tone] || tone}">${plain(t)}</h3>`,
  subsub: (t) => `<h4><u>${plain(t)}</u></h4>`,
  red: (t) => bar('h2', '#C00000', t),
  point: (t) => `<p><span style="color:#0F6FC6">◆</span> ${fm(t)}</p>`,
  sub2: (t) => `<p style="margin-left:18px"><span style="color:#0F6FC6">●</span> ${fm(t)}</p>`,
  note: (t) => `<div data-callout="tip"><p>${esc(t)}</p></div>`,
  info: (t) => `<div data-callout="info"><p>${esc(t)}</p></div>`,
  why: (t = 'Write the news summary here.') => bar('h2', '#104818', '📰 Why in News?') + `<p>${esc(t)}</p>`,
  img: (url, w, border = false) => `<p${border ? ' data-borders="border:1.5px solid #000000;line-height:0"' : ''}><img src="${url}" style="width:${w}px"></p>`,
  pyq: (inner) => `<div data-callout="pyq">${inner}</div>`,
};
export const TONE_NAMES = Object.keys(TONES);

const sec = (s) => {
  const l = Math.min(3, Math.max(1, s.level || 1));
  return (l === 1 ? BLOCKS.section : l === 2 ? BLOCKS.sub : BLOCKS.subsub)(s.title)
    + (s.body || []).map((t) => `<p>${fm(t)}</p>`).join('') + (s.points || []).map(BLOCKS.point).join('');
};
const label = (parts, hl) => { const t = esc(parts.filter(Boolean).join(' · ')); return hl ? `<mark data-color="#FFD966" style="background-color:#FFD966"><strong>[${t}]</strong></mark>` : `<strong>[${t}]</strong>`; };
const mcqInner = (x, tag, hl) => `<p>${label(tag, hl)} <strong>Q. ${fm(x.q)}</strong></p>${(x.options || []).map((o) => `<p>${fm(o)}</p>`).join('')}<p>✅ <strong>Correct Answer: ${esc(x.answer)}</strong>${x.explanation ? ` — ${fm(x.explanation)}` : ''}</p>`;
const mcq = (x, tag) => mcqInner(x, tag, false);
const struct = (a) => (a || []).map(BLOCKS.point).join('');
export const imagePrompts = (d) => (d.images || []).filter((m) => m.prompt).map((m, i) => `Image ${i + 1}: ${m.title || ''}\n${m.prompt}`).join('\n\n');

/** d = merged Gemini JSON, img = {url,w,h} (the article), opts = include flags, extras = [{url,caption}] extra images */
export function buildNotesHtml(d, img, opts = DEFAULT_OPTS, extras = []) {
  const tall = img.h / img.w > 1.25;
  const h = [BLOCKS.banner(d.title || 'Article Notes'), tall ? '' : BLOCKS.img(img.url, FULL_W, true), tall ? BLOCKS.img(img.url, COL_W, true) : ''];
  if ((d.syllabus || []).length) h.push(BLOCKS.info(`📌 Syllabus: ${d.syllabus.join('  |  ')}`));
  h.push(BLOCKS.red('📰 Dynamic: What the article says'), ...(d.dynamic || []).map(sec));
  extras.forEach((e) => h.push(BLOCKS.img(e.url, COL_W), `<p><em>${esc(e.caption || '')}</em></p>`));
  if (opts.keywords && (d.keywords || []).length) h.push(BLOCKS.section('🔑 Keywords for the exam'), ...d.keywords.map((x) => `<p><span style="color:#0F6FC6">◆</span> <strong>${esc(x.term)}</strong>: ${esc(x.meaning)}</p>`));
  h.push(BLOCKS.red('📚 Static: Background to know'), ...(d.static || []).map(sec));
  if (opts.related && (d.related_facts || []).length) h.push(BLOCKS.red('🔎 Related facts likely in exams'), ...d.related_facts.map(sec));
  if ((d.revision || []).length) h.push(BLOCKS.section('⚡ Revision Pointers'), ...d.revision.map(BLOCKS.point));
  if (opts.images && (d.images || []).length && !extras.length) h.push(BLOCKS.section('🖼 Image ideas (paste the prompt in Gemini)'), ...d.images.map((x) => `<div data-callout="tip"><p><strong>${plain(x.title)}</strong>: ${plain(x.caption)}</p><p>🖼 <em>${plain(x.prompt)}</em></p></div>`));
  if (opts.pyqPrelims && (d.pyq_prelims || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Prelims'), ...d.pyq_prelims.map((x) => BLOCKS.pyq(mcqInner(x, ['PYQ', x.exam, x.year, x.syllabus], true))));
  if (opts.pyqMains && (d.pyq_mains || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Mains'), ...d.pyq_mains.map((x) => BLOCKS.pyq(`<p>${label(['PYQ', x.exam, x.year, x.marks ? `${x.marks} marks` : '', x.syllabus], true)} <strong>${fm(x.q)}</strong></p>`)));
  if (opts.mockPrelims && (d.mock_prelims || []).length) h.push(BLOCKS.red('Prelims Practice Questions'), ...d.mock_prelims.map((x) => mcq(x, ['Mock', x.syllabus])));
  if (opts.mockMains && (d.mock_mains || []).length) h.push(BLOCKS.red('Mains Practice Questions'), ...d.mock_mains.map((x) => `<p>${label(['Mock', x.marks ? `${x.marks} marks` : '', x.words ? `${x.words} words` : '', x.syllabus])} ${esc(x.q)}</p><h4>Answer Structure</h4>${struct(x.structure)}`));
  return h.join('');
}
export const PAGE_BREAK = '<div data-page-break></div>';

/* ---------------- cover page (full-bleed image) ---------------- */
const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
export const DEFAULT_COVER = {
  date: '', coverage: 'GS I, II, III, IV & Essay', platform: 'YouTube / Telegram PDF',
  vision: 'To democratize civil services preparation by breaking financial and geographical barriers, ensuring every aspirant—regardless of rural roots or economic background—has equal access to top-tier mentorship.',
  mission: 'To deliver high-quality, affordable digital coaching on YouTube. We replace rote learning with conceptual clarity and strategic guidance so rural aspirants can compete on equal footing with the privileged.',
  commitments: 'Democratize Access: Deliver free/affordable YouTube coaching removing financial barriers.\nConceptual Clarity: Move beyond facts to deep analytical understanding of issues.\nLevel the Playing Field: Provide top-tier exam strategies for rural & poor aspirants.\nStructured Guidance: Honest, focused direction to navigate UPSC & State PSC syllabi.',
  topics: 'THE HINDU & IE POINTERS|PIB & GOVT. SCHEMES|MAINS ANSWER STRUCTURE|PRELIMS FACTS',
  footerL: 'Free & Affordable Education Initiative', footerR: 'Connect with us: www.indias.com',
};
export async function makeCover(o) {
  const c = document.createElement('canvas'); c.width = 1588; c.height = 2246;
  const x = c.getContext('2d'); x.scale(2, 2);
  const GOLD = '#C9A634'; const RED = '#B3262E'; const F = 'Arial, Helvetica, sans-serif';
  const rr = (a, b, w, h, r) => { x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); };
  const txt = (t, px, y, size, color, weight = 'bold', align = 'center', ls = 0) => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = align; if ('letterSpacing' in x) x.letterSpacing = `${ls}px`; x.fillText(t, px, y); if ('letterSpacing' in x) x.letterSpacing = '0px'; };
  const wrap = (t, a, y, w, size, color, lh, weight = 'normal') => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = 'left'; let line = ''; t.split(' ').forEach((wd) => { const n = line ? `${line} ${wd}` : wd; if (x.measureText(n).width > w && line) { x.fillText(line, a, y); y += lh; line = wd; } else line = n; }); x.fillText(line, a, y); return y; };
  // background: slate blue with a faint grid
  const g = x.createLinearGradient(0, 0, 0, 1123); g.addColorStop(0, '#2B4268'); g.addColorStop(0.55, '#1E3050'); g.addColorStop(1, '#16233B');
  x.fillStyle = g; x.fillRect(0, 0, 794, 1123);
  x.strokeStyle = 'rgba(255,255,255,.05)'; x.lineWidth = 1;
  for (let i = 0; i <= 8; i += 1) { x.beginPath(); x.moveTo(i * 100 - 20, 0); x.lineTo(i * 100 - 60, 1123); x.stroke(); }
  for (let i = 1; i < 11; i += 1) { x.beginPath(); x.moveTo(0, i * 105); x.lineTo(794, i * 105 - 12); x.stroke(); }
  // gold double frame
  x.strokeStyle = GOLD; x.lineWidth = 2; x.strokeRect(19, 19, 756, 1085); x.lineWidth = 0.8; x.strokeRect(26, 26, 742, 1071);
  // logo tile
  const logo = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = LOGO; });
  x.save(); x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = 14; x.fillStyle = '#fff'; x.fillRect(303, 53, 189, 189); x.restore(); x.drawImage(logo, 303, 53, 189, 189);
  // slogan pill
  x.fillStyle = 'rgba(120,20,30,.92)'; rr(173, 256, 448, 29, 14.5); x.fill(); x.strokeStyle = '#D9363E'; x.lineWidth = 1.5; rr(173, 256, 448, 29, 14.5); x.stroke();
  txt(BRAND.slogan.toUpperCase(), 397, 275.5, 11.5, '#fff', 'bold', 'center', 1.4);
  // title block
  x.fillStyle = 'rgba(14,24,46,.78)'; x.fillRect(68, 297, 658, 135); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(68, 297, 658, 1);
  txt('DAILY CURRENT AFFAIRS', 397, 343, 33, '#fff', 'bold', 'center', 0.5);
  txt('NOTES & COMPREHENSIVE ANALYSIS', 397, 385, 28, GOLD, 'bold', 'center', 0.5);
  txt('ESSENTIAL FOR UPSC CSE & STATE PSC PREPARATION', 397, 413, 13, '#fff', 'bold', 'center', 1.2);
  // info bar (one line)
  x.fillStyle = 'rgba(14,24,46,.7)'; rr(68, 452, 658, 36, 6); x.fill(); x.strokeStyle = GOLD; x.lineWidth = 1; rr(68, 452, 658, 36, 6); x.stroke();
  const info = [['DATE:', o.date || ''], ['COVERAGE:', o.coverage || ''], ['PLATFORM:', o.platform || '']];
  x.font = `bold 12px ${F}`; const widths = info.map(([k, v]) => x.measureText(`${k} `).width + x.measureText(v).width); const gap = 22;
  let cx = 397 - (widths.reduce((a, b) => a + b, 0) + gap * 2) / 2;
  info.forEach(([k, v], i) => { txt(`${k} `, cx, 475, 12, GOLD, 'bold', 'left'); txt(v, cx + x.measureText(`${k} `).width, 475, 12, '#fff', 'bold', 'left'); cx += widths[i] + gap; });
  // vision / mission cards
  [['OUR VISION', o.vision, 68, GOLD], ['OUR MISSION', o.mission, 405, RED]].forEach(([t, v, a, col]) => {
    x.fillStyle = 'rgba(14,24,46,.82)'; x.fillRect(a, 507, 321, 143); x.fillStyle = col; x.fillRect(a, 507, 4, 143);
    txt(t, a + 20, 536, 14, GOLD, 'bold', 'left', 1.2); wrap(v || '', a + 20, 562, 285, 11.5, '#fff', 17.5);
  });
  // commitments
  x.fillStyle = 'rgba(14,24,46,.82)'; rr(68, 670, 658, 147, 6); x.fill();
  txt('OUR INSTITUTIONAL COMMITMENTS', 87, 697, 14, GOLD, 'bold', 'left', 1); x.fillStyle = GOLD; x.fillRect(87, 708, 620, 1);
  (o.commitments || '').split('\n').filter(Boolean).slice(0, 4).forEach((ln, i) => {
    const k = ln.indexOf(':'); const t = k > 0 ? ln.slice(0, k + 1) : ''; const d = k > 0 ? ln.slice(k + 1).trim() : ln;
    const ax = i % 2 ? 420 : 98; const ay = 733 + Math.floor(i / 2) * 45;
    x.fillStyle = '#D9363E'; x.beginPath(); x.moveTo(ax - 1, ay - 4); x.lineTo(ax + 4, ay - 9); x.lineTo(ax + 9, ay - 4); x.lineTo(ax + 4, ay + 1); x.closePath(); x.fill();
    x.font = `bold 11px ${F}`; const tw = x.measureText(`${t} `).width; txt(t, ax + 16, ay, 11, '#fff', 'bold', 'left');
    x.font = `11px ${F}`; x.fillStyle = '#fff'; x.textAlign = 'left'; let line = ''; let y = ay; let first = true; const words = d.split(' ');
    words.forEach((wd) => { const n = line ? `${line} ${wd}` : wd; const lim = first ? 290 - tw : 290; if (x.measureText(n).width > lim && line) { x.fillText(line, first ? ax + 16 + tw : ax + 16, y); y += 15; line = wd; first = false; } else line = n; });
    x.fillText(line, first ? ax + 16 + tw : ax + 16, y);
  });
  // topics strip
  x.fillStyle = 'rgba(110,20,28,.75)'; rr(68, 836, 658, 32, 6); x.fill(); x.strokeStyle = '#C0343C'; x.lineWidth = 1; rr(68, 836, 658, 32, 6); x.stroke();
  const tps = (o.topics || '').split('|').filter(Boolean).map((t) => `•  ${t.trim()}`); x.font = `bold 10px ${F}`;
  const tw2 = tps.map((t) => x.measureText(t).width); const g2 = 14; let tx = 397 - (tw2.reduce((a, b) => a + b, 0) + g2 * (tps.length - 1)) / 2;
  tps.forEach((t, i) => { txt(t, tx, 856.5, 10, '#fff', 'bold', 'left'); tx += tw2[i] + g2; });
  // footer
  x.fillStyle = GOLD; x.globalAlpha = 0.6; x.fillRect(68, 1041, 658, 1); x.globalAlpha = 1;
  txt(o.footerL || '', 68, 1070, 12, '#E6E9F0', 'normal', 'left'); txt(o.footerR || '', 726, 1070, 12, '#E6E9F0', 'normal', 'right');
  return c.toDataURL('image/jpeg', 0.92);
}
export const coverHtml = (url) => BLOCKS.img(url, 794);

/* ---------------- image helper ---------------- */
export const fileToJpeg = (file, max = 1400) => new Promise((res, rej) => {
  const r = new FileReader(); r.onerror = () => rej(new Error('Could not read image'));
  r.onload = () => {
    const i = new Image(); i.onerror = () => rej(new Error('Not a valid image'));
    i.onload = () => { const s = Math.min(1, max / Math.max(i.width, i.height)); const c = document.createElement('canvas'); c.width = Math.round(i.width * s); c.height = Math.round(i.height * s); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); res({ url: c.toDataURL('image/jpeg', 0.85), w: c.width, h: c.height }); };
    i.src = r.result;
  };
  r.readAsDataURL(file);
});
