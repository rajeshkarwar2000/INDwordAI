import { createStore, get, set } from 'idb-keyval';

const kv = createStore('indword-ai', 'kv');
export const getAiSettings = async () => ({ key: (await get('key', kv)) || '', model: (await get('model', kv)) || 'gemini-flash-latest' });
export const saveAiSettings = async (key, model) => { await set('key', key, kv); await set('model', model, kv); };

export const NOTES_META = { margins: { top: 48, right: 48, bottom: 48, left: 48 }, columns: 1, marginBorder: { style: 'dashed', color: '#000000', width: 2, gap: 10 }, fontSet: 'office' };

export const PROMPT = `You are a UPSC / State PSC current-affairs expert. Read the newspaper article in the attached image. Reply with ONLY the JSON below inside one code block, no other text:
{"title":"","dynamic":[{"level":1,"title":"","body":[""],"points":[""]}],"static":[same shape],"revision":[""],"pyq":[{"q":"","options":["(A)","(B)","(C)","(D)"],"answer":"","exam":"UPSC Prelims","year":2019}],"mock":[{"q":"","options":["(A)","(B)","(C)","(D)"],"answer":"","explanation":""}],"mains":{"q":"","structure":[""]}}
Rules: level is 1, 2 or 3 (heading, sub-heading, sub-sub-heading). "dynamic" = what the article says (start with Why in News, end with Way Forward). "static" = underlying general knowledge (definitions, institutions, schemes, facts). Include "pyq" ONLY for questions you are certain were really asked, with exact exam and year; otherwise return []. Give 4 mock MCQs based on the article. Be factual and concise.`;

export const fileToJpeg = (file, max = 1400) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onerror = () => rej(new Error('Could not read image'));
  r.onload = () => {
    const i = new Image();
    i.onerror = () => rej(new Error('Not a valid image'));
    i.onload = () => {
      const s = Math.min(1, max / Math.max(i.width, i.height)), c = document.createElement('canvas');
      c.width = Math.round(i.width * s); c.height = Math.round(i.height * s);
      c.getContext('2d').drawImage(i, 0, 0, c.width, c.height);
      res({ url: c.toDataURL('image/jpeg', 0.85), w: c.width, h: c.height });
    };
    i.src = r.result;
  };
  r.readAsDataURL(file);
});

export async function generateNotes(url, key, model) {
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: PROMPT }, { inline_data: { mime_type: 'image/jpeg', data: url.split(',')[1] } }] }], generationConfig: { responseMimeType: 'application/json' } }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error?.message || `Gemini error ${r.status}`);
  const t = j.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!t) throw new Error('Gemini returned no text. Try again.');
  return JSON.parse(t.replace(/```json|```/g, ''));
}

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const bar = (tag, bg, text, extra = '') => `<${tag} style="background-color:${bg};${extra}"><span style="color:#ffffff">${esc(text)}</span></${tag}>`;
export const BLOCKS = {
  banner: (t) => bar('h1', '#C00000', t, 'text-align:center'),
  section: (t) => bar('h2', '#104818', t),
  sub: (t) => `<h3 style="background-color:#FBE4D5">${esc(t)}</h3>`,
  subsub: (t) => `<h4><u>${esc(t)}</u></h4>`,
  red: (t) => bar('h2', '#C00000', t),
  point: (t) => `<p><span style="color:#0F6FC6">◆</span> ${esc(t)}</p>`,
  note: (t) => `<div data-callout="tip"><p>${esc(t)}</p></div>`,
};

const sec = (s) => {
  const l = Math.min(3, Math.max(1, s.level || 1));
  return (l === 1 ? BLOCKS.section : l === 2 ? BLOCKS.sub : BLOCKS.subsub)(s.title)
    + (s.body || []).map((t) => `<p>${esc(t)}</p>`).join('') + (s.points || []).map(BLOCKS.point).join('');
};
const mcq = (x, tag) => `<p><strong>[${esc(tag)}]</strong> Q. ${esc(x.q)}</p>${(x.options || []).map((o) => `<p>${esc(o)}</p>`).join('')}<p>✅ <strong>Correct Answer: ${esc(x.answer)}</strong>${x.explanation ? ` — ${esc(x.explanation)}` : ''}</p>`;

/** Wide / square article: full-width image above two columns. Tall article: image is the first item in column 1. */
export function buildNotesHtml(d, img) {
  const tall = img.h / img.w > 1.25;
  const imgHtml = (w) => `<p><img src="${img.url}" style="width:${w}px"></p>`;
  const body = [
    BLOCKS.red('📰 Dynamic: What the article says'), ...(d.dynamic || []).map(sec),
    BLOCKS.red('📚 Static: Background to know'), ...(d.static || []).map(sec),
    BLOCKS.section('⚡ Revision Pointers'), ...(d.revision || []).map(BLOCKS.point),
    ...((d.pyq || []).length ? [BLOCKS.red('Previous Year Questions'), ...d.pyq.map((x) => mcq(x, `PYQ · ${x.exam} ${x.year} · Verify`))] : []),
    BLOCKS.red('Mock Questions (based on this article)'), ...(d.mock || []).map((x) => mcq(x, 'Mock')),
    ...(d.mains ? [BLOCKS.red('Mains Practice'), `<p>${esc(d.mains.q)}</p>`, ...(d.mains.structure || []).map(BLOCKS.point)] : []),
  ].join('');
  return BLOCKS.banner(d.title || 'Article Notes') + (tall ? '' : imgHtml(698))
    + `<div data-columns="2" data-gap="28" data-sep="1">${tall ? imgHtml(335) : ''}${body}</div>`;
}
export const PAGE_BREAK = '<div data-page-break></div>';

/** Reads Gemini's pasted reply: tolerates code fences, extra text and smart quotes around the JSON. */
export function parseReply(text) {
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('No JSON found. Copy the whole reply from Gemini, including the { and } symbols.');
  try { return JSON.parse(text.slice(a, b + 1)); }
  catch (e) { throw new Error('The reply is cut off or not valid JSON. Ask Gemini: "Continue and give the complete JSON again."'); }
}
