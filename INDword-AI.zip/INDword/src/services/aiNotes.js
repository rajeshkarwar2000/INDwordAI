import { LOGO, BRAND } from '../brand.js';

const dateStr = () => new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
export const todayStr = dateStr;
/** header carries today's date; it is read at the moment the meta is spread into a document */
export const NOTES_META = {
  get header() { return `${BRAND.header}  ·  ${dateStr()}`; },
  paged: true, size: 'A4', orientation: 'portrait', columns: 2, fontSet: 'office',
  margins: { top: 52, right: 44, bottom: 52, left: 44 },
  marginBorder: { style: 'dashed', color: '#000000', width: 2, gap: 12 },
  footer: BRAND.footer, pageNumbers: true,
  watermark: { text: '', image: LOGO, imageWidth: 420, opacity: 0.07 },
};
const COL_W = 339, FULL_W = 706;

/* ---------------- prompt ---------------- */
export const DEFAULT_OPTS = { pyqPrelims: false, pyqMains: false, mockPrelims: false, mockMains: false, hindi: false, keywords: true, related: true, images: true, cover: false, cols: 2 };

const SEC = '{"level":1,"title":"","body":["short paragraph if needed"],"points":["short bullet point"]}';
export function buildPrompt(o = DEFAULT_OPTS, part = 'all') {
  const p1 = part !== '2', p2 = part !== '1';
  const k = [];
  if (p1) {
    k.push('"title":"short topic title"', '"syllabus":["GS2 · International Relations · Prelims + Mains"]', `"dynamic":[${SEC}]`);
    if (o.images) k.push('"images":[{"title":"","caption":"","prompt":"Generate an image: ..."}]');
    if (o.keywords) k.push('"keywords":[{"term":"","meaning":"one line, exam oriented"}]');
  }
  if (p2) {
    if (part === '2') k.push('"title":"same short topic title"');
    k.push(`"static":[${SEC}]`);
    if (o.related) k.push(`"related_facts":[${SEC}]`);
    k.push('"revision":["crisp, fact-packed point"]');
    if (o.pyqPrelims) k.push('"pyq_prelims":[{"q":"","options":["(A) ","(B) ","(C) ","(D) "],"answer":"(B)","explanation":"","exam":"UPSC Prelims","year":2019,"syllabus":"GS1 · History · Prelims"}]');
    if (o.pyqMains) k.push('"pyq_mains":[{"q":"","exam":"UPSC Mains GS2","year":2018,"marks":15,"syllabus":"GS2 · Polity · Mains"}]');
    if (o.mockPrelims) k.push('"mock_prelims":[{"q":"","options":["(A) ","(B) ","(C) ","(D) "],"answer":"(C)","explanation":"","syllabus":"GS2 · Polity · Prelims"}]');
    if (o.mockMains) k.push(`"mock_mains":[{"q":"","${o.hindi ? 'q_hi":"Hindi version of the question","' : ''}marks":15,"words":250,"syllabus":"GS2 · Polity · Mains","structure":["Introduction: ...","Body: ...","Way forward: ...","Conclusion: ..."],"answer":["model answer, point by point"]${o.hindi ? ',"answer_hi":["Hindi model answer, point by point"]' : ''}}]`);
  }
  const r = [];
  r.push('SOURCES (very important): first search the internet for this topic on UPSC coaching websites (Vision IAS, Drishti IAS, Insights IAS, ForumIAS, IASbaba, PWOnlyIAS, NEXT IAS, Shankar IAS, Vajiram & Ravi) and on the Deepak Yadav Education YouTube channel, and read PIB, PRS, ministry/department websites, court judgments and official reports. See what these sources include and how they arrange it (headings, bullet style, wording, diagrams) and follow the same structure and similar wording. Do not overfeed: include only what a UPSC / State PSC aspirant needs.');
  r.push('PYQ ANALYSIS: before writing, think about which parts of this topic UPSC (Prelims and Mains) and State PSCs have asked about, and give those parts more space and clearer treatment.');
  if (p1) {
    r.push('DYNAMIC (what the article says): there is NO word limit. Make it short where the content is simple and long where the topic needs it: precise but complete. Include EVERY important detail, fact, figure, date, name, provision, argument, strategy, suggestion and solution from the article; leave out only what is unimportant. Add the closely related information that is important (from PIB and other government sources, committees, reports). Arrange events in chronological order. Use bullet points ("points") wherever possible, with short sentences: fewest words, maximum coverage. Use simple words, but never change keywords, technical terms or proper names. Always name the ministry / department / regulator / organisation concerned (for example Ministry of Defence, DRDO, ISRO, MoEFCC).');
    r.push('HEADINGS: use proper headings (level 1), sub-headings (level 2) and sub-sub-headings (level 3); every point must sit under a suitable heading. Do not add a heading that says why the topic is important for UPSC; put that information under the relevant headings instead.');
    r.push('DEFENCE / SCIENCE / TECHNOLOGY articles (ships, submarines, missiles, aircraft, satellites, reactors, vaccines, etc.): explain comprehensively everything an aspirant must know: type and class, developer / builder, ministry, project or programme, important dates, key specifications, weapons and sensors, indigenous content, significance, and related platforms. Use images for these topics.');
    r.push('SYLLABUS: tag the topic to the exact UPSC syllabus (paper, subject, stage), for example "GS1 · History · Prelims", "GS3 · Science & Technology · Prelims + Mains".');
    if (o.images) r.push('IMAGES: give as many images as are genuinely needed to explain the article (none if not needed): maps, flowcharts, timelines, diagrams and, for defence / science topics, pictures and cut-away technical diagrams. Look at which figures the coaching websites use for this topic. Each "prompt" must be a complete instruction that I can paste into Gemini directly, starting with "Generate an image:", describing a clean, labelled, 16:9 educational image with readable text labels. Do NOT generate the images now.');
    if (o.keywords) r.push('KEYWORDS: list ALL important keywords from the article and its context, with a one-line meaning each. There is no limit on the number.');
  }
  if (p2) {
    r.push('STATIC (background syllabus knowledge): rationalise it for UPSC: only what is directly connected to this topic, in short bullets, arranged logically or chronologically: definitions, articles, acts, institutions, schemes, committees, judgments, reports and indices, geography, history. Name the ministry / department for each organisation.');
    if (o.related) r.push('RELATED FACTS: the important related facts NOT in the article that are likely to be asked in UPSC / State PSC (data, firsts, lists, places, organisations, dates), mainly from PIB and other government sources. Verify them.');
    r.push('REVISION: crisp, fact-packed bullet points covering everything important.');
    if (o.pyqPrelims || o.pyqMains) r.push('PYQ: include ONLY questions that were genuinely asked in UPSC Prelims / UPSC Mains (or a named State PSC) and are related to this topic. Give the exact exam and year. If you are not certain a question was really asked, leave it out. Never invent, never modify. Return [] if none. Every PYQ needs a syllabus tag.');
    if (o.mockPrelims) r.push('MOCK PRELIMS: statement-based UPSC-style MCQs from the article and its static context, with answer and explanation.');
    if (o.mockMains) r.push(`MOCK MAINS: 2 questions (one 150 words, one 250 words), each with an answer structure AND a complete model answer in bullet points${o.hindi ? ', and the Hindi version of the question with its Hindi model answer' : ''}.`);
  }
  r.push('HIGHLIGHTING: inside strings use only two styles: **bold** and ==yellow highlight==. Mark as many important words as the text contains (key terms, names, places, organisations, numbers, dates, provisions, schemes). Mark the most critical ones with both, like ==**term**==. Do not mark filler words.');
  return `You are a senior UPSC CSE and State PSC mentor and current-affairs analyst. The attached image is a newspaper article. Prepare aspirant-friendly, exam-oriented notes.

Reply with ONLY one JSON object inside ONE code block. No text before or after.${part === 'all' ? '' : `\nThis is PART ${part} of 2; I will send the other part separately.`}

JSON shape (use only these keys):
{${k.join(',\n')}}

Rules:
- "level" is 1 (heading), 2 (sub-heading) or 3 (sub-sub-heading).
- Plain text inside strings, except the ** and == marks. No other markdown, no line breaks inside a string, no trailing commas.
${r.map((x) => `- ${x}`).join('\n')}`;
}

/* ---------------- reply parsing (accepts several JSON objects, e.g. Part 1 + Part 2) ---------------- */
function objectsIn(text) {
  const out = []; let depth = 0; let start = -1; let inStr = false; let esc = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true;
    else if (ch === '{') { if (depth === 0) start = i; depth += 1; }
    else if (ch === '}' && depth > 0) { depth -= 1; if (depth === 0) out.push(text.slice(start, i + 1)); }
  }
  return out;
}
export function parseReply(text) {
  const t = String(text).replace(/[\u201C\u201D]/g, '"');
  const parts = objectsIn(t); if (!parts.length) throw new Error('No JSON found. Copy the whole reply from Gemini, including the { and } symbols.');
  const merged = {};
  parts.forEach((s) => {
    let o; try { o = JSON.parse(s); } catch { throw new Error('A reply is cut off or not valid JSON. Ask Gemini: "Continue and give the complete JSON again."'); }
    Object.keys(o).forEach((key) => {
      if (Array.isArray(o[key])) merged[key] = (merged[key] || []).concat(o[key]);
      else if (!merged[key]) merged[key] = o[key];
    });
  });
  return merged;
}

/* ---------------- block builders ---------------- */
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const plain = (s) => esc(String(s ?? '').replace(/\*\*|==/g, ''));
/** **bold** and ==highlight== marks from Gemini */
const fm = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/==(.+?)==/g, '<mark data-color="#FFF200" style="background-color:#FFF200">$1</mark>');
const bar = (tag, bg, text, extra = '') => `<${tag} style="background-color:${bg};${extra}"><span style="color:#ffffff">${plain(text)}</span></${tag}>`;
const TONES = { peach: '#FBE4D5', mint: '#C6EFCE', amber: '#FFC000', sky: '#D3EEFA' };
export const BLOCKS = {
  banner: (t) => bar('h1', '#C00000', t, 'text-align:center'),
  section: (t) => bar('h2', '#104818', t),
  sub: (t, tone = 'peach') => `<h3 style="background-color:${TONES[tone] || tone}">${plain(t)}</h3>`,
  subsub: (t) => `<h4><u>${plain(t)}</u></h4>`,
  red: (t) => bar('h2', '#C00000', t),
  point: (t) => `<p><span style="color:#0F6FC6">◆</span> ${fm(t)}</p>`,
  sub2: (t) => `<p style="margin-left:18px"><span style="color:#0F6FC6">●</span> ${fm(t)}</p>`,
  note: (t) => `<div data-callout="tip"><p>${esc(t)}</p></div>`,
  info: (t) => `<div data-callout="info"><p>${esc(t)}</p></div>`,
  why: (t = 'Write the news summary here.') => bar('h2', '#104818', '📰 Why in News?') + `<p>${esc(t)}</p>`,
  img: (url, w, border = false) => `<p${border ? ' data-borders="border:1.5px solid #000000;line-height:0"' : ''}><img src="${url}" style="width:${w}px"></p>`,
  imgidea: (title, caption, prompt) => `<div data-callout="imgidea"><p><strong>${plain(title)}</strong></p><p>${plain(caption)}</p><p><em>${plain(prompt)}</em></p></div>`,
  pyq: (inner) => `<div data-callout="pyq">${inner}</div>`,
};
export const TONE_NAMES = Object.keys(TONES);

const sec = (s) => {
  const l = Math.min(3, Math.max(1, s.level || 1));
  return (l === 1 ? BLOCKS.section : l === 2 ? BLOCKS.sub : BLOCKS.subsub)(s.title)
    + (s.body || []).map((t) => `<p>${fm(t)}</p>`).join('') + (s.points || []).map(BLOCKS.point).join('');
};
const label = (parts, hl) => { const t = esc(parts.filter(Boolean).join(' · ')); return hl ? `<mark data-color="#FFD966" style="background-color:#FFD966"><strong>[${t}]</strong></mark>` : `<strong>[${t}]</strong>`; };
const mcqInner = (x, tag, hl) => `<p>${label(tag, hl)} <strong>Q. ${fm(x.q)}</strong></p>${(x.options || []).map((o) => `<p>${fm(o)}</p>`).join('')}<p>✅ <strong>Correct Answer: ${esc(x.answer)}</strong>${x.explanation ? ` — ${fm(x.explanation)}` : ''}</p>`;
const mcq = (x, tag) => mcqInner(x, tag, false);
const struct = (a) => (a || []).map(BLOCKS.point).join('');
export const imagePrompts = (d) => (d.images || []).filter((m) => m.prompt).map((m, i) => `Image ${i + 1}: ${m.title || ''}\n${m.prompt}`).join('\n\n');

/** d = merged Gemini JSON, img = {url,w,h} (the article), opts = include flags, extras = [{url,caption}] images the user already has */
export function buildNotesHtml(d, img, opts = DEFAULT_OPTS, extras = []) {
  const one = opts.cols === 1; const colW = one ? FULL_W : COL_W;
  const tall = img.h / img.w > 1.25;
  const h = [BLOCKS.banner(d.title || 'Article Notes'), tall && !one ? '' : BLOCKS.img(img.url, one ? Math.min(FULL_W, tall ? 460 : FULL_W) : FULL_W, true), tall && !one ? BLOCKS.img(img.url, COL_W, true) : ''];
  if ((d.syllabus || []).length) h.push(BLOCKS.info(`📌 Syllabus: ${d.syllabus.join('  |  ')}`));
  h.push(BLOCKS.red('📰 Dynamic: What the article says'), ...(d.dynamic || []).map(sec));
  const ideas = opts.images ? (d.images || []) : [];
  const n = Math.max(ideas.length, extras.length);
  if (n) {
    h.push(BLOCKS.section('🖼 Diagrams and images'));
    for (let i = 0; i < n; i += 1) {
      const e = extras[i]; const x = ideas[i] || {};
      if (e) h.push(BLOCKS.img(e.url, colW, true), `<p><em>${plain(e.caption || x.caption || x.title || '')}</em></p>`);
      else h.push(BLOCKS.imgidea(x.title, x.caption, x.prompt));
    }
  }
  if (opts.keywords && (d.keywords || []).length) h.push(BLOCKS.section('🔑 Keywords'), ...d.keywords.map((x) => `<p><span style="color:#0F6FC6">◆</span> <strong>${plain(x.term)}</strong>: ${fm(x.meaning)}</p>`));
  h.push(BLOCKS.red('📚 Static: Background to know'), ...(d.static || []).map(sec));
  if (opts.related && (d.related_facts || []).length) h.push(BLOCKS.red('🔎 Related facts likely in exams'), ...d.related_facts.map(sec));
  if ((d.revision || []).length) h.push(BLOCKS.section('⚡ Revision Pointers'), ...d.revision.map(BLOCKS.point));
  if (opts.pyqPrelims && (d.pyq_prelims || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Prelims'), ...d.pyq_prelims.map((x) => BLOCKS.pyq(mcqInner(x, ['PYQ', x.exam, x.year, x.syllabus], true))));
  if (opts.pyqMains && (d.pyq_mains || []).length) h.push(BLOCKS.red('🎯 Previous Year Questions – Mains'), ...d.pyq_mains.map((x) => BLOCKS.pyq(`<p>${label(['PYQ', x.exam, x.year, x.marks ? `${x.marks} marks` : '', x.syllabus], true)} <strong>${fm(x.q)}</strong></p>`)));
  if (opts.mockPrelims && (d.mock_prelims || []).length) h.push(BLOCKS.red('Prelims Practice Questions'), ...d.mock_prelims.map((x) => mcq(x, ['Mock', x.syllabus])));
  if (opts.mockMains && (d.mock_mains || []).length) {
    h.push(BLOCKS.red('Mains Practice Questions'));
    d.mock_mains.forEach((x) => {
      h.push(`<p>${label(['Mock', x.marks ? `${x.marks} marks` : '', x.words ? `${x.words} words` : '', x.syllabus])} <strong>${fm(x.q)}</strong></p>`);
      if (opts.hindi && x.q_hi) h.push(`<p><strong>${fm(x.q_hi)}</strong></p>`);
      if ((x.structure || []).length) h.push('<h4>Answer Structure</h4>', struct(x.structure));
      if ((x.answer || []).length) h.push('<h4>Model Answer</h4>', struct(x.answer));
      if (opts.hindi && (x.answer_hi || []).length) h.push('<h4>आदर्श उत्तर</h4>', struct(x.answer_hi));
    });
  }
  return h.join('');
}
export const PAGE_BREAK = '<div data-page-break></div>';

/* ---------------- cover page (full-bleed image) ---------------- */
const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
export const DEFAULT_COVER = {
  date: '', coverage: 'GS I, II, III, IV & Essay', platform: 'YouTube / Telegram PDF',
  vision: 'To democratize civil services preparation by breaking financial and geographical barriers, ensuring every aspirant—regardless of rural roots or economic background—has equal access to top-tier mentorship.',
  mission: 'To deliver high-quality, affordable digital coaching on YouTube. We replace rote learning with conceptual clarity and strategic guidance so rural aspirants can compete on equal footing with the privileged.',
  commitments: 'Democratize Access: Deliver free/affordable YouTube coaching removing financial barriers.\nConceptual Clarity: Move beyond facts to deep analytical understanding of issues.\nLevel the Playing Field: Provide top-tier exam strategies for rural & poor aspirants.\nStructured Guidance: Honest, focused direction to navigate UPSC & State PSC syllabi.',
  topics: 'THE HINDU & IE POINTERS|PIB & GOVT. SCHEMES|MAINS ANSWER STRUCTURE|PRELIMS FACTS',
  footerL: 'Free & Affordable Education Initiative', footerR: 'Connect with us: www.indias.com',
};
export async function makeCover(o) {
  const c = document.createElement('canvas'); c.width = 1588; c.height = 2246;
  const x = c.getContext('2d'); x.scale(2, 2);
  const GOLD = '#C9A634'; const RED = '#B3262E'; const F = 'Arial, Helvetica, sans-serif';
  const rr = (a, b, w, h, r) => { x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); };
  const txt = (t, px, y, size, color, weight = 'bold', align = 'center', ls = 0) => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = align; if ('letterSpacing' in x) x.letterSpacing = `${ls}px`; x.fillText(t, px, y); if ('letterSpacing' in x) x.letterSpacing = '0px'; };
  const wrap = (t, a, y, w, size, color, lh, weight = 'normal') => { x.font = `${weight} ${size}px ${F}`; x.fillStyle = color; x.textAlign = 'left'; let line = ''; t.split(' ').forEach((wd) => { const n = line ? `${line} ${wd}` : wd; if (x.measureText(n).width > w && line) { x.fillText(line, a, y); y += lh; line = wd; } else line = n; }); x.fillText(line, a, y); return y; };
  // background: slate blue with a faint grid
  const g = x.createLinearGradient(0, 0, 0, 1123); g.addColorStop(0, '#2B4268'); g.addColorStop(0.55, '#1E3050'); g.addColorStop(1, '#16233B');
  x.fillStyle = g; x.fillRect(0, 0, 794, 1123);
  x.strokeStyle = 'rgba(255,255,255,.05)'; x.lineWidth = 1;
  for (let i = 0; i <= 8; i += 1) { x.beginPath(); x.moveTo(i * 100 - 20, 0); x.lineTo(i * 100 - 60, 1123); x.stroke(); }
  for (let i = 1; i < 11; i += 1) { x.beginPath(); x.moveTo(0, i * 105); x.lineTo(794, i * 105 - 12); x.stroke(); }
  // gold double frame
  x.strokeStyle = GOLD; x.lineWidth = 2; x.strokeRect(19, 19, 756, 1085); x.lineWidth = 0.8; x.strokeRect(26, 26, 742, 1071);
  // logo tile
  const logo = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = LOGO; });
  x.save(); x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = 14; x.fillStyle = '#fff'; x.fillRect(303, 53, 189, 189); x.restore(); x.drawImage(logo, 303, 53, 189, 189);
  // slogan pill
  x.fillStyle = 'rgba(120,20,30,.92)'; rr(173, 256, 448, 29, 14.5); x.fill(); x.strokeStyle = '#D9363E'; x.lineWidth = 1.5; rr(173, 256, 448, 29, 14.5); x.stroke();
  txt(BRAND.slogan.toUpperCase(), 397, 275.5, 11.5, '#fff', 'bold', 'center', 1.4);
  // title block
  x.fillStyle = 'rgba(14,24,46,.78)'; x.fillRect(68, 297, 658, 135); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(68, 297, 658, 1);
  txt('DAILY CURRENT AFFAIRS', 397, 343, 33, '#fff', 'bold', 'center', 0.5);
  txt('NOTES & COMPREHENSIVE ANALYSIS', 397, 385, 28, GOLD, 'bold', 'center', 0.5);
  txt('ESSENTIAL FOR UPSC CSE & STATE PSC PREPARATION', 397, 413, 13, '#fff', 'bold', 'center', 1.2);
  // info bar (one line)
  x.fillStyle = 'rgba(14,24,46,.7)'; rr(68, 452, 658, 36, 6); x.fill(); x.strokeStyle = GOLD; x.lineWidth = 1; rr(68, 452, 658, 36, 6); x.stroke();
  const info = [['DATE:', o.date || ''], ['COVERAGE:', o.coverage || ''], ['PLATFORM:', o.platform || '']];
  x.font = `bold 12px ${F}`; const widths = info.map(([k, v]) => x.measureText(`${k} `).width + x.measureText(v).width); const gap = 22;
  let cx = 397 - (widths.reduce((a, b) => a + b, 0) + gap * 2) / 2;
  info.forEach(([k, v], i) => { txt(`${k} `, cx, 475, 12, GOLD, 'bold', 'left'); txt(v, cx + x.measureText(`${k} `).width, 475, 12, '#fff', 'bold', 'left'); cx += widths[i] + gap; });
  // vision / mission cards
  [['OUR VISION', o.vision, 68, GOLD], ['OUR MISSION', o.mission, 405, RED]].forEach(([t, v, a, col]) => {
    x.fillStyle = 'rgba(14,24,46,.82)'; x.fillRect(a, 507, 321, 143); x.fillStyle = col; x.fillRect(a, 507, 4, 143);
    txt(t, a + 20, 536, 14, GOLD, 'bold', 'left', 1.2); wrap(v || '', a + 20, 562, 285, 11.5, '#fff', 17.5);
  });
  // commitments
  x.fillStyle = 'rgba(14,24,46,.82)'; rr(68, 670, 658, 147, 6); x.fill();
  txt('OUR INSTITUTIONAL COMMITMENTS', 87, 697, 14, GOLD, 'bold', 'left', 1); x.fillStyle = GOLD; x.fillRect(87, 708, 620, 1);
  (o.commitments || '').split('\n').filter(Boolean).slice(0, 4).forEach((ln, i) => {
    const k = ln.indexOf(':'); const t = k > 0 ? ln.slice(0, k + 1) : ''; const d = k > 0 ? ln.slice(k + 1).trim() : ln;
    const ax = i % 2 ? 420 : 98; const ay = 733 + Math.floor(i / 2) * 45;
    x.fillStyle = '#D9363E'; x.beginPath(); x.moveTo(ax - 1, ay - 4); x.lineTo(ax + 4, ay - 9); x.lineTo(ax + 9, ay - 4); x.lineTo(ax + 4, ay + 1); x.closePath(); x.fill();
    x.font = `bold 11px ${F}`; const tw = x.measureText(`${t} `).width; txt(t, ax + 16, ay, 11, '#fff', 'bold', 'left');
    x.font = `11px ${F}`; x.fillStyle = '#fff'; x.textAlign = 'left'; let line = ''; let y = ay; let first = true; const words = d.split(' ');
    words.forEach((wd) => { const n = line ? `${line} ${wd}` : wd; const lim = first ? 290 - tw : 290; if (x.measureText(n).width > lim && line) { x.fillText(line, first ? ax + 16 + tw : ax + 16, y); y += 15; line = wd; first = false; } else line = n; });
    x.fillText(line, first ? ax + 16 + tw : ax + 16, y);
  });
  // topics strip
  x.fillStyle = 'rgba(110,20,28,.75)'; rr(68, 836, 658, 32, 6); x.fill(); x.strokeStyle = '#C0343C'; x.lineWidth = 1; rr(68, 836, 658, 32, 6); x.stroke();
  const tps = (o.topics || '').split('|').filter(Boolean).map((t) => `•  ${t.trim()}`); x.font = `bold 10px ${F}`;
  const tw2 = tps.map((t) => x.measureText(t).width); const g2 = 14; let tx = 397 - (tw2.reduce((a, b) => a + b, 0) + g2 * (tps.length - 1)) / 2;
  tps.forEach((t, i) => { txt(t, tx, 856.5, 10, '#fff', 'bold', 'left'); tx += tw2[i] + g2; });
  // footer
  x.fillStyle = GOLD; x.globalAlpha = 0.6; x.fillRect(68, 1041, 658, 1); x.globalAlpha = 1;
  txt(o.footerL || '', 68, 1070, 12, '#E6E9F0', 'normal', 'left'); txt(o.footerR || '', 726, 1070, 12, '#E6E9F0', 'normal', 'right');
  return c.toDataURL('image/jpeg', 0.92);
}
export const coverHtml = (url) => BLOCKS.img(url, 794);

/* ---------------- image helper ---------------- */
export const fileToJpeg = (file, max = 1400) => new Promise((res, rej) => {
  const r = new FileReader(); r.onerror = () => rej(new Error('Could not read image'));
  r.onload = () => {
    const i = new Image(); i.onerror = () => rej(new Error('Not a valid image'));
    i.onload = () => { const s = Math.min(1, max / Math.max(i.width, i.height)); const c = document.createElement('canvas'); c.width = Math.round(i.width * s); c.height = Math.round(i.height * s); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); res({ url: c.toDataURL('image/jpeg', 0.85), w: c.width, h: c.height }); };
    i.src = r.result;
  };
  r.readAsDataURL(file);
});
