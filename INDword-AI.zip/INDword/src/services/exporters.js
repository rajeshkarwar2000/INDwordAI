import TurndownService from 'turndown';
import { gfm } from 'turndown-plugin-gfm';
import { marked } from 'marked';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { registerPlugin } from '@capacitor/core';
import { stageToJpegs } from './svgExport.js';
const SaveAs = registerPlugin('SaveAs');
import { Share } from '@capacitor/share';
import {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType,
  AlignmentType, ImageRun, ShadingType, BorderStyle, LevelFormat, Header, Footer, PageNumber, PageOrientation,
} from 'docx';
import { PAGE_SIZES } from '../constants.js';

/* ---------------- Markdown <-> HTML ---------------- */
const td = new TurndownService({ headingStyle: 'atx', codeBlockStyle: 'fenced', bulletListMarker: '-' });
td.use(gfm);
td.keep(['u', 'sub', 'sup', 'mark']);
td.addRule('taskItem', {
  filter: (n) => n.nodeName === 'LI' && n.getAttribute('data-type') === 'taskItem',
  replacement: (_c, n) => `- [${n.getAttribute('data-checked') === 'true' ? 'x' : ' '}] ${(n.querySelector('div')?.textContent || '').trim()}\n`,
});
export const htmlToMarkdown = (html) => td.turndown(html);
export const markdownToHtml = (md) => marked.parse(md, { gfm: true, async: false });
export const bodyOf = (html) => new DOMParser().parseFromString(html, 'text/html').body.innerHTML;

/* ---------------- Saving files (web + native) ---------------- */
export async function saveBlob(name, blob) {
  if (Capacitor.isNativePlatform()) {
    const data = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(',')[1]);
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
    const f = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache });
    await Share.share({ title: name, url: f.uri, dialogTitle: `Save or share ${name}` });
    return;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

/* ---------------- PDF ---------------- */
async function exportPagedPdf(stage, meta) {
  const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import('html2canvas'), import('jspdf')]);
  const root = document.documentElement; const wasDark = root.classList.contains('dark');
  const wrap = stage.closest('.zoomwrap'); const z = wrap?.style.zoom;
  const [pw0, ph0] = PAGE_SIZES[meta.size] || PAGE_SIZES.A4; const land = meta.orientation === 'landscape';
  const [W, H] = land ? [ph0, pw0] : [pw0, ph0];
  const n = stage.querySelectorAll('.pcard').length; const GAP = 28;
  root.classList.remove('dark'); stage.classList.add('exporting'); if (wrap) wrap.style.zoom = '1';
  try {
    await new Promise((r) => setTimeout(r, 120));
    const pdf = new jsPDF({ unit: 'pt', format: [W * 0.75, H * 0.75], orientation: land ? 'landscape' : 'portrait' });
    let jpegs = null;
    try { jpegs = await stageToJpegs(stage, { W, H, GAP, n, scale: 2 }); } catch { jpegs = null; }
    for (let i = 0; i < n; i += 1) {
      let url;
      if (jpegs) url = jpegs[i];
      else {
        stage.querySelectorAll('mark').forEach((m) => { m.style.display = 'inline'; });
        const cv = await html2canvas(stage, { scale: 2, useCORS: true, backgroundColor: '#ffffff', x: 0, y: i * (H + GAP), width: W, height: H, scrollX: 0, scrollY: 0 });
        url = cv.toDataURL('image/jpeg', 0.92);
      }
      if (i) pdf.addPage([W * 0.75, H * 0.75], land ? 'landscape' : 'portrait');
      pdf.addImage(url, 'JPEG', 0, 0, W * 0.75, H * 0.75);
    }
    return pdf.output('blob');
  } finally {
    stage.classList.remove('exporting'); if (wasDark) root.classList.add('dark'); if (wrap) wrap.style.zoom = z;
  }
}

export async function exportPdf(pageEl, meta = {}) {
  if (pageEl.classList.contains('paged-stage')) return exportPagedPdf(pageEl, meta);
  const { default: html2pdf } = await import('html2pdf.js');
  const root = document.documentElement;
  const wasDark = root.classList.contains('dark');
  const wrap = pageEl.closest('.zoomwrap');
  const z = wrap?.style.zoom;
  const keep = { padding: pageEl.style.padding, width: pageEl.style.width, minHeight: pageEl.style.minHeight, backgroundColor: pageEl.style.backgroundColor };
  const [pw0, ph0] = PAGE_SIZES[meta.size] || PAGE_SIZES.A4;
  const land = meta.orientation === 'landscape';
  const [pw, ph] = land ? [ph0, pw0] : [pw0, ph0];
  const m = meta.margins || { top: 96, right: 96, bottom: 96, left: 96 };
  const mm = (px) => px * 0.264583;
  root.classList.remove('dark');
  pageEl.classList.add('exporting');
  if (wrap) wrap.style.zoom = '1';
  // the PDF library applies the margins on every page, so the element itself carries no padding
  pageEl.style.backgroundColor = meta.bg || '#ffffff';
  pageEl.style.padding = '0'; pageEl.style.width = `${pw - m.left - m.right}px`; pageEl.style.minHeight = '0';
  try {
    const mb = meta.marginBorder || { style: 'none' };
    const worker = html2pdf()
      .set({
        margin: [mm(m.top), mm(m.left), mm(m.bottom), mm(m.right)],
        html2canvas: { scale: 2, useCORS: true, backgroundColor: meta.bg || '#ffffff' },
        jsPDF: { unit: 'mm', format: [mm(pw), mm(ph)], orientation: land ? 'landscape' : 'portrait' },
        pagebreak: { mode: ['css', 'legacy'] },
      })
      .from(pageEl)
      .toPdf()
      .get('pdf')
      .then((pdf) => {
        const n = pdf.internal.getNumberOfPages();
        const W = mm(pw); const H = mm(ph);
        for (let i = 1; i <= n; i += 1) {
          pdf.setPage(i);
          if (meta.bg && meta.bg.toLowerCase() !== '#ffffff') {   // paint the page colour under the margins too
            const c = parseInt(meta.bg.slice(1), 16);
            pdf.setFillColor((c >> 16) & 255, (c >> 8) & 255, c & 255);
            pdf.rect(0, 0, W, H, 'F');
          }
        }
        if (mb.style && mb.style !== 'none') {
          const c = parseInt((mb.color || '#475569').slice(1), 16);
          const g = mm(mb.gap || 10);
          for (let i = 1; i <= n; i += 1) {
            pdf.setPage(i);
            pdf.setDrawColor((c >> 16) & 255, (c >> 8) & 255, c & 255);
            pdf.setLineWidth(mm(mb.width || 1));
            pdf.setLineDashPattern(mb.style === 'dashed' ? [3, 2] : mb.style === 'dotted' ? [0.6, 1.6] : [], 0);
            const x = mm(m.left) - g; const y = mm(m.top) - g; const w = W - mm(m.left) - mm(m.right) + 2 * g; const h = H - mm(m.top) - mm(m.bottom) + 2 * g;
            pdf.rect(x, y, w, h);
            if (mb.style === 'double') pdf.rect(x - 1.2, y - 1.2, w + 2.4, h + 2.4);
          }
        }
      });
    return await worker.outputPdf('blob');
  } finally {
    pageEl.classList.remove('exporting');
    Object.assign(pageEl.style, keep);
    if (wasDark) root.classList.add('dark');
    if (wrap) wrap.style.zoom = z;
  }
}

/* ---------------- DOCX ---------------- */
const HX = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(c || ''); return m ? m[1].toUpperCase() : undefined; };
const ALIGN = { left: AlignmentType.LEFT, center: AlignmentType.CENTER, right: AlignmentType.RIGHT, justify: AlignmentType.JUSTIFIED };

function runs(node, base = {}) {
  const out = [];
  for (const n of node.content || []) {
    if (n.type === 'hardBreak') { out.push(new TextRun({ break: 1 })); continue; }
    if (n.type !== 'text') continue;
    const o = { text: n.text, ...base };
    for (const m of n.marks || []) {
      const a = m.attrs || {};
      if (m.type === 'bold') o.bold = true;
      else if (m.type === 'italic') o.italics = true;
      else if (m.type === 'underline') o.underline = {};
      else if (m.type === 'strike') o.strike = true;
      else if (m.type === 'subscript') o.subScript = true;
      else if (m.type === 'superscript') o.superScript = true;
      else if (m.type === 'link') { o.color = '1971C2'; o.underline = {}; }
      else if (m.type === 'highlight' && HX(a.color)) o.shading = { type: ShadingType.CLEAR, fill: HX(a.color), color: 'auto' };
      else if (m.type === 'textStyle') {
        if (HX(a.color)) o.color = HX(a.color);
        if (a.fontSize) o.size = Math.round(parseFloat(a.fontSize) * 2);
        if (a.fontFamily) o.font = a.fontFamily.split(',')[0].replace(/["']/g, '').trim();
      }
    }
    out.push(new TextRun(o));
  }
  return out;
}

function toPng(src) {
  return new Promise((resolve) => {
    const i = new Image();
    i.crossOrigin = 'anonymous';
    i.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = i.naturalWidth; c.height = i.naturalHeight;
        c.getContext('2d').drawImage(i, 0, 0);
        c.toBlob(async (b) => resolve(b ? { data: new Uint8Array(await b.arrayBuffer()), w: c.width, h: c.height } : null), 'image/png');
      } catch { resolve(null); }
    };
    i.onerror = () => resolve(null);
    i.src = src;
  });
}

async function list(n, ordered, level, ctx) {
  const out = [];
  const lv = Math.min(level, 4);
  for (const li of n.content || []) {
    let first = true;
    for (const c of li.content || []) {
      if (c.type === 'paragraph' && first) {
        out.push(new Paragraph({ children: runs(c, ctx.run), ...(ordered ? { numbering: { reference: 'ol', level: lv } } : { bullet: { level: lv } }) }));
        first = false;
      } else if (c.type === 'bulletList' || c.type === 'orderedList') {
        out.push(...await list(c, c.type === 'orderedList', level + 1, ctx));
      } else out.push(...await blocks({ content: [c] }, ctx));
    }
  }
  return out;
}

async function blocks(node, ctx = {}) {
  const out = [];
  for (const n of node.content || []) {
    const a = n.attrs || {};
    const base = {
      alignment: ALIGN[a.textAlign] ?? ctx.align,
      spacing: a.lineHeight ? { line: Math.round(parseFloat(a.lineHeight) * 240), lineRule: 'auto' } : undefined,
      indent: { left: (a.indent || 0) * 540 + (ctx.indent || 0) },
      ...(ctx.para || {}),
    };
    switch (n.type) {
      case 'paragraph':
        out.push(new Paragraph({ ...base, children: runs(n, ctx.run) }));
        break;
      case 'heading':
        out.push(new Paragraph({ ...base, heading: [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3][(a.level || 1) - 1], children: runs(n, ctx.run) }));
        break;
      case 'bulletList': out.push(...await list(n, false, 0, ctx)); break;
      case 'orderedList': out.push(...await list(n, true, 0, ctx)); break;
      case 'taskList':
        for (const li of n.content || []) {
          const p = (li.content || []).find((c) => c.type === 'paragraph') || { content: [] };
          out.push(new Paragraph({ children: [new TextRun(li.attrs?.checked ? '☑ ' : '☐ '), ...runs(p, ctx.run)] }));
        }
        break;
      case 'blockquote': out.push(...await blocks(n, { ...ctx, indent: (ctx.indent || 0) + 720, run: { ...(ctx.run || {}), italics: true, color: '64748B' } })); break;
      case 'callout': out.push(...await blocks(n, { ...ctx, para: { shading: { type: ShadingType.CLEAR, fill: 'EEF4FF', color: 'auto' } } })); break;
      case 'codeBlock': {
        const lines = (n.content || []).map((t) => t.text).join('').split('\n');
        out.push(new Paragraph({ shading: { type: ShadingType.CLEAR, fill: 'F1F5F9', color: 'auto' }, children: lines.map((l, i) => new TextRun({ text: l, font: 'Courier New', size: 21, break: i ? 1 : 0 })) }));
        break;
      }
      case 'horizontalRule':
        out.push(new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: '999999', space: 1 } } }));
        break;
      case 'image': {
        const img = a.src ? await toPng(a.src) : null;
        if (!img) { out.push(new Paragraph({ children: [new TextRun({ text: '[image could not be embedded]', italics: true })] })); break; }
        const wv = String(a.width || '100%'); const w = Math.max(20, Math.min(620, wv.endsWith('%') ? Math.round(620 * parseFloat(wv) / 100) : Math.round(parseFloat(wv) || 300)));
        out.push(new Paragraph({ alignment: ALIGN[a.align] || AlignmentType.CENTER, children: [new ImageRun({ type: 'png', data: img.data, transformation: { width: w, height: Math.round(w * img.h / img.w) } })] }));
        break;
      }
      case 'table': {
        const rows = [];
        for (const r of n.content || []) {
          const cells = [];
          for (const c of r.content || []) {
            const kids = await blocks(c, ctx);
            cells.push(new TableCell({
              children: kids.length ? kids : [new Paragraph('')],
              columnSpan: c.attrs?.colspan > 1 ? c.attrs.colspan : undefined,
              rowSpan: c.attrs?.rowspan > 1 ? c.attrs.rowspan : undefined,
              shading: c.type === 'tableHeader' ? { type: ShadingType.CLEAR, fill: 'E5E7EB', color: 'auto' } : undefined,
            }));
          }
          rows.push(new TableRow({ children: cells }));
        }
        out.push(new Table({ rows, width: { size: 100, type: WidthType.PERCENTAGE } }), new Paragraph(''));
        break;
      }
      case 'shapeBox': {
        const col = HX(a.color); const fill = HX(a.fill);
        const dash = { dashed: BorderStyle.DASHED, dotted: BorderStyle.DOTTED, double: BorderStyle.DOUBLE }[a.strokeStyle] || BorderStyle.SINGLE;
        const edge = a.strokeW > 0 && a.stroke && a.shape !== 'accent' ? { style: dash, size: Math.max(2, Math.round(a.strokeW * 6)), color: HX(a.stroke) || '000000' } : { style: BorderStyle.NONE, size: 0, color: 'auto' };
        const inner = await blocks(n, { ...ctx, align: ALIGN[a.textAlign], run: { ...(ctx.run || {}), ...(col ? { color: col } : {}), ...(a.bold ? { bold: true } : {}) } });
        const pct = String(a.width || '100%').endsWith('%') ? parseFloat(a.width) : 100;
        out.push(new Table({
          alignment: ALIGN[a.align] || AlignmentType.CENTER, width: { size: pct, type: WidthType.PERCENTAGE },
          rows: [new TableRow({ children: [new TableCell({
            children: inner.length ? inner : [new Paragraph('')],
            shading: fill ? { type: ShadingType.CLEAR, fill, color: 'auto' } : undefined,
            borders: { top: edge, bottom: edge, left: edge, right: edge },
            margins: { top: Math.round(a.pad * 15), bottom: Math.round(a.pad * 15), left: Math.round(a.pad * 15) + 60, right: Math.round(a.pad * 15) + 60 },
          })] })],
        }), new Paragraph(''));
        break;
      }
      case 'pageBreak': out.push(new Paragraph({ pageBreakBefore: true })); break;
      case 'toc': out.push(...await blocks(n, ctx)); break;
      default: break;
    }
  }
  return out;
}

export async function exportDocx(json, meta = {}) {
  const children = await blocks(json);
  const [pw, ph] = PAGE_SIZES[meta.size] || PAGE_SIZES.A4;
  const m = meta.margins || { top: 96, right: 96, bottom: 96, left: 96 };
  const tw = (px) => Math.round(px * 15);
  const land = meta.orientation === 'landscape';
  const doc = new Document({
    creator: meta.author || 'INDword', title: meta.title || '', subject: meta.subject || '', keywords: meta.keywords || '',
    styles: { default: { document: { run: { size: 24, font: 'Calibri' } } } },
    numbering: {
      config: [{
        reference: 'ol',
        levels: [0, 1, 2, 3, 4].map((i) => ({
          level: i, format: LevelFormat.DECIMAL, text: `%${i + 1}.`, alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720 * (i + 1), hanging: 360 } } },
        })),
      }],
    },
    sections: [{
      properties: { page: { size: { width: tw(pw), height: tw(ph), orientation: land ? PageOrientation.LANDSCAPE : PageOrientation.PORTRAIT }, margin: { top: tw(m.top), right: tw(m.right), bottom: tw(m.bottom), left: tw(m.left) } }, column: { count: meta.columns || 1 } },
      headers: meta.header ? { default: new Header({ children: [new Paragraph(meta.header)] }) } : undefined,
      footers: (meta.footer || meta.pageNumbers) ? { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun(meta.footer ? `${meta.footer}  ` : ''), ...(meta.pageNumbers ? [new TextRun({ children: [PageNumber.CURRENT] })] : [])] })] }) } : undefined,
      children: children.length ? children : [new Paragraph('')],
    }],
  });
  return Packer.toBlob(doc);
}

export function htmlToText(html) {
  const t = html.replace(/<\/(p|h[1-6]|li|tr|blockquote|div|pre)>/gi, '\n').replace(/<br\s*\/?>/gi, '\n').replace(/<\/t[dh]>/gi, '\t').replace(/<[^>]+>/g, '');
  const ta = document.createElement('textarea'); ta.innerHTML = t;
  return ta.value.replace(/\n{3,}/g, '\n\n').trim();
}

export function fullHtml(title, html, meta = {}) {
  return `<!doctype html><html lang="${meta.lang || 'en'}"><head><meta charset="utf-8"><title>${title}</title><meta name="author" content="${meta.author || ''}"><style>body{font-family:Calibri,Carlito,Arial,sans-serif;max-width:800px;margin:40px auto;padding:0 24px;line-height:1.5;color:#111}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:6px 10px}img{max-width:100%}blockquote{border-left:4px solid #94a3b8;padding-left:1em;color:#64748b}pre{background:#0f172a;color:#e2e8f0;padding:12px;border-radius:8px}</style></head><body>${html}</body></html>`;
}

/** Native: try Documents folder, otherwise open the share sheet. Web: normal download. */
export async function saveToDevice(name, blob) {
  if (!blob || !blob.size) throw new Error('The file came out empty. Please try again.');
  if (!Capacitor.isNativePlatform()) { await saveBlob(name, blob); return 'Downloaded'; }
  try {
    const tmp = `export-${Date.now()}.tmp`;
    const CH = 3 * 170000; // ~510 KB per piece (multiple of 3 bytes)
    const b64 = (part) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(part); });
    for (let i = 0; i < blob.size; i += CH) {
      const data = await b64(blob.slice(i, i + CH));
      if (i === 0) await Filesystem.writeFile({ path: tmp, data, directory: Directory.Cache });
      else await Filesystem.appendFile({ path: tmp, data, directory: Directory.Cache });
    }
    const { uri } = await Filesystem.getUri({ path: tmp, directory: Directory.Cache });
    let r;
    try { r = await SaveAs.saveFromFile({ path: uri.replace(/^file:\/\//, ''), name, mime: blob.type || 'application/octet-stream' }); }
    finally { Filesystem.deleteFile({ path: tmp, directory: Directory.Cache }).catch(() => {}); }
    if (!r.saved) return 'Save cancelled';
    if (r.bytes !== blob.size) throw new Error(`Saved file size does not match (${r.bytes} of ${blob.size} bytes)`);
    return `Saved ${name} (${(blob.size / 1048576).toFixed(1)} MB)`;
  } catch (e) {
    if (/Could not save|empty|size does not match/i.test(String(e && e.message))) throw e; // a real write error: tell the user
    /* picker not available: use the Documents folder below */
  }
  const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
  try {
    try { await Filesystem.requestPermissions(); } catch { /* not needed on newer Android */ }
    await Filesystem.writeFile({ path: `INDword/${name}`, data, directory: Directory.Documents, recursive: true });
    return `Saved to Documents/INDword/${name}`;
  } catch {
    await saveBlob(name, blob);
    return 'Choose where to save it';
  }
}
