const wrap = (w, h, body) => `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${body}</svg>`;
const S = 'fill="#dbeafe" stroke="#2563eb" stroke-width="3" stroke-linejoin="round"';
const L = 'stroke="#2563eb" stroke-width="4" stroke-linecap="round" fill="none"';
export const SHAPES = [
  ['Rectangle', () => wrap(160, 100, `<rect x="4" y="4" width="152" height="92" ${S}/>`)],
  ['Rounded Rectangle', () => wrap(160, 100, `<rect x="4" y="4" width="152" height="92" rx="22" ${S}/>`)],
  ['Circle', () => wrap(110, 110, `<circle cx="55" cy="55" r="50" ${S}/>`)],
  ['Ellipse', () => wrap(160, 100, `<ellipse cx="80" cy="50" rx="76" ry="46" ${S}/>`)],
  ['Line', () => wrap(160, 20, `<line x1="6" y1="10" x2="154" y2="10" ${L}/>`)],
  ['Arrow', () => wrap(160, 40, `<path d="M6 20H150M130 6L150 20L130 34" ${L}/>`)],
  ['Double Arrow', () => wrap(160, 40, `<path d="M10 20H150M30 6L10 20L30 34M130 6L150 20L130 34" ${L}/>`)],
  ['Callout', () => wrap(160, 120, `<path d="M4 4H156V84H70L40 114V84H4Z" ${S}/>`)],
  ['Speech Bubble', () => wrap(160, 120, `<path d="M80 6C40 6 6 28 6 54C6 70 18 84 36 92L28 114L62 98C68 99 74 100 80 100C120 100 154 78 154 54C154 28 120 6 80 6Z" ${S}/>`)],
  ['Flowchart: Process', () => wrap(160, 90, `<rect x="4" y="4" width="152" height="82" ${S}/>`)],
  ['Flowchart: Decision', () => wrap(160, 110, `<path d="M80 4L156 55L80 106L4 55Z" ${S}/>`)],
  ['Flowchart: Terminator', () => wrap(160, 70, `<rect x="4" y="4" width="152" height="62" rx="31" ${S}/>`)],
  ['Flowchart: Data', () => wrap(160, 90, `<path d="M36 4H156L124 86H4Z" ${S}/>`)],
];
export const shapeUrl = (fn) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(fn())}`;
