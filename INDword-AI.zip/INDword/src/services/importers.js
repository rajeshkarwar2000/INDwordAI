import mammoth from 'mammoth/mammoth.browser.js';
import { docxToDoc } from './docxImport.js';
import { markdownToHtml, bodyOf } from './exporters.js';

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export const readAsDataUrl = (file) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result));
  r.onerror = () => rej(new Error('Could not read the file'));
  r.readAsDataURL(file);
});

/** Opens DOCX / TXT / Markdown / HTML. Returns { name, ext, html, notes[] }. */
export async function importFile(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const name = file.name.replace(/\.[^.]+$/, '') || 'Imported Document';
  const notes = [];
  let html;
  let meta;
  if (ext === 'docx') {
    const buffer = await file.arrayBuffer();
    try {
      const r = await docxToDoc(buffer);                       // keeps colours, shaded tables, borders, columns, images, page setup
      html = r.html || '<p></p>'; meta = r.meta;
      r.notes.forEach((m) => notes.push(m));
    } catch {
      const r = await mammoth.convertToHtml({ arrayBuffer: buffer });   // plain fallback
      html = r.value || '<p></p>';
      notes.push('This file used features INDword could not read, so it was opened in simple mode (text, tables and images only).');
    }
  } else if (ext === 'txt') {
    html = (await file.text()).split(/\r?\n/).map((l) => `<p>${esc(l)}</p>`).join('');
  } else if (ext === 'md' || ext === 'markdown') {
    html = markdownToHtml(await file.text());
  } else if (ext === 'html' || ext === 'htm') {
    html = bodyOf(await file.text());
  } else throw new Error(`.${ext || 'unknown'} files are not supported. Use DOCX, TXT, MD or HTML.`);
  return { name, ext, html, notes, meta };
}
