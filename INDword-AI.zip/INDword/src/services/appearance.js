export const WALLPAPERS = {
  aurora: { label: 'Aurora', light: 'linear-gradient(135deg,#bae6fd,#fce7f3 55%,#c7d2fe)', dark: 'linear-gradient(135deg,#09090b,#0f172a 55%,#18181b)' },
  sunset: { label: 'Sunset', light: 'linear-gradient(135deg,#fed7aa,#fecdd3 55%,#fbcfe8)', dark: 'linear-gradient(135deg,#1c1917,#3b0764 70%,#1e1b4b)' },
  ocean: { label: 'Ocean', light: 'linear-gradient(135deg,#a5f3fc,#bfdbfe 55%,#c7d2fe)', dark: 'linear-gradient(135deg,#020617,#0c4a6e 70%,#0f172a)' },
  forest: { label: 'Forest', light: 'linear-gradient(135deg,#bbf7d0,#d9f99d 55%,#a7f3d0)', dark: 'linear-gradient(135deg,#022c22,#14532d 70%,#052e16)' },
  graphite: { label: 'Graphite', light: 'linear-gradient(135deg,#e5e7eb,#f3f4f6 55%,#d1d5db)', dark: 'linear-gradient(135deg,#000,#18181b 55%,#09090b)' },
  plain: { label: 'Plain', light: '#f4f4f8', dark: '#0b0b10' },
};
export const ACCENT_CHOICES = ['#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f97316', '#10b981', '#0ea5e9'];

const rgb = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));

/** Pushes the saved appearance settings into CSS variables so every screen updates live. */
export function applyAppearance(s) {
  const root = document.documentElement;
  const st = root.style;
  const lite = !!s.reduceEffects;
  const base = rgb(/^#[0-9a-f]{6}$/i.test(s.accent) ? s.accent : '#3b82f6');
  st.setProperty('--glass-blur', `${lite ? 0 : s.glassBlur}px`);
  st.setProperty('--glass-alpha', String(lite ? 0.97 : s.glassOpacity));
  st.setProperty('--glass-border', String(s.glassBorder));
  st.setProperty('--glass-sat', String(lite ? 1 : s.glassSat));
  st.setProperty('--glass-sheen', String(s.glassSheen));
  st.setProperty('--glass-tint', String(s.glassTint));
  st.setProperty('--glass-rim', String(s.glassRim ?? 0.35));
  st.setProperty('--glass-bright', String(s.glassBright ?? 1));
  st.setProperty('--rim-rgb', s.glassRimColor === 'accent' ? base.join(' ') : '255 255 255');
  root.setAttribute('data-grain', lite ? '0' : String(s.glassGrain || 0));
  root.setAttribute('data-g-controls', s.glassControls === false ? 'off' : 'on');
  st.setProperty('--page-alpha', String(s.pageOpacity));
  [['ribbon', s.glassRibbon], ['side', s.glassSide], ['menu', s.glassMenu], ['status', s.glassStatus], ['card', s.glassCard]].forEach(([k, on]) => root.setAttribute(`data-g-${k}`, on === false ? 'off' : 'on'));
  st.setProperty('--glass-shadow', String(lite ? 0.4 : s.glassShadow));
  st.setProperty('--ui-500', base.join(' '));
  st.setProperty('--ui-400', mix(base, [255, 255, 255], 0.25).join(' '));
  st.setProperty('--ui-600', mix(base, [0, 0, 0], 0.18).join(' '));
  st.setProperty('--radius-scale', String(s.radius));
  st.setProperty('--sb', `${s.scrollSize}px`);
  const wp = WALLPAPERS[s.wallpaper] || WALLPAPERS.aurora;
  st.setProperty('--wp-light', wp.light);
  st.setProperty('--wp-dark', wp.dark);
  st.fontSize = `${16 * s.uiScale}px`;
  root.classList.toggle('reduce-motion', !!s.reduceMotion);
}

/** One-tap looks for the glass effect. */
export const GLASS_PRESETS = {
  frosted: { label: 'Frosted', glassBlur: 20, glassOpacity: 0.75, glassBorder: 0.25, glassShadow: 1, glassSat: 1.5, glassSheen: 0.35, glassTint: 0, glassRim: 0.35, glassRimColor: 'white', glassBright: 1, glassGrain: 0 },
  crystal: { label: 'Crystal', glassBlur: 14, glassOpacity: 0.3, glassBorder: 0.65, glassShadow: 0.8, glassSat: 1.8, glassSheen: 0.7, glassTint: 0, glassRim: 0.95, glassRimColor: 'white', glassBright: 1.05, glassGrain: 0 },
  liquid: { label: 'Liquid', glassBlur: 28, glassOpacity: 0.42, glassBorder: 0.55, glassShadow: 1.2, glassSat: 2, glassSheen: 0.95, glassTint: 0.06, glassRim: 1, glassRimColor: 'white', glassBright: 1.05, glassGrain: 0 },
  matte: { label: 'Matte', glassBlur: 44, glassOpacity: 0.59, glassBorder: 0.2, glassShadow: 0.8, glassSat: 1.1, glassSheen: 0.12, glassTint: 0, glassRim: 0.2, glassRimColor: 'white', glassBright: 1, glassGrain: 1 },
  aurora: { label: 'Aurora', glassBlur: 30, glassOpacity: 0.5, glassBorder: 0.5, glassShadow: 1, glassSat: 2.2, glassSheen: 0.6, glassTint: 0.22, glassRim: 0.85, glassRimColor: 'accent', glassBright: 1.05, glassGrain: 0 },
  tint: { label: 'Tint', glassBlur: 24, glassOpacity: 0.55, glassBorder: 0.4, glassShadow: 1, glassSat: 1.8, glassSheen: 0.5, glassTint: 0.18, glassRim: 0.5, glassRimColor: 'white', glassBright: 1, glassGrain: 0 },
  smoke: { label: 'Smoke', glassBlur: 32, glassOpacity: 0.88, glassBorder: 0.12, glassShadow: 1.3, glassSat: 1, glassSheen: 0.15, glassTint: 0, glassRim: 0.15, glassRimColor: 'white', glassBright: 0.95, glassGrain: 0 },
};
