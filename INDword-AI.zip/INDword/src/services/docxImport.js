import JSZip from 'jszip';
import { convertDocx } from './docxConvert.js';

/** Reads a .docx file and returns { html, meta, notes } preserving layout, colours, tables, images and page setup. */
export async function docxToDoc(buffer) {
  const zip = await JSZip.loadAsync(buffer);
  const texts = {}; const bins = {};
  await Promise.all(Object.keys(zip.files).filter((n) => !zip.files[n].dir).map(async (n) => {
    if (/\.(xml|rels)$/i.test(n)) texts[n] = await zip.file(n).async('string');
    else if (n.startsWith('word/media/')) bins[n] = await zip.file(n).async('base64');
  }));
  return convertDocx({ text: (p) => texts[p] ?? null, base64: (p) => bins[p] ?? null });
}
