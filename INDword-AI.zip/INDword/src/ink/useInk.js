import { useEffect, useRef, useState } from 'react';
import { loadCfg, saveCfg } from './cfg.js';

const EMPTY = [];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/** Ink objects (strokes, shapes, text, tables, images) live in the document meta so they save with it; tool settings stay on this device. */
export function useInk(meta, setMeta, docId) {
  const objs = meta.ink && Array.isArray(meta.ink.objs) ? meta.ink.objs : EMPTY;
  const cur = useRef(objs); cur.current = objs;
  const hist = useRef({ u: [], r: [] });
  const [ui, setUi] = useState(() => ({ tool: 'pen', finger: false, show: true, smooth: 'med', sel: null, cfg: loadCfg() }));
  const [, bump] = useState(0);
  useEffect(() => { hist.current = { u: [], r: [] }; setUi((u) => ({ ...u, sel: null })); bump((n) => n + 1); }, [docId]);

  const commit = (list, rec = true) => {
    if (rec) { hist.current.u.push(cur.current); if (hist.current.u.length > 80) hist.current.u.shift(); hist.current.r = []; }
    cur.current = list; setMeta({ ink: { objs: list } }); bump((n) => n + 1);
  };
  const patchUi = (p) => setUi((u) => ({ ...u, ...p }));
  const setCfg = (tool, patch) => setUi((u) => { const cfg = { ...u.cfg, [tool]: { ...u.cfg[tool], ...patch } }; saveCfg(cfg); return { ...u, cfg }; });
  const undo = () => { const p = hist.current.u.pop(); if (!p) return; hist.current.r.push(cur.current); commit(p, false); };
  const redo = () => { const n = hist.current.r.pop(); if (!n) return; hist.current.u.push(cur.current); commit(n, false); };
  return {
    objs, ...ui, patchUi, setCfg, uid,
    add: (o) => commit([...cur.current, o]),
    update: (o) => commit(cur.current.map((x) => (x.id === o.id ? o : x))),
    remove: (id) => { commit(cur.current.filter((o) => o.id !== id)); patchUi({ sel: null }); },
    replacePage: (p, list) => commit([...cur.current.filter((o) => o.p !== p), ...list]),
    clearPage: (p) => commit(cur.current.filter((o) => o.p !== p)),
    duplicate: (id) => { const o = cur.current.find((x) => x.id === id); if (!o) return; const n = { ...JSON.parse(JSON.stringify(o)), id: uid() }; commit([...cur.current, { ...n, ...(n.pts ? { pts: n.pts.map((q) => [q[0] + 30, q[1] + 30, q[2]]) } : n.x1 != null ? { x1: n.x1 + 30, y1: n.y1 + 30, x2: n.x2 + 30, y2: n.y2 + 30 } : { x: n.x + 30, y: n.y + 30 }) }]); patchUi({ sel: { p: n.p, id: n.id } }); },
    toFront: (id) => { const o = cur.current.find((x) => x.id === id); if (o) commit([...cur.current.filter((x) => x.id !== id), o]); },
    undo, redo, canUndo: hist.current.u.length > 0, canRedo: hist.current.r.length > 0,
  };
}
