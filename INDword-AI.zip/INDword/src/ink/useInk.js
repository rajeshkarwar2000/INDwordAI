import { useEffect, useRef, useState } from 'react';

const KEY = 'indword.ink';
const DEF = { tool: 'pen', color: '#111111', width: 3.5, finger: false, show: true, smooth: 'med' };
const load = () => { try { return { ...DEF, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return DEF; } };
const EMPTY = [];

/** Ink state: strokes live in the document meta (so they save with it); tool settings live on this device. */
export function useInk(meta, setMeta, docId) {
  const strokes = meta.ink || EMPTY;
  const cur = useRef(strokes); cur.current = strokes;
  const undoS = useRef([]); const redoS = useRef([]);
  const [tool, setTool] = useState(load);
  const [, bump] = useState(0);
  useEffect(() => { undoS.current = []; redoS.current = []; bump((n) => n + 1); }, [docId]);
  const commit = (list) => { cur.current = list; setMeta({ ink: list }); bump((n) => n + 1); };
  const set = (patch) => setTool((t) => { const n = { ...t, ...patch }; try { localStorage.setItem(KEY, JSON.stringify(n)); } catch { /* ignore */ } return n; });
  const add = (s) => { undoS.current.push({ k: 'add', s }); redoS.current = []; commit([...cur.current, s]); };
  const del = (ids) => {
    const gone = cur.current.filter((s) => ids.includes(s.id)); if (!gone.length) return;
    undoS.current.push({ k: 'del', list: gone }); redoS.current = []; commit(cur.current.filter((s) => !ids.includes(s.id)));
  };
  const clearPage = (p) => del(cur.current.filter((s) => s.p === p).map((s) => s.id));
  const apply = (op, inverse) => {
    const addIt = (inverse ? op.k === 'del' : op.k === 'add');
    if (addIt) commit([...cur.current, ...(op.s ? [op.s] : op.list)]);
    else { const ids = op.s ? [op.s.id] : op.list.map((s) => s.id); commit(cur.current.filter((s) => !ids.includes(s.id))); }
  };
  const undo = () => { const op = undoS.current.pop(); if (!op) return; redoS.current.push(op); apply(op, true); };
  const redo = () => { const op = redoS.current.pop(); if (!op) return; undoS.current.push(op); apply(op, false); };
  return { strokes, ...tool, set, add, del, clearPage, undo, redo, canUndo: undoS.current.length > 0, canRedo: redoS.current.length > 0 };
}
