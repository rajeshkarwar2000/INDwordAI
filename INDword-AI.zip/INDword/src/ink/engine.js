/** Ink engine: smoothing, shapes, hit tests and drawing. Coordinates are page-local logical pixels. */
export const TOOLS = ['pen', 'brush', 'hl', 'eraser', 'line', 'rect', 'ellipse', 'arrow'];
export const COLORS = ['#111111', '#e11d48', '#2563eb', '#16a34a', '#f59e0b', '#7c3aed', '#0891b2', '#ffffff'];
export const SIZES = [2, 3.5, 6, 10];

/* ---- One-Euro filter: removes sensor and hand jitter on slow strokes, stays responsive on fast ones ---- */
const SMOOTH = { off: null, low: { min: 6, beta: 0.03 }, med: { min: 3.2, beta: 0.02 }, high: { min: 1.8, beta: 0.012 } };
const lpa = (cut, dt) => 1 / (1 + 1 / (2 * Math.PI * cut) / dt);
export const makeFilter = (x, y, t) => ({ x, y, t, dx: 0, dy: 0 });
export function smoothPoint(f, x, y, t, scale, level = 'med') {
  const k = SMOOTH[level];
  if (!k) { f.x = x; f.y = y; f.t = t; return [x, y]; }
  const dt = Math.min(0.1, Math.max(0.002, (t - f.t) / 1000)); f.t = t;
  const a0 = lpa(1.2, dt); const vx = ((x - f.x) * scale) / dt; const vy = ((y - f.y) * scale) / dt;
  f.dx += a0 * (vx - f.dx); f.dy += a0 * (vy - f.dy);
  const a = lpa(k.min + k.beta * Math.hypot(f.dx, f.dy), dt);
  f.x += a * (x - f.x); f.y += a * (y - f.y);
  return [f.x, f.y];
}

/* ---- shapes become plain polylines, so drawing and erasing treat every stroke the same way ---- */
export function shapePoints(tool, a, b) {
  if (tool === 'line') return [a, b];
  if (tool === 'rect') return [a, [b[0], a[1]], b, [a[0], b[1]], a];
  if (tool === 'ellipse') {
    const cx = (a[0] + b[0]) / 2; const cy = (a[1] + b[1]) / 2; const rx = Math.abs(b[0] - a[0]) / 2; const ry = Math.abs(b[1] - a[1]) / 2;
    return Array.from({ length: 65 }, (_, i) => { const t = (i / 64) * Math.PI * 2; return [cx + rx * Math.cos(t), cy + ry * Math.sin(t)]; });
  }
  if (tool === 'arrow') {
    const ang = Math.atan2(b[1] - a[1], b[0] - a[0]); const L = Math.min(22, Math.hypot(b[0] - a[0], b[1] - a[1]) * 0.4);
    const h = (d) => [b[0] - L * Math.cos(ang + d), b[1] - L * Math.sin(ang + d)];
    return [a, b, h(0.45), b, h(-0.45)];
  }
  return [a, b];
}

/* ---- erasing ---- */
function segDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax; const dy = by - ay; const l = dx * dx + dy * dy;
  let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}
export function hitStroke(s, x, y, r) {
  const p = s.pts; const reach = r + (s.t === 'hl' ? s.w * 2 : s.w / 2);
  if (p.length === 1) return Math.hypot(x - p[0][0], y - p[0][1]) <= reach;
  for (let i = 1; i < p.length; i += 1) if (segDist(x, y, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) <= reach) return true;
  return false;
}

/* ---- drawing (k = backing-store scale) ---- */
const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
export function drawStroke(ctx, s, k) {
  const p = s.pts; if (!p.length) return;
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = s.c; ctx.fillStyle = s.c;
  const hl = s.t === 'hl'; const sharp = s.t === 'line' || s.t === 'rect' || s.t === 'ellipse' || s.t === 'arrow';
  if (hl) { ctx.globalAlpha = 0.38; ctx.lineCap = 'butt'; ctx.lineJoin = 'round'; }
  else if (s.t === 'brush') ctx.globalAlpha = 0.88;
  const W = (hl ? s.w * 4 : s.t === 'brush' ? s.w * 1.7 : s.w) * k;
  if (p.length === 1) { ctx.beginPath(); ctx.arc(p[0][0] * k, p[0][1] * k, Math.max(0.5, W / 2), 0, Math.PI * 2); ctx.fill(); ctx.restore(); return; }
  if (hl || sharp || p.length < 3) {
    ctx.lineWidth = W; ctx.beginPath(); ctx.moveTo(p[0][0] * k, p[0][1] * k);
    for (let i = 1; i < p.length; i += 1) ctx.lineTo(p[i][0] * k, p[i][1] * k);
    ctx.stroke(); ctx.restore(); return;
  }
  // smooth pen / brush: quadratic curves through the midpoints, width follows pressure for the pen
  let from = p[0];
  for (let i = 1; i < p.length - 1; i += 1) {
    const to = mid(p[i], p[i + 1]);
    ctx.lineWidth = s.t === 'pen' ? W * (0.45 + (p[i][2] ?? 0.5) * 0.95) : W;
    ctx.beginPath(); ctx.moveTo(from[0] * k, from[1] * k); ctx.quadraticCurveTo(p[i][0] * k, p[i][1] * k, to[0] * k, to[1] * k); ctx.stroke(); from = to;
  }
  const last = p[p.length - 1]; ctx.lineWidth = s.t === 'pen' ? W * (0.45 + (last[2] ?? 0.5) * 0.95) : W;
  ctx.beginPath(); ctx.moveTo(from[0] * k, from[1] * k); ctx.lineTo(last[0] * k, last[1] * k); ctx.stroke();
  ctx.restore();
}
