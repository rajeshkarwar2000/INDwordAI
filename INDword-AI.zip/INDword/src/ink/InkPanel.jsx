import { useRef, useState } from 'react';
import { Keyboard, Layers, LayoutGrid, Download, FileText, Move, Undo2, Redo2, Pencil, Hand, PenLine, Brush, Sparkles, Highlighter, Eraser, MousePointer2, Shapes, Type, Table2, ImagePlus, ZoomIn, ZoomOut, Eye, EyeOff, Trash2, Copy, ArrowUpToLine } from 'lucide-react';
import R from './render.js';
import { COLORS } from './cfg.js';
import { fileToJpeg } from '../services/aiNotes.js';

const chip = (on) => `min-h-[34px] rounded-full border px-3 text-sm ${on ? 'border-blue-500 bg-blue-500/20' : 'border-black/20 dark:border-white/25'}`;
const Seg = ({ value, opts, onChange }) => <div className="mb-2 flex flex-wrap gap-1">{opts.map(([v, l]) => <button key={v} type="button" className={chip(value === v)} onClick={() => onChange(v)}>{l}</button>)}</div>;
const Sld = ({ label, value, min, max, step = 1, onChange }) => (
  <label className="mb-2 block text-xs opacity-80">{label}: {Math.round(value * 100) / 100}
    <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full" /></label>
);
const Cols = ({ value, onChange, none }) => (
  <div className="mb-2 flex flex-wrap items-center gap-1.5">
    {none && <button type="button" className={chip(!value)} onClick={() => onChange(null)}>None</button>}
    {COLORS.map((c) => <button key={c} type="button" aria-label={`Colour ${c}`} onClick={() => onChange(c)} className="h-7 w-7 rounded-full border border-black/25" style={{ background: c, outline: value === c ? '2px solid #3b82f6' : 'none', outlineOffset: 1 }} />)}
    <input type="color" aria-label="Custom colour" value={/^#[0-9a-f]{6}$/i.test(value || '') ? value : '#111827'} onChange={(e) => onChange(e.target.value)} className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent p-0" />
  </div>
);
const Tog = ({ label, on, onChange }) => <button type="button" className={`${chip(on)} mb-2 mr-1`} onClick={() => onChange(!on)}>{on ? '✓ ' : ''}{label}</button>;
const Lbl = ({ children }) => <div className="mb-1 mt-1 text-xs font-semibold opacity-70">{children}</div>;

function Options({ ctl, tool, page }) {
  const c = ctl.cfg[tool]; const set = (p) => ctl.setCfg(tool, p);
  if (tool === 'pen') return (<>
    <Lbl>Pen</Lbl><Seg value={c.pen} onChange={(v) => set({ pen: v })} opts={[['ball', 'Ball'], ['natural', 'Natural'], ['calligraphy', 'Calligraphy'], ['fountain', 'Fountain']]} />
    <Lbl>Line</Lbl><Seg value={c.line} onChange={(v) => set({ line: v })} opts={[['solid', 'Solid'], ['dashed', 'Dashed'], ['dotted', 'Dotted']]} />
    {c.line !== 'solid' && <Sld label="Spacing" value={c.space} min={2} max={40} onChange={(v) => set({ space: v })} />}
    {(c.pen === 'calligraphy' || c.pen === 'fountain') && c.line === 'solid' && (<><Lbl>Nib</Lbl><Seg value={c.nib} onChange={(v) => set({ nib: v })} opts={[['chisel', 'Chisel'], ['pointed', 'Pointed']]} /><Sld label="Nib angle" value={c.angle} min={0} max={90} onChange={(v) => set({ angle: v })} /></>)}
    <Sld label="Size" value={c.size} min={1} max={24} step={0.5} onChange={(v) => set({ size: v })} /><Cols value={c.color} onChange={(v) => set({ color: v })} />
    <Lbl>Steadiness (smoothing)</Lbl><Seg value={ctl.smooth} onChange={(v) => ctl.patchUi({ smooth: v })} opts={[['off', 'Off'], ['low', 'Low'], ['med', 'Medium'], ['high', 'High']]} />
  </>);
  if (tool === 'brush') return (<>
    <Lbl>Brush</Lbl><Seg value={c.brush} onChange={(v) => set({ brush: v })} opts={[['pencil', 'Pencil'], ['oil', 'Oil'], ['spill', 'Spill'], ['watercolor', 'Watercolour'], ['crayon', 'Crayon']]} />
    <Sld label="Size" value={c.size} min={6} max={70} onChange={(v) => set({ size: v })} /><Cols value={c.color} onChange={(v) => set({ color: v })} />
  </>);
  if (tool === 'laser') return (<>
    <Lbl>Laser</Lbl><Seg value={c.mode} onChange={(v) => set({ mode: v })} opts={[['trail', 'Trail'], ['dot', 'Dot'], ['hold', 'Hold']]} />
    {c.mode === 'trail' && <Sld label="Trail (ms)" value={c.trail} min={300} max={2500} step={100} onChange={(v) => set({ trail: v })} />}
    {c.mode === 'hold' && <Sld label="Stays for (s)" value={c.delay} min={1} max={10} onChange={(v) => set({ delay: v })} />}
    <Sld label="Size" value={c.size} min={8} max={44} onChange={(v) => set({ size: v })} /><Cols value={c.color} onChange={(v) => set({ color: v })} />
  </>);
  if (tool === 'highlighter') return (<>
    <Lbl>Tip</Lbl><Seg value={c.tip} onChange={(v) => set({ tip: v })} opts={[['round', 'Round'], ['flat', 'Flat'], ['square', 'Square']]} />
    <Tog label="Straight line" on={c.straight} onChange={(v) => set({ straight: v })} />
    <Sld label="Thickness" value={c.size} min={10} max={70} onChange={(v) => set({ size: v })} /><Sld label="Opacity" value={c.alpha} min={0.15} max={0.8} step={0.05} onChange={(v) => set({ alpha: v })} />
    <Cols value={c.color} onChange={(v) => set({ color: v })} />
  </>);
  if (tool === 'eraser') return (<>
    <Lbl>Eraser</Lbl><Seg value={c.mode} onChange={(v) => set({ mode: v })} opts={[['stroke', 'Whole stroke'], ['pixel', 'Part of a stroke']]} />
    <Sld label="Size" value={c.size} min={10} max={90} onChange={(v) => set({ size: v })} />
    <button type="button" className="secondary mb-1 w-full" onClick={() => ctl.clearPage(Math.max(0, (page || 1) - 1))}><Trash2 size={16} />Clear ink on this page</button>
  </>);
  if (tool === 'select') return (<>
    <Lbl>Select and move</Lbl>
    <p className="mb-2 text-xs opacity-75">Tap an object, drag it to move, drag the blue dot to resize, tap the red dot to delete. Tap a selected text or table again to edit it.</p>
    <div className="flex flex-wrap gap-1">
      <button type="button" className="secondary" disabled={!ctl.sel} onClick={() => ctl.duplicate(ctl.sel.id)}><Copy size={16} />Duplicate</button>
      <button type="button" className="secondary" disabled={!ctl.sel} onClick={() => ctl.toFront(ctl.sel.id)}><ArrowUpToLine size={16} />To front</button>
      <button type="button" className="secondary" disabled={!ctl.sel} onClick={() => ctl.remove(ctl.sel.id)}><Trash2 size={16} />Delete</button>
    </div>
  </>);
  if (tool === 'shapes') return (<>
    <Lbl>Shape</Lbl>
    <div className="mb-2 grid grid-cols-4 gap-1">{R.SHAPES.map(([k, n]) => <button key={k} type="button" className={`${chip(c.kind === k)} !px-1 !text-[11px]`} onClick={() => set({ kind: k })}>{n}</button>)}</div>
    <Sld label="Line width" value={c.bw} min={1} max={18} step={0.5} onChange={(v) => set({ bw: v })} /><Seg value={c.dash} onChange={(v) => set({ dash: v })} opts={[['solid', 'Solid'], ['dashed', 'Dashed'], ['dotted', 'Dotted']]} />
    <Lbl>Outline</Lbl><Cols value={c.color} onChange={(v) => set({ color: v })} />
    <Tog label="Fill" on={c.fill} onChange={(v) => set({ fill: v })} />{c.fill && <Cols value={c.fillColor} onChange={(v) => set({ fillColor: v })} />}
    <Sld label="Opacity" value={c.op} min={0.2} max={1} step={0.05} onChange={(v) => set({ op: v })} />
  </>);
  if (tool === 'text') return (<>
    <Lbl>Text</Lbl>
    <Seg value={c.font} onChange={(v) => set({ font: v })} opts={['Inter', 'Bitter', 'Carlito', 'Roboto', 'JetBrains Mono'].map((f) => [f, f])} />
    <Sld label="Size" value={c.size} min={14} max={140} onChange={(v) => set({ size: v })} />
    <Tog label="B" on={c.b} onChange={(v) => set({ b: v })} /><Tog label="I" on={c.i} onChange={(v) => set({ i: v })} /><Tog label="U" on={c.u} onChange={(v) => set({ u: v })} />
    <Seg value={c.align} onChange={(v) => set({ align: v })} opts={[['left', 'Left'], ['center', 'Centre'], ['right', 'Right']]} />
    <Lbl>Colour</Lbl><Cols value={c.color} onChange={(v) => set({ color: v })} /><Lbl>Background</Lbl><Cols value={c.bg} none onChange={(v) => set({ bg: v })} />
    <p className="text-xs opacity-75">Tap or drag on the page, then type the text.</p>
  </>);
  if (tool === 'table') return (<>
    <Lbl>Table</Lbl>
    <Sld label="Rows" value={c.rows} min={1} max={20} onChange={(v) => set({ rows: v })} /><Sld label="Columns" value={c.cols} min={1} max={10} onChange={(v) => set({ cols: v })} />
    <Tog label="Header row" on={c.header} onChange={(v) => set({ header: v })} /><Tog label="Banded rows" on={c.band} onChange={(v) => set({ band: v })} />
    <Seg value={c.style} onChange={(v) => set({ style: v })} opts={[['grid', 'Grid'], ['lines', 'Lines'], ['box', 'Box']]} /><Cols value={c.color} onChange={(v) => set({ color: v })} />
    <p className="text-xs opacity-75">Drag on the page to draw the table. Tap a cell of the table to type in it.</p>
  </>);
  return null;
}

const DRAW = [['pen', PenLine, 'Pen'], ['brush', Brush, 'Brush'], ['laser', Sparkles, 'Laser pointer'], ['highlighter', Highlighter, 'Highlighter'], ['eraser', Eraser, 'Eraser'], ['select', MousePointer2, 'Select and move'], ['shapes', Shapes, 'Shapes'], ['text', Type, 'Text'], ['table', Table2, 'Table']];

/** INDnote's toolbar, in its order: pages, page view, import, switch note, move toolbar, undo, redo, stylus/finger, pen, brush, laser, highlighter, eraser, select, shapes, text, table, image, zoom. */
export default function InkPanel({ ctl, pos, onFlip, onEdit, onPages, onFit, onImport, onHome, zoom, setZoom, page }) {
  const [open, setOpen] = useState(false); const fileRef = useRef(null);
  const B = ({ icon: I, label, on, onClick, disabled }) => (
    <button type="button" title={label} aria-label={label} disabled={disabled} onClick={onClick} className={`rbtn !min-h-[44px] !min-w-[44px] disabled:opacity-30 ${on ? 'rbtn-on' : ''}`}><I size={20} /></button>
  );
  const Sep = () => <div className="mx-2 my-0.5 h-px bg-black/10 dark:bg-white/15" />;
  const pick = (t) => { if (ctl.tool === t) setOpen((o) => !o); else { ctl.patchUi({ tool: t, sel: t === 'select' ? ctl.sel : null }); setOpen(true); } };
  const addImage = async (e) => {
    const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const m = await fileToJpeg(f, 1600); const w = Math.min(640, m.w), hh = (w * m.h) / m.w;
      const o = { id: ctl.uid(), t: 'img', p: Math.max(0, (page || 1) - 1), x: (R.PAGE_W - w) / 2, y: 260, w, h: hh, src: m.url };
      ctl.add(o); ctl.patchUi({ tool: 'select', sel: { p: o.p, id: o.id } });
    } catch { /* ignore */ }
  };
  const side = pos === 'left' ? 'left-3' : 'right-9';
  return (
    <>
      <input ref={fileRef} type="file" accept="image/*" hidden onChange={addImage} />
      <div className={`glass glass-side no-print fixed z-[45] flex max-h-[calc(100dvh-230px)] w-[68px] flex-col items-center gap-0.5 overflow-y-auto rounded-3xl p-1.5 ${side} top-[190px]`} role="toolbar" aria-label="Ink tools">
        <B icon={Keyboard} label="Back to Edit mode (typing)" onClick={onEdit} />
        <Sep />
        <B icon={Layers} label="Pages" onClick={onPages} />
        <B icon={LayoutGrid} label="Page view (fit to screen)" onClick={onFit} />
        <B icon={Download} label="Import a file" onClick={onImport} />
        <B icon={FileText} label="Switch document" onClick={onHome} />
        <B icon={Move} label="Move toolbar to the other side" onClick={onFlip} />
        <Sep />
        <B icon={Undo2} label="Undo" onClick={ctl.undo} disabled={!ctl.canUndo} />
        <B icon={Redo2} label="Redo" onClick={ctl.redo} disabled={!ctl.canRedo} />
        <B icon={ctl.finger ? Hand : Pencil} label={ctl.finger ? 'Finger draws (tap: stylus only)' : 'Stylus draws, finger scrolls (tap: finger draws)'} on={ctl.finger} onClick={() => ctl.patchUi({ finger: !ctl.finger })} />
        <Sep />
        {DRAW.map(([k, I, n]) => <B key={k} icon={I} label={n} on={ctl.tool === k} onClick={() => pick(k)} />)}
        <B icon={ImagePlus} label="Image" onClick={() => fileRef.current.click()} />
        <Sep />
        <B icon={ZoomIn} label="Zoom in" onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))} />
        <B icon={ZoomOut} label="Zoom out" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} />
        <div className="text-[10px] leading-none opacity-60">{Math.round(zoom * 100)}%</div>
        <B icon={ctl.show ? Eye : EyeOff} label={ctl.show ? 'Hide ink' : 'Show ink'} onClick={() => ctl.patchUi({ show: !ctl.show })} />
      </div>
      {open && ctl.cfg[ctl.tool] && (
        <div className={`glass glass-menu no-print fixed z-[46] top-[190px] max-h-[calc(100dvh-230px)] w-[270px] overflow-y-auto rounded-2xl p-3 ${pos === 'left' ? 'left-[88px]' : 'right-[112px]'}`}>
          <Options ctl={ctl} tool={ctl.tool} page={page} />
        </div>
      )}
    </>
  );
}
