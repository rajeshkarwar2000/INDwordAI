import { PenLine, Brush, Highlighter, Eraser, Minus, Square, Circle, MoveUpRight, Undo2, Redo2, Trash2, Hand, Eye, EyeOff, ArrowLeftRight, Keyboard, Activity } from 'lucide-react';
import { COLORS, SIZES } from './engine.js';

const TOOL_ICONS = [['pen', PenLine, 'Pen'], ['brush', Brush, 'Brush'], ['hl', Highlighter, 'Highlighter'], ['eraser', Eraser, 'Eraser (removes whole strokes)'], ['line', Minus, 'Line'], ['rect', Square, 'Rectangle'], ['ellipse', Circle, 'Ellipse'], ['arrow', MoveUpRight, 'Arrow']];

/** Ink tool sidebar shown in Note mode */
export default function InkPanel({ ctl, pos, onFlip, onEdit, page }) {
  const B = ({ icon: I, label, on, onClick, disabled }) => (
    <button type="button" title={label} aria-label={label} disabled={disabled} onClick={onClick} className={`rbtn !min-h-[44px] !min-w-[44px] disabled:opacity-30 ${on ? 'rbtn-on' : ''}`}><I size={20} /></button>
  );
  const Sep = () => <div className="mx-2 my-0.5 h-px bg-black/10 dark:bg-white/15" />;
  return (
    <div className={`glass glass-side no-print fixed z-[45] flex max-h-[calc(100dvh-230px)] w-[68px] flex-col items-center gap-0.5 overflow-y-auto rounded-3xl p-1.5 ${pos === 'left' ? 'left-3' : 'right-9'} top-[190px]`} role="toolbar" aria-label="Ink tools">
      <B icon={Keyboard} label="Back to Edit mode (typing)" onClick={onEdit} />
      <Sep />
      {TOOL_ICONS.map(([k, I, n]) => <B key={k} icon={I} label={n} on={ctl.tool === k} onClick={() => ctl.set({ tool: k })} />)}
      <Sep />
      <div className="grid grid-cols-2 gap-1 p-0.5">
        {COLORS.map((c) => <button key={c} type="button" aria-label={`Colour ${c}`} onClick={() => ctl.set({ color: c })} className="h-6 w-6 rounded-full border border-black/25" style={{ background: c, outline: ctl.color === c ? '2px solid #3b82f6' : 'none', outlineOffset: 1 }} />)}
      </div>
      <input type="color" aria-label="Custom colour" value={/^#[0-9a-f]{6}$/i.test(ctl.color) ? ctl.color : '#111111'} onChange={(e) => ctl.set({ color: e.target.value })} className="h-7 w-12 cursor-pointer rounded border-0 bg-transparent p-0" />
      <Sep />
      <div className="flex flex-col items-center gap-1 py-0.5">
        {SIZES.map((s) => <button key={s} type="button" aria-label={`Size ${s}`} onClick={() => ctl.set({ width: s })} className="grid h-8 w-10 place-items-center rounded-lg" style={{ background: ctl.width === s ? 'rgba(59,130,246,.25)' : 'transparent' }}><span className="rounded-full" style={{ width: Math.max(4, s * 2.2), height: Math.max(4, s * 2.2), background: ctl.tool === 'hl' ? '#f5c518' : ctl.color, border: '1px solid rgba(0,0,0,.25)' }} /></button>)}
      </div>
      <Sep />
      <B icon={Undo2} label="Undo ink" onClick={ctl.undo} disabled={!ctl.canUndo} />
      <B icon={Redo2} label="Redo ink" onClick={ctl.redo} disabled={!ctl.canRedo} />
      <B icon={Trash2} label="Clear ink on this page" onClick={() => ctl.clearPage(Math.max(0, (page || 1) - 1))} />
      <Sep />
      <B icon={Hand} label={ctl.finger ? 'Finger draws (tap to let the finger scroll)' : 'Finger scrolls (tap to let the finger draw)'} on={ctl.finger} onClick={() => ctl.set({ finger: !ctl.finger })} />
      <B icon={Activity} label={`Pen smoothing: ${ctl.smooth}. Tap to change`} onClick={() => ctl.set({ smooth: { off: 'low', low: 'med', med: 'high', high: 'off' }[ctl.smooth] || 'med' })} />
      <div className="text-[10px] leading-none opacity-60">{ctl.smooth}</div>
      <B icon={ctl.show ? Eye : EyeOff} label={ctl.show ? 'Hide ink' : 'Show ink'} onClick={() => ctl.set({ show: !ctl.show })} />
      <B icon={ArrowLeftRight} label="Move sidebar to the other side" onClick={onFlip} />
    </div>
  );
}
