import R from './render.js';

const KEY = 'indword.ink3';
export const COLORS = ['#111827', '#e11d48', '#2563eb', '#16a34a', '#f59e0b', '#7c3aed', '#0891b2', '#ffffff'];
export const DEF = {
  pen: { color: '#111827', size: 4, pen: 'ball', line: 'solid', space: 10, nib: 'chisel', angle: 40 },
  brush: { color: '#e11d48', size: 18, brush: 'pencil' },
  laser: { color: '#ff2a2a', size: 20, mode: 'trail', trail: 900, delay: 3 },
  highlighter: { color: '#facc15', size: 30, alpha: 0.4, tip: 'flat', straight: false },
  eraser: { size: 28, mode: 'stroke' },
  shapes: { kind: 'rect', color: '#2563eb', bw: 4, fill: false, fillColor: '#bfdbfe', dash: 'solid', op: 1 },
  text: { font: 'Inter', size: 36, color: '#111827', b: false, i: false, u: false, align: 'left', lh: 1.3, bg: null },
  table: { ...R.TABLE_DEFAULTS },
};
export function loadCfg() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { /* ignore */ }
  const out = {};
  Object.keys(DEF).forEach((k) => { out[k] = { ...DEF[k], ...(saved[k] || {}) }; });
  return out;
}
export function saveCfg(cfg) { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch { /* ignore */ } }
