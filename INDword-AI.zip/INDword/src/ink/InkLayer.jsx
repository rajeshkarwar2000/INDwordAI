import { useEffect, useMemo, useRef } from 'react';
import { createPortal } from 'react-dom';
import R from './render.js';
import { smoothPoint, makeFilter } from './engine.js';

const PW = R.PAGE_W;
const FREE = { pen: 1, brush: 1, highlighter: 1 };
const touches = new Set();
const laser = { strokes: [], raf: 0, cv: null };
const near = (x, y, a, b, r) => Math.hypot(x - a, y - b) <= r;
function segD(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); }

/* ---------- laser pointer: a screen-space overlay, drawn with INDnote's renderer ---------- */
function laserLoop() {
  if (laser.raf) return;
  const tick = () => {
    laser.raf = 0; const cv = laser.cv; if (!cv) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2), w = window.innerWidth, h = window.innerHeight;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const now = performance.now(); const live = [];
    laser.strokes.forEach((st) => {
      const down = !st.end, since = now - st.end, sz = st.size * 0.8, last = st.pts[st.pts.length - 1];
      if (st.mode === 'dot') { if (!down && since > 220) return; live.push(st); R.drawLaser(ctx, [], null, st.color, sz, { head: { x: last.x, y: last.y, a: down ? 1 : 1 - since / 220 } }); }
      else if (st.mode === 'hold') {
        const fade = down ? 1 : (since - st.delay * 1000 <= 0 ? 1 : 1 - (since - st.delay * 1000) / 650); if (fade <= 0) return; live.push(st);
        R.drawLaser(ctx, st.pts, null, st.color, sz, { alpha: fade, head: down ? { x: last.x, y: last.y, a: 1 } : null });
      } else {
        const TR = st.trail; if (!down && since > TR + 60) return; live.push(st);
        while (st.pts.length > 2 && now - st.pts[0].t > TR + 60) st.pts.shift();
        const al = st.pts.map((q) => { const a = 1 - (now - q.t) / TR; return a <= 0 ? 0 : a ** 1.25; });
        R.drawLaser(ctx, st.pts, al, st.color, sz, { taper: true, head: down ? { x: last.x, y: last.y, a: 1 } : since < 150 ? { x: last.x, y: last.y, a: 1 - since / 150 } : null });
      }
    });
    laser.strokes = live; if (live.length) laser.raf = requestAnimationFrame(tick); else ctx.clearRect(0, 0, w, h);
  };
  laser.raf = requestAnimationFrame(tick);
}

/* ---------- eraser helpers ---------- */
function cutStroke(o, x, y, r) {
  const lim = r + o.size / 2; const p = o.pts; let any = false;
  for (let i = 0; i < p.length; i += 1) { if (i ? segD(x, y, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) <= lim : Math.hypot(x - p[0][0], y - p[0][1]) <= lim) { any = true; break; } }
  if (!any) return null;
  const step = Math.max(2, r / 3); const dense = [p[0]];
  for (let i = 1; i < p.length; i += 1) { const a = p[i - 1], b = p[i], n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / step)); for (let k = 1; k <= n; k += 1) dense.push([a[0] + ((b[0] - a[0]) * k) / n, a[1] + ((b[1] - a[1]) * k) / n, a[2] + (((b[2] ?? 0.5) - (a[2] ?? 0.5)) * k) / n]); }
  const frags = []; let cur = [];
  dense.forEach((q) => { if (Math.hypot(q[0] - x, q[1] - y) <= lim) { if (cur.length > 1) frags.push(cur); cur = []; } else cur.push(q); });
  if (cur.length > 1) frags.push(cur);
  return frags.map((pts, i) => ({ ...o, id: i ? `${o.id}.${i}${Math.random().toString(36).slice(2, 5)}` : o.id, pts }));
}

function PageInk({ i, W, H, top, ctl, k, zoom, scrollRef, getHl, tick }) {
  const baseC = useRef(null); const liveC = useRef(null); const g = useRef(null);
  const kk = (W * k) / PW; const u0 = (W / PW) * (zoom || 1);
  const objs = useMemo(() => ctl.objs.filter((o) => o.p === i), [ctl.objs, i]);
  const selObj = ctl.sel && ctl.sel.p === i ? objs.find((o) => o.id === ctl.sel.id) : null;

  const sizeAll = () => { const w = Math.round(W * k), h = Math.round(H * k); [getHl(), baseC.current, liveC.current].forEach((c) => { if (c && (c.width !== w || c.height !== h)) { c.width = w; c.height = h; } }); };
  const paint = (list, skip) => {
    sizeAll(); const l = skip ? list.filter((o) => o.id !== skip) : list;
    const hc = getHl(); if (hc) { const x = hc.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, hc.width, hc.height); R.drawObjsOnly(x, { objs: l }, kk, 'hl'); }
    const b = baseC.current; const x = b.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, b.width, b.height); R.drawObjsOnly(x, { objs: l }, kk, 'ink');
  };
  const live = () => { const c = liveC.current; const x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height); x.setTransform(kk, 0, 0, kk, 0, 0); return x; };
  const frame = (x, o, uu) => {
    const b = R.bbox(o); const hr = 11 / uu;
    x.save(); x.strokeStyle = '#3b82f6'; x.lineWidth = 1.5 / uu; x.setLineDash([6 / uu, 4 / uu]); x.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8); x.setLineDash([]);
    x.fillStyle = '#ef4444'; x.beginPath(); x.arc(b.x - 4, b.y - 4, hr, 0, 7); x.fill();
    x.strokeStyle = '#fff'; x.lineWidth = 2 / uu; x.beginPath(); x.moveTo(b.x - 4 - hr / 2.4, b.y - 4 - hr / 2.4); x.lineTo(b.x - 4 + hr / 2.4, b.y - 4 + hr / 2.4); x.moveTo(b.x - 4 + hr / 2.4, b.y - 4 - hr / 2.4); x.lineTo(b.x - 4 - hr / 2.4, b.y - 4 + hr / 2.4); x.stroke();
    x.fillStyle = '#3b82f6'; x.beginPath(); x.arc(b.x + b.w + 4, b.y + b.h + 4, hr, 0, 7); x.fill();
    x.restore();
  };
  const overlay = (o) => { const x = live(); if (o) frame(x, o, u0); };
  useEffect(() => { paint(objs, g.current && g.current.moving ? g.current.o.id : null); if (!g.current) overlay(selObj); }, [objs, W, H, k, tick, selObj, ctl.show]); // eslint-disable-line react-hooks/exhaustive-deps

  const pos = (e) => { const r = liveC.current.getBoundingClientRect(); const u = r.width / PW; return { x: (e.clientX - r.left) / u, y: (e.clientY - r.top) / u, u }; };
  const press = (e) => (e.pointerType === 'pen' ? e.pressure || 0.5 : 0.5);

  const drawFree = () => {
    const s = g.current; const x = live();
    if (s.full) R.drawStroke(x, s.s, 0, R.newStrokeState(s.s), true);
    else { R.drawStroke(x, s.s, s.drawn, s.st, true); }
    s.drawn = s.s.pts.length;
  };
  const drawKeep = (s) => { // incremental strokes keep earlier segments on the live canvas
    const c = liveC.current; const x = c.getContext('2d'); x.setTransform(kk, 0, 0, kk, 0, 0); R.drawStroke(x, s.s, s.drawn, s.st, true); s.drawn = s.s.pts.length;
  };
  const eraseAt = (x, y) => {
    const s = g.current; const out = []; let changed = false;
    s.work.forEach((o) => {
      if (s.mode === 'stroke' || o.t !== 's') { if (R.hit(o, x, y, s.r)) { changed = true; return; } out.push(o); return; }
      const f = cutStroke(o, x, y, s.r); if (f === null) out.push(o); else { changed = true; out.push(...f); }
    });
    if (changed) { s.work = out; s.changed = true; paint(out); }
  };
  const shapeObj = (s, cx, cy) => { const c = s.c; return { id: 'tmp', t: 'shape', p: i, kind: c.kind, x1: s.x0, y1: s.y0, x2: cx, y2: cy, color: c.color, bw: c.bw, fill: c.fill, fillColor: c.fillColor, dash: c.dash, op: c.op }; };

  const down = (e) => {
    if (!ctl.active || g.current) return;
    if (e.pointerType === 'touch' && !ctl.finger) { touches.add(e.pointerId); g.current = { pan: true, id: e.pointerId, x: e.clientX, y: e.clientY }; liveC.current.setPointerCapture(e.pointerId); return; }
    e.preventDefault(); liveC.current.setPointerCapture(e.pointerId);
    const { x, y, u } = pos(e); const tool = ctl.tool; const c = ctl.cfg; const id = e.pointerId;
    if (tool === 'laser') {
      const lc = c.laser; const st = { mode: lc.mode, color: lc.color, size: lc.size, trail: lc.trail, delay: lc.delay, pts: [{ x: e.clientX, y: e.clientY, t: performance.now() }], end: 0 };
      laser.strokes.push(st); g.current = { id, laser: st }; laserLoop(); return;
    }
    if (tool === 'eraser') { g.current = { id, erase: true, work: objs.slice(), u, mode: c.eraser.mode, r: c.eraser.size / 2 }; eraseAt(x, y); return; }
    if (tool === 'select') {
      const o = selObj;
      if (o) {
        const b = R.bbox(o); const hr = 20 / u;
        if (near(x, y, b.x - 4, b.y - 4, hr)) { ctl.remove(o.id); return; }
        if (near(x, y, b.x + b.w + 4, b.y + b.h + 4, hr)) { g.current = { id, sel: 'resize', o, b, x0: x, y0: y, u }; return; }
        if (R.hit(o, x, y, 6 / u)) { g.current = { id, sel: 'move', o, x0: x, y0: y, u, was: true }; return; }
      }
      const hit = [...objs].reverse().find((q) => R.hit(q, x, y, 8 / u));
      if (hit) { ctl.patchUi({ sel: { p: i, id: hit.id } }); g.current = { id, sel: 'move', o: hit, x0: x, y0: y, u, was: false }; }
      else { ctl.patchUi({ sel: null }); g.current = { id, sel: 'none' }; }
      return;
    }
    if (FREE[tool]) {
      const fc = c[tool]; const kind = tool === 'highlighter' ? 'hl' : tool;
      const s = { id: ctl.uid(), t: 's', p: i, tool: kind, size: fc.size, color: fc.color, seed: (Math.random() * 1e9) | 0, pts: [[x, y, press(e)]] };
      if (tool === 'pen') Object.assign(s, { pen: fc.pen, line: fc.line, space: fc.space, nib: fc.nib, angle: fc.angle });
      if (tool === 'brush') s.brush = fc.brush;
      if (tool === 'highlighter') Object.assign(s, { alpha: fc.alpha, tip: fc.tip, straight: fc.straight });
      const full = kind === 'hl' || (kind === 'pen' && s.line !== 'solid');
      g.current = { id, s, st: R.newStrokeState(s), full, f: makeFilter(x, y, e.timeStamp), u, drawn: 0, raw: [x, y], lp: press(e) };
      live(); if (full) drawFree(); else drawKeep(g.current);
      return;
    }
    // shapes, text, table: drag out a box
    g.current = { id, create: tool, x0: x, y0: y, cx: x, cy: y, u, c: c[tool === 'shapes' ? 'shapes' : tool] };
    if (tool === 'text' || tool === 'table') {
      const hit = [...objs].reverse().find((q) => q.t === tool && R.hit(q, x, y, 4 / u));
      if (hit) g.current.edit = hit;
    }
  };

  const move = (e) => {
    const s = g.current; if (!s || e.pointerId !== s.id) return;
    if (s.pan) { if (touches.size === 1 && scrollRef && scrollRef.current) scrollRef.current.scrollBy(s.x - e.clientX, s.y - e.clientY); s.x = e.clientX; s.y = e.clientY; return; }
    e.preventDefault();
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    (evs.length ? evs : [e]).forEach((ev) => {
      if (s.laser) { s.laser.pts.push({ x: ev.clientX, y: ev.clientY, t: performance.now() }); return; }
      const { x, y } = pos(ev);
      if (s.erase) { eraseAt(x, y); return; }
      if (s.sel === 'move') { const dx = x - s.x0, dy = y - s.y0; if (Math.hypot(dx, dy) * s.u > 4 || s.moved) { s.moved = true; s.moving = true; s.n = R.transform(s.o, 0, 0, 1, 1, dx, dy); } return; }
      if (s.sel === 'resize') { const sx = Math.max(0.1, (s.b.w + (x - s.x0)) / Math.max(1, s.b.w)), sy = Math.max(0.1, (s.b.h + (y - s.y0)) / Math.max(1, s.b.h)); const uni = s.o.t === 's' || s.o.t === 'text' || s.o.t === 'img'; s.moved = true; s.moving = true; s.n = R.transform(s.o, s.b.x, s.b.y, uni ? Math.min(sx, sy) : sx, uni ? Math.min(sx, sy) : sy, 0, 0); return; }
      if (s.create) { s.cx = x; s.cy = y; return; }
      if (!s.s) return;
      s.raw = [x, y];
      if (s.s.tool === 'hl' && s.s.straight) { s.s.pts = [s.s.pts[0], [x, y, 0.5]]; return; }
      const q = smoothPoint(s.f, x, y, ev.timeStamp, s.u, ctl.smooth); const l = s.s.pts[s.s.pts.length - 1];
      s.lp += (press(ev) - s.lp) * 0.35;
      if (s.s.pts.length < 2 || Math.hypot(q[0] - l[0], q[1] - l[1]) * s.u >= 1.4) s.s.pts.push([q[0], q[1], s.lp]);
    });
    if (s.s) { if (s.full) { live(); drawFree(); } else drawKeep(s); }
    else if (s.sel && s.n) { paint(objs, s.o.id); const x = live(); R.drawObj(x, s.n); frame(x, s.n, s.u); }
    else if (s.create) {
      const x = live();
      if (s.create === 'shapes') R.drawObj(x, shapeObj(s, s.cx, s.cy));
      else if (s.create === 'text' || s.create === 'table') { x.save(); x.strokeStyle = '#3b82f6'; x.setLineDash([8 / s.u, 5 / s.u]); x.lineWidth = 2 / s.u; x.strokeRect(Math.min(s.x0, s.cx), Math.min(s.y0, s.cy), Math.abs(s.cx - s.x0), Math.abs(s.cy - s.y0)); x.restore(); }
    }
  };

  const finish = (s) => {
    const c = ctl.cfg;
    if (s.s) {
      if (!(s.s.tool === 'hl' && s.s.straight)) { const l = s.s.pts[s.s.pts.length - 1]; if (Math.hypot(s.raw[0] - l[0], s.raw[1] - l[1]) * s.u > 0.6) s.s.pts.push([s.raw[0], s.raw[1], l[2]]); }
      s.s.pts = s.s.pts.map((q) => [Math.round(q[0] * 10) / 10, Math.round(q[1] * 10) / 10, Math.round((q[2] ?? 0.5) * 100) / 100]);
      live(); ctl.add(s.s); return;
    }
    if (s.erase) { live(); if (s.changed) ctl.replacePage(i, s.work); return; }
    if (s.sel === 'move' || s.sel === 'resize') {
      if (s.moved && s.n) { ctl.update(s.n); return; }
      overlay(selObj);
      if (s.was && s.o.t === 'text') ctl.ask('Edit text', 'Text', (v) => { const n = { ...s.o, text: v }; R.measureText(n); ctl.update(n); }, s.o.text);
      else if (s.was && s.o.t === 'table') editCell(s.o, s.x0, s.y0);
      return;
    }
    if (!s.create) return;
    const drag = Math.hypot(s.cx - s.x0, s.cy - s.y0); const big = drag * s.u > 14;
    live();
    if (s.create === 'shapes') {
      const k = s.c.kind; const line = R.isLineShape(k);
      const x2 = big ? s.cx : s.x0 + (line ? 240 : 220), y2 = big ? s.cy : line ? s.y0 : s.y0 + 150;
      const o = { ...shapeObj(s, x2, y2), id: ctl.uid() }; ctl.add(o); ctl.patchUi({ sel: { p: i, id: o.id } }); return;
    }
    if (s.create === 'text') {
      if (s.edit) { ctl.ask('Edit text', 'Text', (v) => { const n = { ...s.edit, text: v }; R.measureText(n); ctl.update(n); }, s.edit.text); return; }
      const x = Math.min(s.x0, s.cx), y = Math.min(s.y0, s.cy), fw = big ? Math.max(80, Math.abs(s.cx - s.x0)) : 0;
      ctl.ask('Text', 'Type your text', (v) => { const o = { id: ctl.uid(), t: 'text', p: i, x, y, text: v, ...c.text, fw: fw || undefined }; R.measureText(o); ctl.add(o); }, '');
      return;
    }
    if (s.create === 'table') {
      if (s.edit) { editCell(s.edit, s.x0, s.y0); return; }
      const x = Math.min(s.x0, s.cx), y = Math.min(s.y0, s.cy); const w = big ? Math.max(200, Math.abs(s.cx - s.x0)) : 560, h = big ? Math.max(100, Math.abs(s.cy - s.y0)) : 200;
      const t = R.newTable(x, y, w, h, { ...c.table }); t.p = i; ctl.add(t);
    }
  };
  const editCell = (t, x, y) => {
    const col = Math.min(t.cols - 1, Math.max(0, Math.floor(((x - t.x) / t.w) * t.cols))), row = Math.min(t.rows - 1, Math.max(0, Math.floor(((y - t.y) / t.h) * t.rows)));
    ctl.ask(`Cell ${row + 1}, ${col + 1}`, 'Text', (v) => { const cells = t.cells.map((r) => r.slice()); cells[row][col] = v; ctl.update({ ...t, cells }); }, (t.cells[row] && t.cells[row][col]) || '');
  };
  const up = (e) => {
    const s = g.current; if (!s || e.pointerId !== s.id) return;
    g.current = null; touches.delete(e.pointerId);
    try { liveC.current.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
    if (s.pan) return;
    if (s.laser) { s.laser.end = performance.now(); return; }
    finish(s);
  };
  const cancel = (e) => { const s = g.current; if (!s || e.pointerId !== s.id) return; g.current = null; touches.delete(e.pointerId); if (s.laser) s.laser.end = performance.now(); paint(objs); overlay(selObj); };

  return (
    <>
      <canvas ref={baseC} style={{ position: 'absolute', left: 0, top, width: W, height: H, pointerEvents: 'none' }} />
      <canvas ref={liveC} data-ink-live="1" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={cancel}
        style={{ position: 'absolute', left: 0, top, width: W, height: H, pointerEvents: ctl.active ? 'auto' : 'none', touchAction: 'none', cursor: ctl.active ? 'crosshair' : 'default' }} />
    </>
  );
}

/** Ink for every page: highlighter canvases sit under the text, everything else on top. */
export default function InkLayer({ ctl, W, H, gap, pages, zoom, scrollRef, tick }) {
  const hl = useRef([]); const lc = useRef(null);
  const k = Math.min(3, (window.devicePixelRatio || 1) * Math.max(1, zoom || 1));
  useEffect(() => { laser.cv = lc.current; return () => { laser.cv = null; }; });
  if (!ctl) return null;
  const total = pages * H + (pages - 1) * gap; const show = ctl.show ? 'block' : 'none';
  return (
    <>
      <div className="ink-hl" style={{ position: 'absolute', left: 0, top: 0, width: W, height: total, zIndex: 1, pointerEvents: 'none', display: show }}>
        {Array.from({ length: pages }, (_, i) => <canvas key={i} ref={(el) => { hl.current[i] = el; }} style={{ position: 'absolute', left: 0, top: i * (H + gap), width: W, height: H }} />)}
      </div>
      <div className="ink-layer" style={{ position: 'absolute', left: 0, top: 0, width: W, height: total, zIndex: 3, pointerEvents: 'none', display: show }}>
        {Array.from({ length: pages }, (_, i) => <PageInk key={i} i={i} W={W} H={H} top={i * (H + gap)} ctl={ctl} k={k} zoom={zoom} scrollRef={scrollRef} tick={ctl.tick} getHl={() => hl.current[i]} />)}
      </div>
      {ctl.active && createPortal(<canvas ref={lc} style={{ position: 'fixed', inset: 0, width: '100vw', height: '100vh', pointerEvents: 'none', zIndex: 60 }} />, document.body)}
    </>
  );
}
