import { useEffect, useMemo, useRef } from 'react';
import { drawStroke, hitStroke, shapePoints, makeFilter, smoothPoint } from './engine.js';

const touches = new Set();
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const r1 = (v) => Math.round(v * 10) / 10;

function PageInk({ i, W, H, top, ctl, k, scrollRef }) {
  const cv = useRef(null); const g = useRef(null);
  const list = useMemo(() => ctl.strokes.filter((s) => s.p === i), [ctl.strokes, i]);
  const paint = (skip) => { const c = cv.current; if (!c) return; const x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height); list.forEach((s) => { if (!skip || !skip.has(s.id)) drawStroke(x, s, k); }); };
  useEffect(() => { const c = cv.current; c.width = Math.round(W * k); c.height = Math.round(H * k); paint(); }, [list, W, H, k]); // eslint-disable-line react-hooks/exhaustive-deps

  const loc = (e) => { const r = cv.current.getBoundingClientRect(); const sx = r.width / W; return [(e.clientX - r.left) / sx, (e.clientY - r.top) / sx, sx]; };
  const press = (e) => (e.pointerType === 'pen' ? e.pressure || 0.5 : 0.5);
  const live = () => {
    const s = g.current; const c = cv.current; const x = c.getContext('2d');
    x.clearRect(0, 0, c.width, c.height); x.drawImage(s.base, 0, 0);
    drawStroke(x, { t: s.tool, c: s.color, w: s.w, pts: s.pts }, k);
  };
  const erase = (x, y) => {
    const s = g.current; const r = 8 + ctl.width; let hit = false;
    list.forEach((st) => { if (!s.ids.has(st.id) && hitStroke(st, x, y, r)) { s.ids.add(st.id); hit = true; } });
    if (hit) paint(s.ids);
  };

  const down = (e) => {
    if (!ctl.active || g.current) return;
    if (e.pointerType === 'touch' && !ctl.finger) { touches.add(e.pointerId); g.current = { pan: true, id: e.pointerId, x: e.clientX, y: e.clientY }; cv.current.setPointerCapture(e.pointerId); return; }
    e.preventDefault(); cv.current.setPointerCapture(e.pointerId);
    const [x, y, sx] = loc(e);
    if (ctl.tool === 'eraser') { g.current = { erase: true, id: e.pointerId, ids: new Set() }; erase(x, y); return; }
    const base = document.createElement('canvas'); base.width = cv.current.width; base.height = cv.current.height;
    const bx = base.getContext('2d'); list.forEach((s) => drawStroke(bx, s, k));
    g.current = { id: e.pointerId, tool: ctl.tool, color: ctl.color, w: ctl.width, sx, base, pts: [[x, y, press(e)]], f: makeFilter(x, y, e.timeStamp), a: [x, y], raw: [x, y] };
    live();
  };
  const move = (e) => {
    const s = g.current; if (!s || e.pointerId !== s.id) return;
    if (s.pan) { if (touches.size === 1 && scrollRef?.current) scrollRef.current.scrollBy(s.x - e.clientX, s.y - e.clientY); s.x = e.clientX; s.y = e.clientY; return; }
    e.preventDefault();
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    (evs.length ? evs : [e]).forEach((ev) => {
      const [x, y] = loc(ev);
      if (s.erase) { erase(x, y); return; }
      s.raw = [x, y];
      if (['line', 'rect', 'ellipse', 'arrow'].includes(s.tool)) { s.pts = shapePoints(s.tool, s.a, [x, y]); return; }
      const q = smoothPoint(s.f, x, y, ev.timeStamp, s.sx, ctl.smooth);
      const l = s.pts[s.pts.length - 1];
      if (s.pts.length < 2 || Math.hypot(q[0] - l[0], q[1] - l[1]) * s.sx >= 1.4) s.pts.push([q[0], q[1], press(ev)]);
    });
    if (!s.erase) live();
  };
  const up = (e) => {
    const s = g.current; if (!s || e.pointerId !== s.id) return;
    g.current = null; touches.delete(e.pointerId);
    try { cv.current.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
    if (s.pan) return;
    if (s.erase) { if (s.ids.size) ctl.del([...s.ids]); else paint(); return; }
    const shape = ['line', 'rect', 'ellipse', 'arrow'].includes(s.tool);
    if (!shape) { const l = s.pts[s.pts.length - 1]; if (Math.hypot(s.raw[0] - l[0], s.raw[1] - l[1]) * s.sx > 0.6) s.pts.push([s.raw[0], s.raw[1], l[2]]); }
    else if (s.pts.length < 2 || Math.hypot(s.raw[0] - s.a[0], s.raw[1] - s.a[1]) < 3) { paint(); return; }
    ctl.add({ id: uid(), p: i, t: s.tool, c: s.color, w: s.w, pts: s.pts.map((q) => (q[2] != null ? [r1(q[0]), r1(q[1]), Math.round(q[2] * 100) / 100] : [r1(q[0]), r1(q[1])])) });
  };
  const cancel = (e) => { const s = g.current; if (!s || e.pointerId !== s.id) return; g.current = null; touches.delete(e.pointerId); paint(); };

  return (
    <canvas ref={cv} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={cancel}
      style={{ position: 'absolute', left: 0, top, width: W, height: H, pointerEvents: ctl.active ? 'auto' : 'none', touchAction: 'none', cursor: ctl.active ? 'crosshair' : 'default' }} />
  );
}

/** One transparent drawing canvas per page, on top of the text. */
export default function InkLayer({ ctl, W, H, gap, pages, zoom, scrollRef }) {
  const k = Math.min(3, (window.devicePixelRatio || 1) * Math.max(1, zoom || 1));
  if (!ctl) return null;
  return (
    <div className="ink-layer" style={{ position: 'absolute', left: 0, top: 0, width: W, height: pages * H + (pages - 1) * gap, zIndex: 3, pointerEvents: 'none', display: ctl.show ? 'block' : 'none' }}>
      {Array.from({ length: pages }, (_, i) => <PageInk key={i} i={i} W={W} H={H} top={i * (H + gap)} ctl={ctl} k={k} scrollRef={scrollRef} />)}
    </div>
  );
}
