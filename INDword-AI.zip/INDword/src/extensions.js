import { Extension, Node, mergeAttributes } from '@tiptap/core';
import Image from '@tiptap/extension-image';
import { ReactNodeViewRenderer } from '@tiptap/react';
import { SHAPE_DEFAULTS, shapeCss } from './shapeBox.js';
import ImageView from './components/ImageView.jsx';

const px = (v) => (v || v === 0 ? `${v}px` : null);

/* Font size on the textStyle mark, e.g. "14pt" */
export const FontSize = Extension.create({
  name: 'fontSize',
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: { fontSize: {
      default: null,
      parseHTML: (el) => el.style.fontSize || null,
      renderHTML: (a) => (a.fontSize ? { style: `font-size:${a.fontSize}` } : {}),
    } } }];
  },
  addCommands() {
    return {
      setFontSize: (size) => ({ chain }) => chain().setMark('textStyle', { fontSize: size }).run(),
    };
  },
});

/* Underline styles, double strikethrough and text effects */
export const TextExtras = Extension.create({
  name: 'textExtras',
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: {
      deco: { default: null, parseHTML: (el) => el.style.textDecoration || null, renderHTML: (a) => (a.deco ? { style: `text-decoration:${a.deco}` } : {}) },
      effect: { default: null, parseHTML: (el) => el.getAttribute('data-effect'), renderHTML: (a) => (a.effect ? { 'data-effect': a.effect } : {}) },
    } }];
  },
});

/* Paragraph / heading layout: spacing, indents, shading, borders, named style */
export const BlockLayout = Extension.create({
  name: 'blockLayout',
  addGlobalAttributes() {
    const style = (key, css) => ({
      default: null,
      parseHTML: (el) => el.style[key] || null,
      renderHTML: (a) => (a[key] ? { style: `${css}:${a[key]}` } : {}),
    });
    return [{ types: ['paragraph', 'heading'], attributes: {
      lineHeight: style('lineHeight', 'line-height'),
      marginLeft: style('marginLeft', 'margin-left'),
      marginRight: style('marginRight', 'margin-right'),
      marginTop: style('marginTop', 'margin-top'),
      marginBottom: style('marginBottom', 'margin-bottom'),
      textIndent: style('textIndent', 'text-indent'),
      backgroundColor: style('backgroundColor', 'background-color'),
      borders: {
        default: null,
        parseHTML: (el) => el.getAttribute('data-borders'),
        renderHTML: (a) => (a.borders ? { 'data-borders': a.borders, style: a.borders } : {}),
      },
      pstyle: {
        default: null,
        parseHTML: (el) => (/ps-(\w+)/.exec(el.className || '') || [])[1] || null,
        renderHTML: (a) => (a.pstyle ? { class: `ps-${a.pstyle}` } : {}),
      },
    } }];
  },
});

export const PageBreak = Node.create({
  name: 'pageBreak', group: 'block', atom: true, selectable: true,
  parseHTML() { return [{ tag: 'div[data-page-break]' }]; },
  renderHTML() { return ['div', { 'data-page-break': '', class: 'page-break' }]; },
});
export const ColumnBreak = Node.create({
  name: 'columnBreak', group: 'block', atom: true, selectable: true,
  parseHTML() { return [{ tag: 'div[data-column-break]' }]; },
  renderHTML() { return ['div', { 'data-column-break': '', class: 'column-break' }]; },
});

/* Editable text shape: banner, rectangle, pill, arrow, speech bubble... */
const kebab = (k) => k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
const readAttr = (k, def, el) => {
  const raw = el.getAttribute(`data-${kebab(k)}`);
  if (raw === null) return def;
  if (typeof def === 'boolean') return raw === '1';
  if (typeof def === 'number' || k === 'radius') return raw === '' ? def : Number(raw);
  return raw;
};
export const ShapeBox = Node.create({
  name: 'shapeBox', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return Object.fromEntries(Object.entries(SHAPE_DEFAULTS).map(([k, def]) => [k, { default: def, parseHTML: (el) => readAttr(k, def, el), renderHTML: () => ({}) }]));
  },
  parseHTML() { return [{ tag: 'div[data-shape-box]' }]; },
  renderHTML({ node }) {
    const a = node.attrs;
    const data = {};
    Object.keys(SHAPE_DEFAULTS).forEach((k) => { const v = a[k]; data[`data-${kebab(k)}`] = typeof v === 'boolean' ? (v ? '1' : '0') : (v ?? ''); });
    return ['div', { 'data-shape-box': '', class: 'shape-box', ...data, style: shapeCss(a) }, 0];
  },
});

/* A run of content laid out in columns (imported from Word sections with 2 or more columns) */
export const SectionColumns = Node.create({
  name: 'sectionColumns', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return {
      columns: { default: 2, parseHTML: (el) => Number(el.getAttribute('data-columns')) || 2, renderHTML: () => ({}) },
      gap: { default: 32, parseHTML: (el) => Number(el.getAttribute('data-gap')) || 32, renderHTML: () => ({}) },
      sep: { default: false, parseHTML: (el) => el.getAttribute('data-sep') === '1', renderHTML: () => ({}) },
    };
  },
  parseHTML() { return [{ tag: 'div[data-columns]' }]; },
  renderHTML({ node }) {
    const { columns, gap, sep } = node.attrs;
    return ['div', { 'data-columns': columns, 'data-gap': gap, ...(sep ? { 'data-sep': '1' } : {}), style: `column-count:${columns};column-gap:${gap}px;${sep ? 'column-rule:1px solid #94a3b8;' : ''}` }, 0];
  },
});

export const Toc = Node.create({
  name: 'toc', group: 'block', content: 'block+', defining: true,
  parseHTML() { return [{ tag: 'div[data-toc]' }]; },
  renderHTML() { return ['div', { 'data-toc': '', class: 'toc' }, 0]; },
});

export const Callout = Node.create({
  name: 'callout', group: 'block', content: 'block+', defining: true,
  addAttributes() {
    return { type: { default: 'info', parseHTML: (el) => el.getAttribute('data-callout') || 'info', renderHTML: (a) => ({ 'data-callout': a.type }) } };
  },
  parseHTML() { return [{ tag: 'div[data-callout]' }]; },
  renderHTML({ HTMLAttributes }) { return ['div', mergeAttributes(HTMLAttributes, { class: 'callout' }), 0]; },
  addCommands() { return { setCallout: (type) => ({ commands }) => commands.wrapIn(this.name, { type }) }; },
});

/* Image: inline or floating, resizable, with its own node view (handles + toolbar) */
export const WordImage = Image.extend({
  inline: true,
  group: 'inline',
  draggable: false,
  addAttributes() {
    return {
      ...this.parent?.(),
      dx: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-dx')) || 0, renderHTML: () => ({}) },
      dy: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-dy')) || 0, renderHTML: () => ({}) },
      width: { default: null, parseHTML: (el) => el.style.width || (el.getAttribute('width') ? `${el.getAttribute('width')}px` : null), renderHTML: () => ({}) },
      align: { default: 'inline', parseHTML: (el) => el.getAttribute('data-align') || 'inline', renderHTML: () => ({}) },
      height: { default: null, parseHTML: (el) => (el.getAttribute('data-free') ? el.style.height || null : null), renderHTML: () => ({}) },
      lock: { default: true, parseHTML: (el) => el.getAttribute('data-free') !== '1', renderHTML: () => ({}) },
    };
  },
  renderHTML({ HTMLAttributes, node }) {
    const { width, align, height, lock, dx, dy } = node.attrs;
    const moved = dx || dy ? `position:relative;left:${dx}px;top:${dy}px;` : '';
    const float = align === 'left' ? 'float:left;margin:4px 16px 8px 0;' : align === 'right' ? 'float:right;margin:4px 0 8px 16px;' : align === 'center' ? 'display:block;margin:8px auto;' : '';
    const free = height && !lock;
    return ['img', mergeAttributes(HTMLAttributes, { 'data-align': align, ...(free ? { 'data-free': '1' } : {}), ...(moved ? { 'data-dx': dx, 'data-dy': dy } : {}), style: `${moved}${width ? `width:${width};` : ''}max-width:100%;height:${free ? height : 'auto'};${free ? 'object-fit:fill;' : ''}${float}` })];
  },
  addNodeView() { return ReactNodeViewRenderer(ImageView, { as: 'span' }); },
}).configure({ allowBase64: true, inline: true });
void px;
