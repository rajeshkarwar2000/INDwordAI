export const PAGE_SIZES = { A4: [794, 1123], Letter: [816, 1056], Legal: [816, 1344], Executive: [696, 1008] };

export const FONT_SETS = {
  office: ['Calibri, Carlito, sans-serif', 'Calibri, Carlito, sans-serif'],
  academic: ['"Times New Roman", Times, serif', 'Georgia, serif'],
  modern: ['Inter, sans-serif', 'Inter, sans-serif'],
  minimal: ['Roboto, sans-serif', 'Roboto, sans-serif'],
};
export const THEMES = {
  classic: { label: 'Classic Office', font: 'office', bg: '#ffffff', color: '#111111', accent: '#2563eb' },
  modern: { label: 'Modern Clean', font: 'modern', bg: '#ffffff', color: '#18181b', accent: '#0ea5e9' },
  academic: { label: 'Academic Serif', font: 'academic', bg: '#ffffff', color: '#000000', accent: '#111827' },
  dark: { label: 'Minimalist Dark', font: 'minimal', bg: '#16161c', color: '#e5e7eb', accent: '#60a5fa' },
};
export const ACCENTS = [['Office Blue', '#2563eb'], ['Emerald', '#059669'], ['Crimson', '#dc2626'], ['Amber', '#d97706']];
export const FONT_SET_LABELS = { office: 'Office', academic: 'Academic', modern: 'Modern', minimal: 'Minimal' };
export const PAGE_BGS = [['White', '#ffffff', '#111111'], ['Warm Sepia', '#f4ecd8', '#3b2f1e'], ['Dark Slate', '#1e293b', '#e2e8f0'], ['Soft Gray', '#eceff3', '#111111']];

export const FONTS = [
  ['Arial', 'Arial, Helvetica, sans-serif'], ['Calibri', 'Calibri, Carlito, sans-serif'],
  ['Times New Roman', '"Times New Roman", Times, serif'], ['Inter', 'Inter, sans-serif'],
  ['Georgia', 'Georgia, serif'], ['Courier New', '"Courier New", monospace'],
  ['Trebuchet MS', '"Trebuchet MS", sans-serif'], ['Roboto', 'Roboto, sans-serif'],
  ['JetBrains Mono', '"JetBrains Mono", monospace'],
];
export const SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 36, 48, 72];
export const TEXT_COLORS = ['#000000', '#434343', '#666666', '#999999', '#cccccc', '#ffffff', '#e03131', '#f76707',
  '#f59f00', '#2f9e44', '#1971c2', '#7048e8', '#d6336c', '#0c8599', '#862e9c', '#5c940d'];
export const STANDARD_COLORS = ['#c00000', '#ff0000', '#ffc000', '#ffff00', '#92d050', '#00b050', '#00b0f0', '#0070c0', '#002060', '#7030a0'];
export const HIGHLIGHTS = [['Yellow', '#ffff00'], ['Bright Green', '#00ff00'], ['Cyan', '#00ffff'], ['Magenta', '#ff00ff'], ['Light Pink', '#ffc0cb'], ['Dark Blue', '#00008b'], ['Orange', '#ffa500']];
export const SYMBOLS = {
  'Greek Letters': 'αβγδεζηθικλμνξοπρστυφχψωΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ',
  Mathematical: '±×÷≤≥≠≈∞√∑∏∫∂∆∇∈∉∪∩⊂⊃∀∃∴∵°′″‰¼½¾²³¹',
  Currency: '$€£¥₹¢₽₩₺₫฿₪₴₦',
  Arrows: '←→↑↓↔↕⇐⇒⇑⇓⇔↩↪↗↘↙↖➜➤',
  Geometric: '■□▲△▼▽◆◇●○★☆♠♣♥♦✓✗✔✘',
  'Special Characters': '©®™§¶†‡•…–—«»‹›“”‘’¡¿№℃℉',
};

export const newMeta = () => ({
  margins: { top: 96, right: 96, bottom: 96, left: 96 },
  orientation: 'portrait', size: 'A4', columns: 1, theme: 'classic', fontSet: 'office', accent: '#2563eb',
  bg: '#ffffff', textColor: '#111111', border: { style: 'none', color: '#94a3b8', width: 2, shadow: false },
  marginBorder: { style: 'none', color: '#475569', width: 1, gap: 10 },
  watermark: { text: '', opacity: 0.15 }, header: '', footer: '', pageNumbers: false,
  author: '', subject: '', keywords: '', lang: 'en-US', sources: [], citeStyle: 'APA',
});

export const MARGIN_PRESETS = {
  normal: { label: 'Normal (2.54 cm)', m: { top: 96, right: 96, bottom: 96, left: 96 } },
  narrow: { label: 'Narrow (1.27 cm)', m: { top: 48, right: 48, bottom: 48, left: 48 } },
  moderate: { label: 'Moderate (1.9 / 2.5 cm)', m: { top: 96, right: 72, bottom: 96, left: 72 } },
  wide: { label: 'Wide (5 cm sides)', m: { top: 96, right: 192, bottom: 96, left: 192 } },
};
