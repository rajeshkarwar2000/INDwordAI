import {
  FilePlus, FolderOpen, Save, SaveAll, Printer, Share2, Info, Home as HomeIcon, Scissors, Copy, ClipboardPaste, Paintbrush,
  Bold, Italic, Underline, Strikethrough, Subscript, Superscript, Type, Palette, Highlighter, AlignLeft, AlignCenter, AlignRight,
  AlignJustify, List, ListOrdered, ListChecks, IndentIncrease, IndentDecrease, ArrowDownUp, Pilcrow, Eraser, CaseSensitive,
  Sparkles, PaintBucket, Square, ArrowDownAZ, ArrowUpAZ, Search, Replace, MousePointer2, MousePointer, FileText, Layers,
} from 'lucide-react';
import { Btn, Group, Item, Sep, Menu, ColorMenu, ExportMenu } from './ui.jsx';
import { FONTS, SIZES, HIGHLIGHTS } from '../constants.js';

/* ======================= FILE ======================= */
export function FileTab({ c }) {
  const { act, dlg } = c;
  return (
    <>
      <Group title="New">
        <Menu width={260} trigger={() => <Btn icon={FilePlus} label="New" caret />}>
          {(close) => (<>
            <Item icon={FileText} onClick={() => { act.newBlank(); close(); }}>Blank Document</Item>
            <Item icon={Layers} onClick={() => { act.goHome('templates'); close(); }}>New from Template</Item>
            <Item icon={Copy} onClick={() => { act.duplicateCurrent(); close(); }}>New from Existing Document</Item>
          </>)}
        </Menu>
      </Group>
      <Group title="Open">
        <Btn icon={HomeIcon} label="Recent" onClick={() => act.goHome('recent')} />
        <Btn icon={FolderOpen} label="Local Device" onClick={act.pickFile} />
        <Btn icon={FolderOpen} label="Browse" onClick={() => act.goHome('open')} />
      </Group>
      <Group title="Save">
        <Btn icon={Save} label="Save" onClick={act.save} />
        <Btn icon={SaveAll} label="Save All" onClick={act.save} />
        <Btn icon={SaveAll} label="Save As" onClick={() => dlg('saveas')} />
        <Btn icon={Layers} label="Save as Template" onClick={act.saveTemplate} />
      </Group>
      <Group title="Export">
        <ExportMenu onExport={act.exportAs} label="Export As" />
      </Group>
      <Group title="Print & Share">
        <Btn icon={Printer} label="Print" onClick={() => dlg('print')} />
        <Menu width={240} trigger={() => <Btn icon={Share2} label="Share" caret />}>
          {(close) => (<>
            <Sep>Android share sheet</Sep>
            {[['pdf', 'Share PDF'], ['md', 'Share Markdown'], ['docx', 'Share File (Word)'], ['html', 'Share HTML']].map(([k, n]) => <Item key={k} onClick={() => { act.share(k); close(); }}>{n}</Item>)}
            <Item onClick={() => { act.copyText(); close(); }}>Copy document text</Item>
          </>)}
        </Menu>
      </Group>
      <Group title="Info">
        <Btn icon={Info} label="Properties" onClick={() => dlg('props')} />
        <Btn icon={Info} label="About" onClick={() => dlg('about')} />
      </Group>
    </>
  );
}

/* ======================= HOME ======================= */
const CHARS_CASE = {
  sentence: (t) => t.toLowerCase().replace(/(^\s*|[.!?]\s+)([a-z])/g, (_, a, b) => a + b.toUpperCase()),
  lower: (t) => t.toLowerCase(),
  upper: (t) => t.toUpperCase(),
  title: (t) => t.toLowerCase().replace(/(^|\s)(\S)/g, (_, a, b) => a + b.toUpperCase()),
  toggle: (t) => [...t].map((x) => (x === x.toUpperCase() ? x.toLowerCase() : x.toUpperCase())).join(''),
};
const BORDERS = [['Bottom Border', 'border-bottom:1px solid #111'], ['Top Border', 'border-top:1px solid #111'], ['Left Border', 'border-left:3px solid #111;padding-left:8px'], ['Right Border', 'border-right:3px solid #111;padding-right:8px'], ['All Borders', 'border:1px solid #111;padding:4px 8px'], ['Outside Borders', 'border:2px solid #111;padding:4px 8px'], ['No Border', null]];
const LINE = [1.0, 1.15, 1.5, 2.0, 2.5, 3.0];

export function HomeTab({ c }) {
  const { editor, painter, flash, view, dlg, highlighter: hlt } = c;
  const ch = () => editor.chain().focus();
  const ts = editor.getAttributes('textStyle');
  const size = parseInt(ts.fontSize, 10) || 12;
  const setSize = (n) => ch().setFontSize(`${Math.min(72, Math.max(1, Math.round(n)))}pt`).run();
  const mark = (attrs) => ch().setMark('textStyle', attrs).run();
  const famName = FONTS.find(([, css]) => css === ts.fontFamily)?.[0] || 'Font';
  const blockAttrs = (attrs) => ch().updateAttributes('paragraph', attrs).updateAttributes('heading', attrs).run();
  const para = (ps) => ch().setParagraph().updateAttributes('paragraph', { pstyle: ps }).run();

  const paste = async (plain) => {
    try {
      if (!plain && navigator.clipboard.read) {
        for (const item of await navigator.clipboard.read()) {
          if (item.types.includes('text/html')) { ch().insertContent(await (await item.getType('text/html')).text()).run(); return; }
        }
      }
      ch().insertContent((await navigator.clipboard.readText()).replace(/\r?\n/g, '<br>')).run();
    } catch { flash('Clipboard blocked. Long-press in the page and choose Paste.'); }
  };
  const clip = (cmd) => { editor.commands.focus(); document.execCommand(cmd); };

  const changeCase = (fn) => {
    const { from, to, empty } = editor.state.selection;
    if (empty) { flash('Select some text first'); return; }
    const segs = [];
    editor.state.doc.nodesBetween(from, to, (n, pos) => {
      if (n.isText) { const s = Math.max(from, pos); const e = Math.min(to, pos + n.nodeSize); segs.push({ s, e, t: n.text.slice(s - pos, e - pos), marks: n.marks }); }
    });
    ch().command(({ tr, state }) => {
      segs.reverse().forEach(({ s, e, t, marks }) => tr.replaceWith(s, e, state.schema.text(fn(t), marks)));
      return true;
    }).run();
  };
  const indent = (d) => {
    if (editor.isActive('listItem') || editor.isActive('taskItem')) {
      const k = editor.isActive('taskItem') ? 'taskItem' : 'listItem';
      (d > 0 ? ch().sinkListItem(k) : ch().liftListItem(k)).run(); return;
    }
    const cur = parseInt(editor.getAttributes(editor.isActive('heading') ? 'heading' : 'paragraph').marginLeft, 10) || 0;
    const n = Math.max(0, cur + d * 36);
    blockAttrs({ marginLeft: n ? `${n}px` : null });
  };
  const sortBlocks = (asc, numeric) => {
    const { from, to } = editor.state.selection; const blocks = [];
    editor.state.doc.nodesBetween(from, to, (n, pos) => { if (n.isTextblock) { blocks.push({ n, pos }); return false; } return true; });
    if (blocks.length < 2) { flash('Select two or more paragraphs or list items'); return; }
    const texts = blocks.map((b) => b.n.textContent);
    const sorted = [...texts].sort((a, b) => (numeric ? parseFloat(a) - parseFloat(b) : a.localeCompare(b)) * (asc ? 1 : -1));
    ch().command(({ tr, state }) => {
      for (let i = blocks.length - 1; i >= 0; i -= 1) {
        const a = blocks[i].pos + 1; const b = blocks[i].pos + blocks[i].n.nodeSize - 1;
        if (sorted[i]) tr.replaceWith(a, b, state.schema.text(sorted[i])); else tr.delete(a, b);
      }
      return true;
    }).run();
  };

  const STYLES = [
    ['Normal', () => para(null), {}], ['No Spacing', () => para('nospacing'), {}],
    ['Title', () => para('title'), { fontSize: 22, fontWeight: 700 }], ['Subtitle', () => para('subtitle'), { fontSize: 16, opacity: 0.7 }],
    ['Heading 1', () => ch().setHeading({ level: 1 }).run(), { fontSize: 20, fontWeight: 700 }], ['Heading 2', () => ch().setHeading({ level: 2 }).run(), { fontSize: 17, fontWeight: 700 }],
    ['Heading 3', () => ch().setHeading({ level: 3 }).run(), { fontSize: 15, fontWeight: 700 }], ['Heading 4', () => ch().setHeading({ level: 4 }).run(), { fontWeight: 700 }],
    ['Quote', () => para('quote'), { fontStyle: 'italic' }], ['Intense Quote', () => para('intense'), { fontStyle: 'italic', color: '#2563eb' }],
    ['Blockquote', () => ch().toggleBlockquote().run(), {}], ['Code Block', () => ch().toggleCodeBlock().run(), { fontFamily: 'monospace' }],
  ];
  const activeStyle = [1, 2, 3, 4].map((l) => editor.isActive('heading', { level: l }) && `Heading ${l}`).find(Boolean) || (editor.isActive('blockquote') && 'Blockquote') || (editor.isActive('codeBlock') && 'Code Block') || 'Styles';

  return (
    <>
      <Group title="Clipboard">
        <Menu width={230} trigger={() => <Btn icon={ClipboardPaste} label="Paste" caret />}>
          {(close) => (<><Item onClick={() => { paste(false); close(); }}>Paste</Item><Item onClick={() => { paste(true); close(); }}>Paste Special: Unformatted Text</Item></>)}
        </Menu>
        <Btn icon={Scissors} title="Cut" onClick={() => clip('cut')} />
        <Btn icon={Copy} title="Copy" onClick={() => clip('copy')} />
        <Btn icon={Paintbrush} label="Painter" on={painter.on} onClick={painter.toggle} />
      </Group>

      <Group title="Font">
        <Menu width={260} trigger={() => <Btn icon={Type} label={famName} caret />}>
          {(close) => FONTS.map(([n, css]) => <Item key={n} on={ts.fontFamily === css} style={{ fontFamily: css }} onClick={() => { ch().setFontFamily(css).run(); close(); }}>{n}</Item>)}
        </Menu>
        <Btn title="Decrease font size" onClick={() => setSize(size - 1)}><span className="text-xs font-bold">A-</span></Btn>
        <Menu width={150} trigger={() => <Btn label={`${size} pt`} caret />}>
          {(close) => (<>
            <input type="number" min="1" max="200" defaultValue={size} placeholder="Custom" className="ginput mb-1" onKeyDown={(e) => { if (e.key === 'Enter') { setSize(Number(e.target.value)); close(); } }} />
            {SIZES.map((n) => <Item key={n} on={n === size} onClick={() => { setSize(n); close(); }}>{n}</Item>)}
          </>)}
        </Menu>
        <Btn title="Increase font size" onClick={() => setSize(size + 1)}><span className="text-sm font-bold">A+</span></Btn>
      </Group>

      <Group title="Characters">
        <Btn icon={Bold} title="Bold (Ctrl+B)" on={editor.isActive('bold')} onClick={() => ch().toggleBold().run()} />
        <Btn icon={Italic} title="Italic (Ctrl+I)" on={editor.isActive('italic')} onClick={() => ch().toggleItalic().run()} />
        <Btn icon={Underline} title="Underline (Ctrl+U)" on={editor.isActive('underline')} onClick={() => ch().toggleUnderline().run()} />
        <Btn icon={Strikethrough} title="Strikethrough (Ctrl+Shift+X)" on={editor.isActive('strike')} onClick={() => ch().toggleStrike().run()} />
        <Btn icon={Subscript} title="Subscript" on={editor.isActive('subscript')} onClick={() => ch().toggleSubscript().run()} />
        <Btn icon={Superscript} title="Superscript" on={editor.isActive('superscript')} onClick={() => ch().toggleSuperscript().run()} />
        <Btn icon={Eraser} title="Clear formatting" onClick={() => ch().unsetAllMarks().run()} />
        <Menu width={230} trigger={() => <Btn icon={CaseSensitive} title="Change case" caret />}>
          {(close) => [['Sentence case', 'sentence'], ['lowercase', 'lower'], ['UPPERCASE', 'upper'], ['Capitalize Each Word', 'title'], ['tOGGLE cASE', 'toggle']].map(([n, k]) => <Item key={k} onClick={() => { changeCase(CHARS_CASE[k]); close(); }}>{n}</Item>)}
        </Menu>
        <Menu width={230} trigger={() => <Btn icon={Underline} label="Style" caret />}>
          {(close) => (<>
            {[['Single', 'underline'], ['Double', 'underline double'], ['Dotted', 'underline dotted'], ['Dashed', 'underline dashed'], ['Wavy', 'underline wavy']].map(([n, v]) => <Item key={n} on={ts.deco === v} onClick={() => { mark({ deco: v }); close(); }}>{n}</Item>)}
            <Item on={ts.deco === 'line-through double'} onClick={() => { mark({ deco: ts.deco === 'line-through double' ? null : 'line-through double' }); close(); }}>Double Strikethrough</Item>
            <Item onClick={() => { mark({ deco: null }); close(); }}>None</Item>
          </>)}
        </Menu>
        <Menu width={220} trigger={() => <Btn icon={Sparkles} title="Text effects" caret />}>
          {(close) => (<>
            {['shadow', 'reflection', 'glow', 'outline'].map((k) => <Item key={k} on={ts.effect === k} onClick={() => { mark({ effect: k }); close(); }}>{k[0].toUpperCase() + k.slice(1)}</Item>)}
            <Item onClick={() => { mark({ effect: null }); close(); }}>Clear Effects</Item>
          </>)}
        </Menu>
      </Group>

      <Group title="Colour">
        <ColorMenu icon={Palette} label="Font" onPick={(col) => ch().setColor(col).run()} onClear={() => ch().unsetColor().run()} clearLabel="Automatic" />
        <Menu width={290} trigger={() => <Btn icon={Highlighter} label="Highlighter" on={hlt.on} caret />}>
          {(close) => (<>
            <Sep>Stays on until you choose another tool</Sep>
            {HIGHLIGHTS.map(([n, col]) => <Item key={n} on={hlt.on && hlt.color === col} onClick={() => { hlt.start(col); close(); }}><span className="mr-2 inline-block h-4 w-4 rounded-full align-middle" style={{ background: col }} />{n}</Item>)}
            <Item on={hlt.on && hlt.color === null} onClick={() => { hlt.start(null); close(); }}>Eraser (remove highlight)</Item>
            <Item onClick={() => { ch().unsetHighlight().run(); close(); }}>Clear highlight from selection</Item>
            {hlt.on && <Item onClick={() => { hlt.stop(); close(); }}>Stop highlighting</Item>}
          </>)}
        </Menu>
        <Btn icon={MousePointer} label="Select" on={!hlt.on} title="Select tool: stops the highlighter" onClick={hlt.stop} />
      </Group>

      <Group title="Paragraph">
        {[['left', AlignLeft], ['center', AlignCenter], ['right', AlignRight], ['justify', AlignJustify]].map(([a, I]) => <Btn key={a} icon={I} title={`Align ${a}`} on={editor.isActive({ textAlign: a })} onClick={() => ch().setTextAlign(a).run()} />)}
        <Menu width={170} trigger={() => <Btn icon={ArrowDownUp} title="Line spacing" caret />}>
          {(close) => (<>
            {LINE.map((v) => <Item key={v} on={String(editor.getAttributes('paragraph').lineHeight) === String(v)} onClick={() => { blockAttrs({ lineHeight: String(v) }); close(); }}>{v.toFixed(2).replace(/0$/, '')}</Item>)}
            <Item onClick={() => { dlg('paragraph'); close(); }}>Custom…</Item>
          </>)}
        </Menu>
        <Btn icon={List} title="Bulleted list" on={editor.isActive('bulletList')} onClick={() => ch().toggleBulletList().run()} />
        <Btn icon={ListOrdered} title="Numbered list" on={editor.isActive('orderedList')} onClick={() => ch().toggleOrderedList().run()} />
        <Btn icon={Layers} title="Multilevel list (use Indent for sub-levels)" onClick={() => ch().toggleOrderedList().run()} />
        <Btn icon={ListChecks} title="Checklist" on={editor.isActive('taskList')} onClick={() => ch().toggleTaskList().run()} />
        <Btn icon={IndentDecrease} title="Decrease indent" onClick={() => indent(-1)} />
        <Btn icon={IndentIncrease} title="Increase indent" onClick={() => indent(1)} />
        <ColorMenu icon={PaintBucket} label="Shading" onPick={(col) => blockAttrs({ backgroundColor: col })} onClear={() => blockAttrs({ backgroundColor: null })} clearLabel="No Shading" />
        <Menu width={230} trigger={() => <Btn icon={Square} title="Borders" caret />}>
          {(close) => BORDERS.map(([n, css]) => <Item key={n} onClick={() => { blockAttrs({ borders: css }); close(); }}>{n}</Item>)}
        </Menu>
        <Menu width={230} trigger={() => <Btn icon={ArrowDownAZ} title="Sort" caret />}>
          {(close) => (<>
            <Item icon={ArrowDownAZ} onClick={() => { sortBlocks(true, false); close(); }}>Sort A–Z</Item>
            <Item icon={ArrowUpAZ} onClick={() => { sortBlocks(false, false); close(); }}>Sort Z–A</Item>
            <Item onClick={() => { sortBlocks(true, true); close(); }}>Numerical Ascending</Item>
            <Item onClick={() => { sortBlocks(false, true); close(); }}>Numerical Descending</Item>
          </>)}
        </Menu>
        <Menu width={250} trigger={() => <Btn icon={Pilcrow} title="Formatting marks" on={view.marks} caret />}>
          {(close) => (<>
            <Item on={view.marks} onClick={() => { view.setMarks(!view.marks); close(); }}>Show / Hide Paragraph Marks</Item>
            <div className="px-3 py-2 text-xs opacity-60">Spaces and tab characters are not shown.</div>
          </>)}
        </Menu>
      </Group>

      <Group title="Styles">
        <Menu width={250} trigger={() => <Btn icon={Type} label={activeStyle} caret />}>
          {(close) => STYLES.map(([n, fn, st]) => <Item key={n} on={activeStyle === n} style={st} onClick={() => { fn(); close(); }}>{n}</Item>)}
        </Menu>
      </Group>

      <Group title="Editing">
        <Btn icon={Search} label="Find" onClick={() => dlg('find')} />
        <Btn icon={Replace} label="Replace" onClick={() => dlg('find')} />
        <Btn icon={MousePointer2} label="Select All" onClick={() => ch().selectAll().run()} />
      </Group>
    </>
  );
}
