import { Sparkles, FileText, LayoutTemplate, Heading2, Heading3, ListChecks, Zap, StickyNote, Type, HelpCircle, PenLine, PanelLeft, BookImage, Newspaper, KeyRound, Target, History, FilePlus2, PanelTop, Stamp, Keyboard, CircleDot, Lightbulb } from 'lucide-react';
import { Btn, Group, Item, Menu } from './ui.jsx';
import { BLOCKS, NOTES_META, TONE_NAMES, PAGE_BREAK } from '../services/aiNotes.js';
import { LOGO, BRAND } from '../brand.js';

const SECTIONS = ['📰 Why in News?', '🏛 Background', '🌍 Key Facts', '⚠ Challenges', '📌 Key Points', '⭐ Significance', '🎯 Objectives', '📊 Data', '➡ Way Forward', '✅ Conclusion'];
const MCQ = '<p><strong>Q.</strong> Question text</p><p>(A) Option</p><p>(B) Option</p><p>(C) Option</p><p>(D) Option</p><p>✅ <strong>Correct Answer: C</strong></p><p><strong>Explanation:</strong> </p>';
const MAINS = `${BLOCKS.red('UPSC GS Paper II – Mains Question')}<p>Q. Question text (250 words)</p><h4>Answer Structure</h4>${['Introduction', 'Body', 'Way Forward', 'Conclusion'].map((t) => `<p>🟢 <strong>${t}</strong></p>`).join('')}`;

export function NotesTab({ c }) {
  const { editor, setMeta, dlg, flash, meta } = c;
  const put = (html) => editor.chain().focus().insertContent(html).run();
  const ask = (title, label, fn, init = '') => c.ask(title, label, (v) => v && fn(v), init);
  const wmOn = !!meta.watermark?.image;
  return (<>
    <Group title="AI Notes">
      <Btn icon={Sparkles} label="From Images" title="Generate notes from article images" onClick={() => dlg('ainotes')} />
      <Btn icon={BookImage} label="Cover" title="indIAS cover page" onClick={() => dlg('cover')} />
    </Group>
    <Group title="Page">
      <Btn icon={LayoutTemplate} label="Notes Page" title="A4, two columns, dashed border, header, footer, logo background" onClick={() => { setMeta(NOTES_META); flash('Notes page style applied'); }} />
      <Btn icon={PanelTop} label="Header/Footer" onClick={() => ask('Header text', 'Header', (h) => ask('Footer text', 'Footer', (f) => setMeta({ header: h, footer: f, pageNumbers: true }), meta.footer || BRAND.footer), meta.header || BRAND.header)} />
      <Btn icon={Stamp} label="Logo bg" on={wmOn} title="indIAS logo background on every page" onClick={() => setMeta({ watermark: { ...meta.watermark, text: '', image: wmOn ? '' : LOGO, imageWidth: 420, opacity: meta.watermark?.opacity || 0.07 } })} />
      <Btn icon={FilePlus2} label="New topic" title="New page with title banner and Why in News" onClick={() => ask('New topic', 'Topic title', (v) => put(`${PAGE_BREAK}${BLOCKS.banner(v)}${BLOCKS.why()}`))} />
    </Group>
    <Group title="Headings">
      <Btn icon={FileText} label="Title" onClick={() => ask('Title banner', 'Topic title', (v) => put(BLOCKS.banner(v)))} />
      <Menu width={250} trigger={() => <Btn icon={Heading2} label="Section" caret />}>
        {(close) => [...SECTIONS.map((s) => <Item key={s} onClick={() => { close(); put(BLOCKS.section(s)); }}>{s}</Item>),
          <Item key="x" onClick={() => { close(); ask('Section heading', 'Heading text', (v) => put(BLOCKS.section(v))); }}>Custom…</Item>]}
      </Menu>
      <Menu width={200} trigger={() => <Btn icon={Heading3} label="Sub-head" caret />}>
        {(close) => TONE_NAMES.map((t) => <Item key={t} onClick={() => { close(); ask('Sub-heading', 'Text', (v) => put(BLOCKS.sub(v, t))); }}>{t[0].toUpperCase() + t.slice(1)} bar</Item>)}
      </Menu>
      <Btn icon={Type} label="Sub-sub" onClick={() => ask('Sub-sub-heading', 'Text', (v) => put(BLOCKS.subsub(v)))} />
    </Group>
    <Group title="Blocks">
      <Btn icon={Newspaper} label="Why in News" onClick={() => put(BLOCKS.why())} />
      <Btn icon={ListChecks} label="Point ◆" onClick={() => put(BLOCKS.point('Point'))} />
      <Btn icon={CircleDot} label="Sub-point ●" onClick={() => put(BLOCKS.sub2('Sub-point'))} />
      <Btn icon={Zap} label="Revision" onClick={() => put(BLOCKS.section('⚡ Revision Pointers') + BLOCKS.point('Point 1') + BLOCKS.point('Point 2'))} />
      <Btn icon={KeyRound} label="Keywords" onClick={() => put(BLOCKS.section('🔑 Keywords for the exam') + BLOCKS.point('Term: meaning'))} />
      <Btn icon={Target} label="Syllabus tag" onClick={() => ask('Syllabus tag', 'e.g. GS2 · Polity · Prelims + Mains', (v) => put(BLOCKS.info(`📌 Syllabus: ${v}`)), 'GS2 · Polity & Governance · Prelims + Mains')} />
      <Btn icon={Lightbulb} label="Static box" onClick={() => put(BLOCKS.red('📚 Static: Background to know') + BLOCKS.sub('Topic', 'mint') + '<p>Details…</p>')} />
    </Group>
    <Group title="Questions">
      <Btn icon={History} label="PYQ Prelims" title="Previous year question with exam and year label" onClick={() => put(BLOCKS.red('🎯 Previous Year Questions – Prelims') + '<p><strong>[PYQ · UPSC Prelims 20XX · GS · Subject]</strong> Q. Question text</p>' + MCQ.split('</p>').slice(1).join('</p>'))} />
      <Btn icon={History} label="PYQ Mains" onClick={() => put(BLOCKS.red('🎯 Previous Year Questions – Mains') + '<p><strong>[PYQ · UPSC Mains GS2 · 20XX · 15 marks]</strong> Question text</p>')} />
      <Btn icon={HelpCircle} label="Mock MCQ" onClick={() => put(BLOCKS.red('Prelims Practice Question') + MCQ)} />
      <Btn icon={PenLine} label="Mains Q&A" onClick={() => put(MAINS)} />
      <Btn icon={StickyNote} label="Note box" onClick={() => put(BLOCKS.note('Tip or key note'))} />
    </Group>
    <Group title="Panel">
      <Btn icon={PanelLeft} label="Blocks" title="Side panel: all boxes and text, with remove, rearrange and edit" on={c.view.outline && c.view.navTab === 'blocks'} onClick={() => { c.view.setNavTab('blocks'); c.view.setOutline(c.view.navTab === 'blocks' ? !c.view.outline : true); }} />
      <Btn icon={Keyboard} label="Keyboard" title="Show or hide the on-screen keyboard" on={c.kb} onClick={c.toggleKb} />
    </Group>
  </>);
}
