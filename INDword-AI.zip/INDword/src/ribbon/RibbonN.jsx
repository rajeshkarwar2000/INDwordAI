import { Sparkles, FileText, LayoutTemplate, Heading2, Heading3, ListChecks, Zap, StickyNote, Type, HelpCircle, PenLine } from 'lucide-react';
import { Btn, Group, Item, Menu } from './ui.jsx';
import { BLOCKS, NOTES_META } from '../services/aiNotes.js';

const SECTIONS = ['📰 Why in News?', '🏛 Background', '🌍 Key Facts', '⚠ Challenges', '📌 Key Points', '⭐ Significance', '🎯 Objectives', '📊 Data', '➡ Way Forward', '✅ Conclusion'];
const MCQ = '<p><strong>Q.</strong> Question text</p><p>(A) Option</p><p>(B) Option</p><p>(C) Option</p><p>(D) Option</p><p>✅ <strong>Correct Answer: C</strong></p><p><strong>Explanation:</strong> </p>';
const MAINS = `${BLOCKS.red('UPSC GS Paper II – Mains Question')}<p>Q. Question text (250 words)</p><h4>Answer Structure</h4><p>🟢 <strong>Introduction</strong></p><p>🟢 <strong>Body</strong></p><p>🟢 <strong>Way Forward</strong></p><p>🟢 <strong>Conclusion</strong></p>`;

export function NotesTab({ c }) {
  const { editor, setMeta, dlg, flash } = c;
  const put = (html) => editor.chain().focus().insertContent(html).run();
  const ask = (title, label, fn) => c.ask(title, label, (v) => v && fn(v), '');
  return (<>
    <Group title="AI Notes">
      <Btn icon={Sparkles} label="From Images" title="Generate notes from article images" onClick={() => dlg('ainotes')} />
    </Group>
    <Group title="Page">
      <Btn icon={LayoutTemplate} label="Notes Page" title="A4, narrow margins, dashed border" onClick={() => { setMeta(NOTES_META); flash('Notes page style applied'); }} />
    </Group>
    <Group title="Headings">
      <Btn icon={FileText} label="Title" onClick={() => ask('Title banner', 'Topic title', (v) => put(BLOCKS.banner(v)))} />
      <Menu width={250} trigger={() => <Btn icon={Heading2} label="Section" caret />}>
        {(close) => [...SECTIONS.map((s) => <Item key={s} onClick={() => { close(); put(BLOCKS.section(s)); }}>{s}</Item>),
          <Item key="x" onClick={() => { close(); ask('Section heading', 'Heading text', (v) => put(BLOCKS.section(v))); }}>Custom…</Item>]}
      </Menu>
      <Btn icon={Heading3} label="Sub-head" onClick={() => ask('Sub-heading', 'Text', (v) => put(BLOCKS.sub(v)))} />
      <Btn icon={Type} label="Sub-sub" onClick={() => ask('Sub-sub-heading', 'Text', (v) => put(BLOCKS.subsub(v)))} />
    </Group>
    <Group title="Blocks">
      <Btn icon={ListChecks} label="Point ◆" onClick={() => put(BLOCKS.point('Point'))} />
      <Btn icon={Zap} label="Revision" onClick={() => put(BLOCKS.section('⚡ Revision Pointers') + BLOCKS.point('Point 1') + BLOCKS.point('Point 2'))} />
      <Btn icon={HelpCircle} label="MCQ" onClick={() => put(BLOCKS.red('Prelims Practice Question') + MCQ)} />
      <Btn icon={PenLine} label="Mains" onClick={() => put(MAINS)} />
      <Btn icon={StickyNote} label="Note box" onClick={() => put(BLOCKS.note('Tip or key note'))} />
    </Group>
  </>);
}
