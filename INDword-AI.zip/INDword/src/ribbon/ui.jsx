import { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Download, FileText, FileDown, FileCode, FileType } from 'lucide-react';
import { TEXT_COLORS, STANDARD_COLORS } from '../constants.js';

export const Btn = ({ icon: I, label, on, onClick, disabled, title, caret, children }) => (
  <button type="button" title={title || label} disabled={disabled} onMouseDown={(e) => e.preventDefault()}
    onClick={onClick} className={`rbtn ${on ? 'rbtn-on' : ''}`}>
    {I && <I size={19} />}
    {label && <span className="text-xs">{label}</span>}
    {children}
    {caret && <ChevronDown size={13} className="opacity-60" />}
  </button>
);

export const Group = ({ title, children }) => (
  <div className="flex shrink-0 flex-col items-center border-r border-black/10 px-2 last:border-0 dark:border-white/10">
    <div className="flex items-center gap-0.5">{children}</div>
    <div className="pb-1 text-[10px] uppercase tracking-wide opacity-50">{title}</div>
  </div>
);

export const Item = ({ icon: I, children, on, onClick, style, disabled }) => (
  <button type="button" disabled={disabled} onClick={onClick} style={style} className={`mitem disabled:opacity-40 ${on ? 'rbtn-on' : ''}`}>
    {I && <I size={17} />}
    <span className="flex-1">{children}</span>
    {on && <span>✓</span>}
  </button>
);

export const Sep = ({ children }) => <div className="px-3 pb-1 pt-2 text-[11px] uppercase tracking-wide opacity-50">{children}</div>;

/** Glass dropdown rendered in a portal so ribbon scrolling never clips it. */
export function Menu({ trigger, width = 240, children }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0 });
  const ref = useRef(null);
  const panel = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const h = (e) => { if (!ref.current?.contains(e.target) && !panel.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('pointerdown', h);
    return () => document.removeEventListener('pointerdown', h);
  }, [open]);
  const toggle = () => {
    if (!open) {
      const r = ref.current.getBoundingClientRect();
      setPos({ top: r.bottom + 6, left: Math.max(8, Math.min(r.left, window.innerWidth - width - 8)) });
    }
    setOpen(!open);
  };
  return (
    <div ref={ref} className="inline-block">
      <div onMouseDown={(e) => e.preventDefault()} onClick={toggle}>{trigger(open)}</div>
      {open && createPortal(
        <div ref={panel} onMouseDown={(e) => { if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) e.preventDefault(); }}
          style={{ position: 'fixed', top: pos.top, left: pos.left, width, maxHeight: '62vh' }}
          className="glass glass-menu z-[60] animate-pop overflow-y-auto rounded-2xl p-1.5">
          {typeof children === 'function' ? children(() => setOpen(false)) : children}
        </div>, document.body)}
    </div>
  );
}

export function ColorMenu({ icon, label, colors = TEXT_COLORS, standard = STANDARD_COLORS, onPick, onClear, clearLabel = 'No colour' }) {
  const [hex, setHex] = useState('#');
  const valid = /^#[0-9a-f]{6}$/i.test(hex);
  return (
    <Menu width={316} trigger={() => <Btn icon={icon} label={label} caret />}>
      {(close) => (
        <div className="space-y-2 p-2">
          <Sep>Theme colours</Sep>
          <div className="grid grid-cols-8 gap-1.5">
            {colors.map((c) => <button key={c} type="button" aria-label={c} onClick={() => { onPick(c); close(); }} style={{ background: c }} className="h-9 w-9 rounded-full border border-black/15 active:scale-90" />)}
          </div>
          {standard && (
            <>
              <Sep>Standard colours</Sep>
              <div className="grid grid-cols-8 gap-1.5">
                {standard.map((c) => <button key={c} type="button" aria-label={c} onClick={() => { onPick(c); close(); }} style={{ background: c }} className="h-9 w-9 rounded-full border border-black/15 active:scale-90" />)}
              </div>
            </>
          )}
          <div className="flex items-center gap-2">
            <span className="h-11 w-11 shrink-0 rounded-lg border border-black/15" style={{ background: valid ? hex : 'transparent' }} />
            <input className="ginput" value={hex} maxLength={7} placeholder="#1971c2" onChange={(e) => setHex(e.target.value)} />
            <button type="button" className="rbtn" disabled={!valid} onClick={() => { onPick(hex); close(); }}>Apply</button>
          </div>
          <Item onClick={() => { onClear(); close(); }}>{clearLabel}</Item>
        </div>
      )}
    </Menu>
  );
}

export function ExportMenu({ onExport, label = 'Export' }) {
  const items = [['docx', FileText, 'Word (.docx)'], ['pdf', FileDown, 'PDF (.pdf)'], ['md', FileCode, 'Markdown (.md)'], ['html', FileType, 'HTML (.html)'], ['txt', FileText, 'Plain Text (.txt)']];
  return (
    <Menu width={230} trigger={() => <Btn icon={Download} label={label} title="Export" caret />}>
      {(close) => (<><Sep>Export as</Sep>{items.map(([k, I, n]) => <Item key={k} icon={I} onClick={() => { onExport(k); close(); }}>{n}</Item>)}</>)}
    </Menu>
  );
}
