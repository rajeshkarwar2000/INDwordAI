import { FileTab, HomeTab } from './RibbonA.jsx';
import { InsertTab, DesignTab, LayoutTab, PictureTab, TableTab, ShapeTab } from './RibbonB.jsx';
import { NotesTab } from './RibbonN.jsx';
import { ReferencesTab, ReviewTab, ViewTab } from './RibbonC.jsx';

const TABS = { File: FileTab, Home: HomeTab, Notes: NotesTab, Insert: InsertTab, Design: DesignTab, Layout: LayoutTab, References: ReferencesTab, Review: ReviewTab, View: ViewTab, 'Picture Format': PictureTab, 'Table Layout': TableTab, 'Shape Format': ShapeTab };

export default function Ribbon({ c, tab, setTab }) {
  const { editor } = c;
  const ctx = [];
  if (editor.isActive('image')) ctx.push('Picture Format');
  if (editor.isActive('table')) ctx.push('Table Layout');
  if (editor.isActive('shapeBox')) ctx.push('Shape Format');
  const names = ['File', 'Home', 'Notes', 'Insert', 'Design', 'Layout', 'References', 'Review', 'View', ...ctx];
  const active = names.includes(tab) ? tab : 'Home';
  const Body = TABS[active];
  return (
    <div>
      <div className="mx-3 mb-1 mt-1 flex gap-1 overflow-x-auto rounded-full bg-black/5 p-1 shadow-inner dark:bg-white/5">
        {names.map((t) => (
          <button key={t} type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => setTab(t)}
            className={`min-h-[40px] shrink-0 rounded-full px-4 text-sm font-semibold transition ${active === t ? 'rbtn-on font-bold' : ctx.includes(t) ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'hover:bg-black/5 dark:hover:bg-white/10'}`}>{t}</button>
        ))}
      </div>
      <div className="flex items-stretch overflow-x-auto px-2 pb-1"><Body c={c} /></div>
    </div>
  );
}
