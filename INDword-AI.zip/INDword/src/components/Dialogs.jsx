import { useState, useEffect } from 'react';
import { X, Upload, Link2, Image as ImageIcon, Trash2, Search, Loader2 } from 'lucide-react';
import Logo from './Logo.jsx';
import { SYMBOLS } from '../constants.js';
import { listLibraryImages, deleteLibraryImage, addLibraryImage } from '../services/store.js';
import { readAsDataUrl } from '../services/importers.js';
import { findAll, selectMatch, replaceMatch, replaceAll } from '../services/find.js';

export function Modal({ title, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/30 p-4 backdrop-blur-sm" onMouseDown={onClose}>
      <div onMouseDown={(e) => e.stopPropagation()}
        className={`glass glass-menu animate-pop max-h-[88vh] w-full ${wide ? 'max-w-2xl' : 'max-w-lg'} overflow-y-auto rounded-3xl p-5`}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button type="button" aria-label="Close" onClick={onClose} className="rbtn"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
export const Field = ({ label, children }) => (
  <label className="mb-3 block"><span className="mb-1 block text-xs font-medium opacity-70">{label}</span>{children}</label>
);
const Row = ({ children }) => <div className="mt-3 flex gap-2">{children}</div>;

export function ConfirmDialog({ title, message, confirm = 'Delete', danger = true, onOk, onClose }) {
  return (
    <Modal title={title} onClose={onClose}>
      <p className="mb-4 text-sm opacity-80">{message}</p>
      <Row>
        <button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button>
        <button type="button" className={`primary flex-1 ${danger ? '!bg-red-500' : ''}`} onClick={onOk}>{confirm}</button>
      </Row>
    </Modal>
  );
}

export function PromptDialog({ title, label, initial = '', cta = 'OK', onOk, onClose }) {
  const [v, setV] = useState(initial);
  return (
    <Modal title={title} onClose={onClose}>
      <Field label={label}><input autoFocus className="ginput" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && v.trim() && onOk(v.trim())} /></Field>
      <Row><button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button><button type="button" className="primary flex-1" disabled={!v.trim()} onClick={() => onOk(v.trim())}>{cta}</button></Row>
    </Modal>
  );
}

/* ---------------- Insert image: device / URL / library ---------------- */
const fmtSize = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
export function ImageDialog({ onInsert, onClose, flash }) {
  const [tab, setTab] = useState('device');
  const [file, setFile] = useState(null);
  const [src, setSrc] = useState('');
  const [url, setUrl] = useState('');
  const [urlOk, setUrlOk] = useState(null);
  const [lib, setLib] = useState(null);
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('new');
  const [sel, setSel] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (tab === 'library') listLibraryImages().then(setLib); }, [tab]);
  const pick = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    if (!/^image\/(jpe?g|png|webp|svg\+xml)$/.test(f.type)) { flash('Choose a JPG, PNG, WEBP or SVG image'); return; }
    setFile(f); setSrc(await readAsDataUrl(f));
  };
  const insertDevice = async () => {
    setBusy(true);
    await addLibraryImage({ name: file.name, type: file.type, size: file.size, dataUrl: src });
    onInsert(src, file.name);
  };
  const insertUrl = async () => {
    setBusy(true);
    try {
      const blob = await (await fetch(url)).blob();
      const data = await readAsDataUrl(blob);          // embed so the picture never disappears
      onInsert(data, url.split('/').pop() || 'image');
    } catch { onInsert(url, 'image'); flash('Inserted as a link: it needs internet to display'); }
  };
  const shown = (lib || []).filter((i) => i.name.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : sort === 'size' ? b.size - a.size : b.added - a.added));
  const tabs = [['device', 'Device Image', Upload], ['url', 'Web Image URL', Link2], ['library', 'Asset Library', ImageIcon]];

  return (
    <Modal title="Insert Image" onClose={onClose} wide>
      <div className="mb-4 flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
        {tabs.map(([k, l, I]) => (
          <button key={k} type="button" onClick={() => setTab(k)} className={`flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl text-xs font-medium ${tab === k ? 'bg-white shadow dark:bg-zinc-700' : ''}`}><I size={15} />{l}</button>
        ))}
      </div>
      {tab === 'device' && (
        <>
          <input type="file" accept="image/jpeg,image/png,image/webp,image/svg+xml,.jpg,.jpeg,.png,.webp,.svg" onChange={pick} className="ginput py-2.5" />
          {file && <p className="mt-2 text-sm">{file.name} · {fmtSize(file.size)}</p>}
          {src && <img src={src} alt="Preview" className="mt-3 max-h-56 rounded-xl" />}
          <Row><button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button><button type="button" className="primary flex-1" disabled={!src || busy} onClick={insertDevice}>Insert Image</button></Row>
        </>
      )}
      {tab === 'url' && (
        <>
          <Field label="Image URL"><input className="ginput" placeholder="https://example.com/photo.jpg" value={url} onChange={(e) => { setUrl(e.target.value); setUrlOk(null); }} /></Field>
          {/^https?:\/\//i.test(url) && (
            <img src={url} alt="Preview" className="max-h-56 rounded-xl" onLoad={() => setUrlOk(true)} onError={() => setUrlOk(false)} />
          )}
          {urlOk === false && <p className="mt-2 text-sm text-red-500">This image could not be loaded. Check the address.</p>}
          <Row><button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button><button type="button" className="primary flex-1" disabled={!urlOk || busy} onClick={insertUrl}>Insert Image</button></Row>
        </>
      )}
      {tab === 'library' && (
        <>
          <div className="mb-3 flex gap-2">
            <div className="relative flex-1"><Search size={16} className="absolute left-3 top-3.5 opacity-50" /><input className="ginput pl-9" placeholder="Search library" value={q} onChange={(e) => setQ(e.target.value)} /></div>
            <select className="ginput !w-36" value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Newest</option><option value="name">Name</option><option value="size">Size</option></select>
          </div>
          {!lib && <div className="flex justify-center p-6"><Loader2 className="animate-spin" /></div>}
          {lib && !shown.length && <p className="p-3 text-sm opacity-70">No images yet. Images you insert from your device are saved here.</p>}
          <div className="grid max-h-72 grid-cols-3 gap-2 overflow-y-auto">
            {shown.map((i) => (
              <button key={i.id} type="button" onClick={() => setSel(i)} className={`rounded-2xl p-1.5 text-left ${sel?.id === i.id ? 'bg-blue-500/20 ring-2 ring-blue-500' : 'bg-black/5 dark:bg-white/10'}`}>
                <img src={i.dataUrl} alt="" className="h-24 w-full rounded-xl object-cover" />
                <div className="mt-1 truncate text-xs font-medium">{i.name}</div>
                <div className="text-[11px] opacity-60">{i.type.split('/')[1]} · {fmtSize(i.size)}</div>
              </button>
            ))}
          </div>
          <Row>
            <button type="button" className="secondary" disabled={!sel} onClick={async () => { await deleteLibraryImage(sel.id); setSel(null); setLib(await listLibraryImages()); }}><Trash2 size={16} />Delete</button>
            <button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button>
            <button type="button" className="primary flex-1" disabled={!sel} onClick={() => onInsert(sel.dataUrl, sel.name)}>Insert</button>
          </Row>
        </>
      )}
    </Modal>
  );
}

/* ---------------- Link ---------------- */
export function LinkDialog({ initial, selectedText, onApply, onClose }) {
  const [text, setText] = useState(selectedText || '');
  const [href, setHref] = useState(initial || 'https://');
  const [blank, setBlank] = useState(true);
  return (
    <Modal title="Hyperlink" onClose={onClose}>
      <Field label="Text to display"><input className="ginput" value={text} onChange={(e) => setText(e.target.value)} /></Field>
      <Field label="Web address"><input autoFocus className="ginput" value={href} onChange={(e) => setHref(e.target.value)} /></Field>
      <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={blank} onChange={(e) => setBlank(e.target.checked)} /> Open in a new tab</label>
      <Row>
        <button type="button" className="secondary" onClick={() => onApply(null)}>Remove Link</button>
        <button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button>
        <button type="button" className="primary flex-1" onClick={() => onApply({ text, href, blank })}>Insert</button>
      </Row>
    </Modal>
  );
}

/* ---------------- Custom table ---------------- */
export function TableDialog({ onInsert, onClose }) {
  const [rows, setRows] = useState(3); const [cols, setCols] = useState(3); const [head, setHead] = useState(true);
  return (
    <Modal title="Insert Table" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Rows"><input type="number" min="1" max="100" className="ginput" value={rows} onChange={(e) => setRows(+e.target.value)} /></Field>
        <Field label="Columns"><input type="number" min="1" max="20" className="ginput" value={cols} onChange={(e) => setCols(+e.target.value)} /></Field>
      </div>
      <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={head} onChange={(e) => setHead(e.target.checked)} /> Header row</label>
      <Row><button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button><button type="button" className="primary flex-1" onClick={() => onInsert(Math.min(100, Math.max(1, rows)), Math.min(20, Math.max(1, cols)), head)}>Insert</button></Row>
    </Modal>
  );
}

/* ---------------- Symbols ---------------- */
export function SymbolDialog({ onPick, onClose }) {
  const [cat, setCat] = useState(Object.keys(SYMBOLS)[0]);
  return (
    <Modal title="Symbols" onClose={onClose} wide>
      <div className="mb-3 flex flex-wrap gap-1">{Object.keys(SYMBOLS).map((k) => <button key={k} type="button" onClick={() => setCat(k)} className={`rbtn ${cat === k ? 'rbtn-on' : ''}`}>{k}</button>)}</div>
      <div className="grid grid-cols-8 gap-1.5 sm:grid-cols-10">
        {[...SYMBOLS[cat]].map((c, i) => <button key={i} type="button" onClick={() => onPick(c)} className="min-h-[48px] rounded-xl bg-black/5 text-xl active:scale-90 dark:bg-white/10">{c}</button>)}
      </div>
    </Modal>
  );
}

/* ---------------- Find & Replace ---------------- */
export function FindDialog({ editor, onClose, flash }) {
  const [term, setTerm] = useState(''); const [rep, setRep] = useState(''); const [cs, setCs] = useState(false); const [idx, setIdx] = useState(-1);
  const go = (dir) => {
    const all = findAll(editor, term, cs);
    if (!all.length) { flash('No matches found'); return; }
    const n = (idx + dir + all.length) % all.length; setIdx(n); selectMatch(editor, all[n]); flash(`${n + 1} of ${all.length}`);
  };
  const replaceOne = () => {
    const all = findAll(editor, term, cs); const m = all[idx] || all[0];
    if (m) { replaceMatch(editor, m, rep); setIdx(-1); } else flash('No matches found');
  };
  return (
    <div className="glass glass-menu fixed bottom-20 left-1/2 z-[65] w-[min(560px,94vw)] -translate-x-1/2 animate-pop rounded-3xl p-4">
      <div className="mb-2 flex items-center justify-between"><b>Find and Replace</b><button type="button" className="rbtn" onClick={onClose}><X size={18} /></button></div>
      <input className="ginput mb-2" placeholder="Find" value={term} onChange={(e) => { setTerm(e.target.value); setIdx(-1); }} />
      <input className="ginput mb-2" placeholder="Replace with" value={rep} onChange={(e) => setRep(e.target.value)} />
      <label className="mb-2 flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={cs} onChange={(e) => setCs(e.target.checked)} /> Match case</label>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="secondary" onClick={() => go(-1)}>Previous</button>
        <button type="button" className="primary" onClick={() => go(1)}>Find Next</button>
        <button type="button" className="secondary" onClick={replaceOne}>Replace</button>
        <button type="button" className="secondary" onClick={() => flash(`${replaceAll(editor, term, rep, cs)} replaced`)}>Replace All</button>
      </div>
    </div>
  );
}

/* ---------------- Statistics ---------------- */
export function StatsDialog({ editor, onClose, pages }) {
  const text = editor.getText({ blockSeparator: '\n' });
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  let paras = 0;
  editor.state.doc.descendants((n) => { if ((n.type.name === 'paragraph' || n.type.name === 'heading') && n.content.size) paras += 1; });
  const rows = [['Words', words], ['Characters (with spaces)', text.replace(/\n/g, '').length], ['Characters (no spaces)', text.replace(/\s/g, '').length], ['Paragraphs', paras], ['Pages', pages], ['Reading time', `${Math.max(1, Math.ceil(words / 200))} min`]];
  return (
    <Modal title="Document Statistics" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">{rows.map(([k, v]) => <div key={k} className="rounded-2xl bg-black/5 p-4 dark:bg-white/10"><div className="text-2xl font-semibold tabular-nums">{v}</div><div className="text-xs opacity-60">{k}</div></div>)}</div>
    </Modal>
  );
}

/* ---------------- About ---------------- */
export function AboutDialog({ onClose }) {
  return (
    <Modal title="About" onClose={onClose}>
      <div className="flex flex-col items-center gap-3 py-4 text-center">
        <Logo size={96} />
        <div className="text-2xl font-bold tracking-tight">IND<span className="text-blue-500">word</span></div>
        <p className="max-w-xs text-sm opacity-70">A Word-style document app for Android tablets. Your documents stay on this device and work fully offline.</p>
        <span className="rounded-full bg-black/5 px-3 py-1 text-xs dark:bg-white/10">Version 1.0.0</span>
      </div>
    </Modal>
  );
}
