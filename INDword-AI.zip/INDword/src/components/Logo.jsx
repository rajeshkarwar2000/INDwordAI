import { useId } from 'react';

const PAGE = 'M164 96H312L376 160V388Q376 416 348 416H164Q136 416 136 388V124Q136 96 164 96Z';

/** INDword brand mark: a glass tile with a document page, a gradient W and a tricolour wave. */
export default function Logo({ size = 32, tile = true, className = '' }) {
  const id = useId().replace(/:/g, '');
  const u = (n) => `url(#${id}${n})`;
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} className={className} role="img" aria-label="INDword logo">
      <defs>
        <linearGradient id={`${id}bg`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#1D4ED8" /><stop offset="1" stopColor="#9333EA" /></linearGradient>
        <radialGradient id={`${id}gw`} cx=".25" cy=".12" r=".85"><stop offset="0" stopColor="#fff" stopOpacity=".5" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></radialGradient>
        <linearGradient id={`${id}gl`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".3" /><stop offset=".5" stopColor="#fff" stopOpacity="0" /></linearGradient>
        <linearGradient id={`${id}wg`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#2563EB" /><stop offset="1" stopColor="#7C3AED" /></linearGradient>
        <clipPath id={`${id}pg`}><path d={PAGE} /></clipPath>
        <filter id={`${id}sh`} x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="10" stdDeviation="12" floodColor="#1e1b4b" floodOpacity=".4" /></filter>
      </defs>
      {tile && (<>
        <rect width="512" height="512" rx="112" fill={u('bg')} />
        <rect width="512" height="512" rx="112" fill={u('gw')} />
        <rect width="512" height="512" rx="112" fill={u('gl')} />
      </>)}
      <path d={PAGE} fill="#fff" filter={tile ? u('sh') : undefined} stroke={tile ? 'none' : '#CBD5E1'} strokeWidth="6" />
      <g clipPath={u('pg')}>
        <path d="M130 328Q193 316 256 328T382 328L382 356Q319 368 256 356Q193 344 130 356Z" fill="#FF9933" />
        <path d="M130 384Q193 372 256 384T382 384L382 424Q319 436 256 424Q193 412 130 424Z" fill="#138808" />
      </g>
      <g stroke="#000080" strokeWidth="2" fill="none"><circle cx="256" cy="370" r="10" /><path d="M256 360V380M246 370H266M249 363L263 377M263 363L249 377" /></g>
      <path d="M312 96V160H376Z" fill="#DBEAFE" />
      <polyline points="176,190 210,300 256,215 302,300 336,190" fill="none" stroke={u('wg')} strokeWidth="28" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="172,185 206,295 256,210 298,295 332,185" fill="none" stroke="#fff" strokeOpacity=".4" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
