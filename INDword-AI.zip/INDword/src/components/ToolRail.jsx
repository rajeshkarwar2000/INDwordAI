import { PenLine, PanelLeft, Undo2, Redo2, Bold, Italic, Underline, Highlighter, List, Table2, ImagePlus, ZoomIn, ZoomOut, Keyboard, ArrowLeftRight } from 'lucide-react';

/** Vertical glass tool sidebar for the Word editor, like the one in Note mode. Sits on the right or left. */
export default function ToolRail({ editor, c, hl, setHl, zoom, setZoom, pos, onFlip, onNote, kb, toggleKb, outlineOn, toggleOutline }) {
  const run = (fn) => () => { try { fn(editor.chain().focus()).run(); } catch (e) { /* ignore */ } };
  const B = ({ icon: I, label, on, onClick, disabled }) => (
    <button type="button" title={label} aria-label={label} disabled={disabled} onClick={onClick}
      className={`rbtn !min-h-[44px] !min-w-[44px] disabled:opacity-30 ${on ? 'rbtn-on' : ''}`}><I size={20} /></button>
  );
  const Sep = () => <div className="mx-2 my-0.5 h-px bg-black/10 dark:bg-white/15" />;
  const a = (n) => editor.isActive(n);
  return (
    <div className={`glass glass-side no-print fixed z-[45] flex max-h-[calc(100dvh-230px)] flex-col items-center gap-0.5 overflow-y-auto rounded-3xl p-1.5 ${pos === 'left' ? 'left-3' : 'right-9'} top-[190px]`} role="toolbar" aria-label="Tools">
      <B icon={PenLine} label="Switch to Note mode" onClick={onNote} />
      <B icon={PanelLeft} label="Pages, headings and blocks panel" on={outlineOn} onClick={toggleOutline} />
      <Sep />
      <B icon={Undo2} label="Undo" onClick={run((x) => x.undo())} disabled={!editor.can().undo()} />
      <B icon={Redo2} label="Redo" onClick={run((x) => x.redo())} disabled={!editor.can().redo()} />
      <Sep />
      <B icon={Bold} label="Bold" on={a('bold')} onClick={run((x) => x.toggleBold())} />
      <B icon={Italic} label="Italic" on={a('italic')} onClick={run((x) => x.toggleItalic())} />
      <B icon={Underline} label="Underline" on={a('underline')} onClick={run((x) => x.toggleUnderline())} />
      <B icon={Highlighter} label="Highlighter (stays on until you switch it off)" on={hl.on} onClick={() => setHl((h) => ({ ...h, on: !h.on }))} />
      <B icon={List} label="Bullet list" on={a('bulletList')} onClick={run((x) => x.toggleBulletList())} />
      <B icon={Table2} label="Insert table" onClick={run((x) => x.insertTable({ rows: 3, cols: 3, withHeaderRow: true }))} />
      <B icon={ImagePlus} label="Insert image" onClick={() => c.dlg('image')} />
      <Sep />
      <B icon={ZoomIn} label="Zoom in" onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))} />
      <B icon={ZoomOut} label="Zoom out" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} />
      <B icon={Keyboard} label={kb ? 'Keyboard on' : 'Keyboard off'} on={kb} onClick={toggleKb} />
      <Sep />
      <B icon={ArrowLeftRight} label={pos === 'left' ? 'Move sidebar to the right' : 'Move sidebar to the left'} onClick={onFlip} />
    </div>
  );
}
