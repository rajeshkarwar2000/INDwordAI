import { useState, useRef } from 'react';
import { ImagePlus, Sparkles, Copy, ExternalLink, Images } from 'lucide-react';
import { Modal } from './Dialogs.jsx';
import { fileToJpeg, buildPrompt, imagePrompts, parseReply, todayStr, buildNotesHtml, PAGE_BREAK, DEFAULT_OPTS, DEFAULT_COVER, makeCover, coverHtml } from '../services/aiNotes.js';

const OPTS = [['pyqPrelims', 'PYQ Prelims'], ['pyqMains', 'PYQ Mains'], ['mockPrelims', 'Mock Prelims'], ['mockMains', 'Mock Mains'], ['keywords', 'Keywords'], ['related', 'Related facts'], ['images', 'Diagram ideas']];
const today = () => todayStr();

export default function AiNotesDialog({ onClose, onResult, insertMode }) {
  const [items, setItems] = useState([]); // [{ img, reply, extras }]
  const [opts, setOpts] = useState(DEFAULT_OPTS);
  const [part, setPart] = useState('all');
  const [cover, setCover] = useState(false); const [date, setDate] = useState(today());
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const ref = useRef(null); const xref = useRef(null); const target = useRef(0);

  const pick = async (e) => {
    try { const imgs = await Promise.all([...e.target.files].map((f) => fileToJpeg(f))); setItems((o) => [...o, ...imgs.map((img) => ({ img, reply: '', extras: [] }))]); setMsg(''); } catch (err) { setMsg(err.message); }
    e.target.value = '';
  };
  const pickExtra = async (e) => {
    try { const imgs = await Promise.all([...e.target.files].map((f) => fileToJpeg(f))); const i = target.current; setItems((o) => o.map((x, k) => (k === i ? { ...x, extras: [...x.extras, ...imgs.map((m) => ({ url: m.url, caption: '' }))] } : x))); } catch (err) { setMsg(err.message); }
    e.target.value = '';
  };
  const copy = async () => {
    try { await navigator.clipboard.writeText(buildPrompt(opts, part)); setMsg('Prompt copied. Open Gemini, attach the article image, paste and send.'); } catch { setMsg('Could not copy automatically.'); }
  };
  const copyImg = async (i) => {
    try { const t = imagePrompts(parseReply(items[i].reply)); if (!t) return setMsg('No image prompts in this reply.'); await navigator.clipboard.writeText(t); setMsg('Image prompt copied. Open Gemini, paste it and send to generate the image. Then use Add generated images.'); } catch (e) { setMsg(e.message); }
  };
  const set = (i, patch) => setItems((o) => o.map((x, k) => (k === i ? { ...x, ...patch } : x)));
  const build = async () => {
    try {
      setBusy(true);
      if (!items.length) throw new Error('Add at least one article image.');
      const parts = items.map((x, i) => {
        if (!x.reply.trim()) throw new Error(`Paste Gemini’s reply for article ${i + 1}.`);
        const d = parseReply(x.reply); return { d, html: buildNotesHtml(d, x.img, opts, x.extras) };
      });
      let html = parts.map((p) => p.html).join(PAGE_BREAK);
      if (cover) html = coverHtml(await makeCover({ ...DEFAULT_COVER, date: date || today() })) + html;
      onResult(html, (parts[0].d.title || 'AI Notes').slice(0, 60));
    } catch (e) { setMsg(e.message); setBusy(false); }
  };
  return (
    <Modal title="Notes from Article Images" onClose={onClose} wide>
      <ol className="mb-3 list-decimal space-y-1 pl-5 text-sm opacity-80">
        <li>Choose what to include, add the article image(s).</li>
        <li>Copy the prompt, open Gemini, attach the same image, paste and send. For the deepest notes use <b>Part 1</b> then <b>Part 2</b>.</li>
        <li>Paste Gemini’s reply (or both replies) under the image.</li>
        <li>Tap <b>Build notes</b>. Pages, columns, boxes and image are automatic.</li>
      </ol>
      <div className="mb-2 flex flex-wrap gap-1.5">
        {OPTS.map(([k, n]) => <button key={k} type="button" onClick={() => setOpts((o) => ({ ...o, [k]: !o[k] }))} className={`min-h-[36px] rounded-full border px-3 text-sm ${opts[k] ? 'border-blue-500 bg-blue-500/20' : 'border-black/20 opacity-60 dark:border-white/25'}`}>{opts[k] ? '✓ ' : ''}{n}</button>)}
      </div>
      <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
        <span className="opacity-70">Prompt:</span>
        {[['all', 'All in one'], ['1', 'Part 1 · Dynamic'], ['2', 'Part 2 · Static + questions']].map(([k, n]) => <button key={k} type="button" onClick={() => setPart(k)} className={`min-h-[36px] rounded-full border px-3 ${part === k ? 'border-blue-500 bg-blue-500/20' : 'border-black/20 dark:border-white/25'}`}>{n}</button>)}
      </div>
      <input ref={ref} type="file" accept="image/*" multiple hidden onChange={pick} />
      <input ref={xref} type="file" accept="image/*" multiple hidden onChange={pickExtra} />
      <div className="mb-3 flex flex-wrap gap-2">
        <button type="button" className="secondary" onClick={() => ref.current.click()}><ImagePlus size={18} />Add article images</button>
        <button type="button" className="secondary" onClick={copy}><Copy size={18} />Copy prompt</button>
        <a className="secondary inline-flex items-center gap-2" href="https://gemini.google.com/app" target="_blank" rel="noreferrer"><ExternalLink size={18} />Open Gemini</a>
      </div>
      {items.map((x, i) => (
        <div key={i} className="glass glass-card mb-3 flex gap-3 rounded-2xl p-3">
          <img src={x.img.url} alt="" className="h-28 w-20 shrink-0 rounded-lg object-cover" />
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex flex-wrap items-center justify-between gap-2 text-xs opacity-80">
              <span>Article {i + 1}</span>
              <span className="flex gap-3"><button type="button" className="inline-flex items-center gap-1 underline" onClick={() => { target.current = i; xref.current.click(); }}><Images size={13} />Add generated images{x.extras.length ? ` (${x.extras.length})` : ''}</button>
                <button type="button" className="underline" onClick={() => copyImg(i)}>Copy image prompt</button><button type="button" className="underline" onClick={() => setItems((o) => o.filter((_, k) => k !== i))}>Remove</button></span>
            </div>
            <textarea className="ginput h-28 w-full" placeholder="Paste Gemini’s reply here (Part 1 and Part 2 can go together)" value={x.reply} onChange={(e) => set(i, { reply: e.target.value })} />
            {x.extras.map((m, k) => <input key={k} className="ginput mt-1 w-full" placeholder={`Caption for generated image ${k + 1}`} value={m.caption} onChange={(e) => set(i, { extras: x.extras.map((y, j) => (j === k ? { ...y, caption: e.target.value } : y)) })} />)}
          </div>
        </div>
      ))}
      {!insertMode && (
        <label className="mb-3 flex flex-wrap items-center gap-2 text-sm"><input type="checkbox" checked={cover} onChange={(e) => setCover(e.target.checked)} /> Add indIAS cover page, date:
          <input className="ginput w-44" value={date} onChange={(e) => setDate(e.target.value)} /></label>
      )}
      {msg && <p className="mb-3 text-sm">{msg}</p>}
      <button type="button" className="primary w-full" disabled={busy} onClick={build}><Sparkles size={18} />{insertMode ? 'Build and add to this document' : 'Build notes'}</button>
      <p className="mt-2 text-xs opacity-60">No API key needed. PYQ labels come from Gemini: always verify before sharing.</p>
    </Modal>
  );
}

export function CoverDialog({ onClose, onInsert }) {
  const [v, setV] = useState({ ...DEFAULT_COVER, date: today() }); const [busy, setBusy] = useState(false);
  const f = (k, n, area) => (<label className="mb-2 block text-xs opacity-70">{n}{area ? <textarea className="ginput mt-1 h-24 w-full text-base" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} /> : <input className="ginput mt-1 w-full text-base" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} />}</label>);
  return (
    <Modal title="Cover Page" onClose={onClose}>
      {f('date', 'Date')}{f('coverage', 'Coverage')}{f('platform', 'Platform')}{f('vision', 'Our vision')}{f('mission', 'Our mission')}{f('commitments', 'Commitments (one per line, Title: text)', true)}{f('topics', 'Red strip (separate with |)')}{f('footerL', 'Footer left')}{f('footerR', 'Footer right')}
      <button type="button" className="primary w-full" disabled={busy} onClick={async () => { setBusy(true); onInsert(await makeCover(v)); }}>Insert cover at the start</button>
    </Modal>
  );
}
