import { useState, useRef } from 'react';
import { ImagePlus, Sparkles, Copy, ExternalLink } from 'lucide-react';
import { Modal } from './Dialogs.jsx';
import { fileToJpeg, PROMPT, parseReply, buildNotesHtml, PAGE_BREAK } from '../services/aiNotes.js';

export default function AiNotesDialog({ onClose, onResult, insertMode }) {
  const [items, setItems] = useState([]); // [{ img, reply }]
  const [msg, setMsg] = useState('');
  const ref = useRef(null);
  const pick = async (e) => {
    try { const imgs = await Promise.all([...e.target.files].map((f) => fileToJpeg(f))); setItems((o) => [...o, ...imgs.map((img) => ({ img, reply: '' }))]); setMsg(''); }
    catch (err) { setMsg(err.message); }
  };
  const copy = async () => {
    try { await navigator.clipboard.writeText(PROMPT); setMsg('Prompt copied. Open Gemini, attach the article image, paste, send.'); }
    catch { setMsg('Could not copy automatically. Select the prompt text below and copy it.'); }
  };
  const setReply = (i, v) => setItems((o) => o.map((x, k) => (k === i ? { ...x, reply: v } : x)));
  const build = () => {
    try {
      if (!items.length) throw new Error('Add at least one article image.');
      const parts = items.map((x, i) => {
        if (!x.reply.trim()) throw new Error(`Paste Gemini’s reply for article ${i + 1}.`);
        const d = parseReply(x.reply); return { d, html: buildNotesHtml(d, x.img) };
      });
      onResult(parts.map((p) => p.html).join(PAGE_BREAK), (parts[0].d.title || 'AI Notes').slice(0, 60));
    } catch (e) { setMsg(e.message); }
  };
  return (
    <Modal title="Notes from Article Images" onClose={onClose} wide>
      <ol className="mb-3 list-decimal space-y-1 pl-5 text-sm opacity-80">
        <li>Add your article image(s) here.</li>
        <li>Tap <b>Copy prompt</b>, open Gemini, attach the same image, paste the prompt and send.</li>
        <li>Copy Gemini’s whole reply and paste it under the image below.</li>
        <li>Tap <b>Build notes</b>. Layout, boxes, image and columns are automatic.</li>
      </ol>
      <input ref={ref} type="file" accept="image/*" multiple hidden onChange={pick} />
      <div className="mb-3 flex flex-wrap gap-2">
        <button type="button" className="secondary" onClick={() => ref.current.click()}><ImagePlus size={18} />Add article images</button>
        <button type="button" className="secondary" onClick={copy}><Copy size={18} />Copy prompt</button>
        <a className="secondary inline-flex items-center gap-2" href="https://gemini.google.com/app" target="_blank" rel="noreferrer"><ExternalLink size={18} />Open Gemini</a>
      </div>
      {items.map((x, i) => (
        <div key={i} className="glass glass-card mb-3 flex gap-3 rounded-2xl p-3">
          <img src={x.img.url} alt="" className="h-28 w-20 shrink-0 rounded-lg object-cover" />
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex items-center justify-between text-xs opacity-70"><span>Article {i + 1}</span><button type="button" className="underline" onClick={() => setItems((o) => o.filter((_, k) => k !== i))}>Remove</button></div>
            <textarea className="ginput h-28 w-full" placeholder="Paste Gemini’s reply here" value={x.reply} onChange={(e) => setReply(i, e.target.value)} />
          </div>
        </div>
      ))}
      {msg && <p className="mb-3 text-sm">{msg}</p>}
      <button type="button" className="primary w-full" onClick={build}><Sparkles size={18} />{insertMode ? 'Build and add to this document' : 'Build notes'}</button>
      <p className="mt-2 text-xs opacity-60">No API key needed. Always check PYQ labels against a trusted source.</p>
    </Modal>
  );
}
