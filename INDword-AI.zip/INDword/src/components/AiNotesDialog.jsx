import { useState, useEffect, useRef } from 'react';
import { ImagePlus, Sparkles, Loader2 } from 'lucide-react';
import { Modal } from './Dialogs.jsx';
import { getAiSettings, saveAiSettings, fileToJpeg, generateNotes, buildNotesHtml, PAGE_BREAK } from '../services/aiNotes.js';

export default function AiNotesDialog({ onClose, onResult, insertMode }) {
  const [key, setKey] = useState(''); const [model, setModel] = useState('gemini-flash-latest');
  const [files, setFiles] = useState([]); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const ref = useRef(null);
  useEffect(() => { getAiSettings().then((s) => { setKey(s.key); setModel(s.model); }); }, []);
  const run = async () => {
    if (!files.length) return setMsg('Add at least one article image.');
    if (!key.trim()) return setMsg('Paste your Gemini API key first (free from aistudio.google.com).');
    setBusy(true);
    try {
      await saveAiSettings(key.trim(), model.trim());
      const parts = []; let name = 'AI Notes';
      for (let n = 0; n < files.length; n += 1) {
        setMsg(`Reading and writing article ${n + 1} of ${files.length}…`);
        const img = await fileToJpeg(files[n]);
        const d = await generateNotes(img.url, key.trim(), model.trim());
        if (n === 0 && d.title) name = d.title.slice(0, 60);
        parts.push(buildNotesHtml(d, img));
      }
      onResult(parts.join(PAGE_BREAK), name);
    } catch (e) { setMsg(`Error: ${e.message}`); setBusy(false); }
  };
  return (
    <Modal title="AI Notes from Article Images" onClose={busy ? () => {} : onClose}>
      <p className="mb-3 text-sm opacity-70">Add newspaper article images. Gemini reads them and writes dynamic notes first, then static background, revision pointers, PYQs (labelled, please verify) and mock questions. The image is placed on the page automatically.</p>
      <input ref={ref} type="file" accept="image/*" multiple hidden onChange={(e) => setFiles([...e.target.files])} />
      <button type="button" className="secondary mb-3 w-full" onClick={() => ref.current.click()}><ImagePlus size={18} />{files.length ? `${files.length} image(s) selected` : 'Choose article images'}</button>
      <label className="mb-1 block text-xs opacity-60">Gemini API key (saved on this tablet)</label>
      <input className="ginput mb-2" type="password" value={key} onChange={(e) => setKey(e.target.value)} placeholder="Paste once" />
      <label className="mb-1 block text-xs opacity-60">Model</label>
      <input className="ginput mb-3" value={model} onChange={(e) => setModel(e.target.value)} />
      {msg && <p className="mb-3 text-sm">{msg}</p>}
      <button type="button" className="primary w-full" disabled={busy} onClick={run}>{busy ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}{insertMode ? 'Generate and add to this document' : 'Generate notes'}</button>
      <p className="mt-2 text-xs opacity-60">Needs internet. Always check PYQ labels against a trusted source.</p>
    </Modal>
  );
}
