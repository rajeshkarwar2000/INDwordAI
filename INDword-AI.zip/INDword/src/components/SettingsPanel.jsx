import { WALLPAPERS, ACCENT_CHOICES, GLASS_PRESETS } from '../services/appearance.js';
import { DEFAULT_SETTINGS } from '../services/store.js';
import { PAGE_SIZES, MARGIN_PRESETS, FONT_SET_LABELS } from '../constants.js';

const Section = ({ title, children }) => (
  <section className="glass glass-card mb-4 rounded-3xl p-4">
    <h3 className="mb-3 text-base font-semibold tracking-tight">{title}</h3>
    <div className="grid gap-1">{children}</div>
  </section>
);
const Sub = ({ children }) => <div className="mb-1 mt-3 text-xs font-semibold uppercase tracking-wide opacity-50">{children}</div>;
const Row = ({ label, hint, children }) => (
  <div className="flex min-h-[52px] flex-wrap items-center justify-between gap-3 px-1 py-1">
    <div className="min-w-[160px] flex-1"><div className="text-sm font-medium">{label}</div>{hint && <div className="text-xs opacity-60">{hint}</div>}</div>
    <div className="flex items-center gap-2">{children}</div>
  </div>
);
/** Full-width slider row with the value on the right, like the reference design. */
const Slide = ({ label, value, min, max, step, onChange, fmt = (v) => v }) => (
  <div className="px-1 py-1">
    <div className="flex items-baseline justify-between"><span className="text-sm font-semibold">{label}</span><span className="text-sm font-semibold opacity-60 tabular-nums">{fmt(value)}</span></div>
    <input type="range" className="grange w-full" min={min} max={max} step={step} value={value} style={{ '--p': `${((value - min) / (max - min)) * 100}%` }} onChange={(e) => onChange(Number(e.target.value))} />
  </div>
);
const Toggle = ({ value, onChange }) => <button type="button" role="switch" aria-checked={value} onClick={() => onChange(!value)} className="gswitch" />;
const Seg = ({ value, options, onChange }) => (
  <div className="flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
    {options.map(([v, l]) => <button key={String(v)} type="button" onClick={() => onChange(v)} className={`min-h-[40px] rounded-xl px-3 text-sm font-medium ${value === v ? 'rbtn-on bg-white shadow dark:bg-zinc-700' : ''}`}>{l}</button>)}
  </div>
);

const TILE_BG = 'linear-gradient(135deg,#f9a8d4,#a5b4fc 50%,#67e8f9)';
function GlassTile({ id, p, active, onPick }) {
  return (
    <button type="button" onClick={() => onPick(id)} className={`flex flex-col items-center gap-1.5 rounded-2xl bg-black/5 p-2 dark:bg-white/10 ${active ? 'ring-2 ring-blue-500' : ''}`}>
      <span className="grid h-16 w-full place-items-center overflow-hidden rounded-xl p-2" style={{ background: TILE_BG }}>
        <span className="h-full w-full rounded-lg" style={{
          background: `linear-gradient(135deg, rgba(255,255,255,${0.55 * p.glassSheen}), rgba(255,255,255,0) 45%), rgba(255,255,255,${p.glassOpacity})`,
          backdropFilter: `blur(${Math.min(p.glassBlur, 12)}px) saturate(${p.glassSat})`, WebkitBackdropFilter: `blur(${Math.min(p.glassBlur, 12)}px) saturate(${p.glassSat})`,
          border: `1px solid rgba(255,255,255,${Math.min(1, p.glassBorder + 0.25)})`,
          boxShadow: `inset 2px 2px 4px -2px rgba(255,255,255,${0.95 * p.glassRim}), inset -1px -2px 4px -2px rgba(255,255,255,${0.7 * p.glassRim}), 0 4px 10px rgba(0,0,0,.12)`,
        }} />
      </span>
      <span className="text-sm font-semibold">{p.label}</span>
    </button>
  );
}

export default function SettingsPanel({ settings: s, setSettings }) {
  const set = (patch) => setSettings({ ...s, ...patch });
  const custom = (patch) => set({ ...patch, glassStyle: 'custom' });
  const pick = (id) => { const { label, ...vals } = GLASS_PRESETS[id]; set({ ...vals, glassStyle: id }); };
  const base = GLASS_PRESETS[s.glassStyle] || GLASS_PRESETS.frosted;
  const pct = (v) => `${Math.round(v * 100)}%`;
  return (
    <div className="max-w-3xl">
      <Section title="Appearance">
        <div className="mb-1"><Seg value={s.theme} onChange={(v) => set({ theme: v })} options={[['system', 'Auto'], ['light', 'Light'], ['dark', 'Dark']]} /></div>
      </Section>

      <Section title="Glass style">
        <div className="glass glass-card mb-2 rounded-2xl p-3 text-center text-sm">Live preview: this card uses your glass settings</div>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {Object.entries(GLASS_PRESETS).map(([id, p]) => <GlassTile key={id} id={id} p={p} active={s.glassStyle === id} onPick={pick} />)}
        </div>
        <Slide label="Blur" min={0} max={60} step={1} value={s.glassBlur} onChange={(v) => custom({ glassBlur: v })} fmt={(v) => `${v} px`} />
        <Slide label="Transparency" min={0.2} max={1} step={0.01} value={s.glassOpacity} onChange={(v) => custom({ glassOpacity: v })} fmt={(v) => `${Math.round(v * 100)}% opaque`} />
        <button type="button" className="secondary mt-1 w-full" onClick={() => set({ glassBlur: base.glassBlur, glassOpacity: base.glassOpacity })}>Reset blur and transparency</button>

        <Sub>Light and reflections</Sub>
        <Slide label="Edge light" min={0} max={1} step={0.05} value={s.glassRim} onChange={(v) => custom({ glassRim: v })} fmt={pct} />
        <Row label="Edge light colour"><Seg value={s.glassRimColor} onChange={(v) => custom({ glassRimColor: v })} options={[['white', 'White'], ['accent', 'Accent']]} /></Row>
        <Slide label="Liquid shine" min={0} max={1} step={0.05} value={s.glassSheen} onChange={(v) => custom({ glassSheen: v })} fmt={pct} />
        <Slide label="Border brightness" min={0} max={0.8} step={0.05} value={s.glassBorder} onChange={(v) => custom({ glassBorder: v })} fmt={pct} />

        <Sub>Colour and depth</Sub>
        <Slide label="Colour boost" min={1} max={2.5} step={0.1} value={s.glassSat} onChange={(v) => custom({ glassSat: v })} fmt={(v) => `${v.toFixed(1)}×`} />
        <Slide label="Brightness" min={0.8} max={1.3} step={0.01} value={s.glassBright} onChange={(v) => custom({ glassBright: v })} fmt={pct} />
        <Slide label="Accent tint" min={0} max={0.35} step={0.01} value={s.glassTint} onChange={(v) => custom({ glassTint: v })} fmt={pct} />
        <Slide label="Shadow depth" min={0} max={2} step={0.1} value={s.glassShadow} onChange={(v) => custom({ glassShadow: v })} fmt={(v) => v.toFixed(1)} />
        <Row label="Frosted texture" hint="Fine grain like sandblasted glass"><Seg value={s.glassGrain} onChange={(v) => custom({ glassGrain: v })} options={[[0, 'Off'], [1, 'Low'], [2, 'High']]} /></Row>

        <Sub>Where glass is used</Sub>
        <Row label="Ribbon and headers"><Toggle value={s.glassRibbon} onChange={(v) => set({ glassRibbon: v })} /></Row>
        <Row label="Side panels"><Toggle value={s.glassSide} onChange={(v) => set({ glassSide: v })} /></Row>
        <Row label="Menus and dialogs"><Toggle value={s.glassMenu} onChange={(v) => set({ glassMenu: v })} /></Row>
        <Row label="Status bar"><Toggle value={s.glassStatus} onChange={(v) => set({ glassStatus: v })} /></Row>
        <Row label="Cards and lists"><Toggle value={s.glassCard} onChange={(v) => set({ glassCard: v })} /></Row>
        <Row label="Glass switches and slider knobs" hint="The glass controls you see on this screen"><Toggle value={s.glassControls} onChange={(v) => set({ glassControls: v })} /></Row>
        <Slide label="Glass paper" min={0.6} max={1} step={0.02} value={s.pageOpacity} onChange={(v) => set({ pageOpacity: v })} fmt={pct} />
        <p className="px-1 text-xs opacity-60">Glass paper lets the wallpaper show faintly through the page. Exports stay solid.</p>
        <Row label="Performance mode" hint="Turns blur off for smoother scrolling on slow devices"><Toggle value={s.reduceEffects} onChange={(v) => set({ reduceEffects: v })} /></Row>
      </Section>

      <Section title="Look and feel">
        <Row label="Accent colour">
          <div className="flex flex-wrap justify-end gap-2">
            {ACCENT_CHOICES.map((c) => <button key={c} type="button" aria-label={c} onClick={() => set({ accent: c })} className={`h-9 w-9 rounded-full border-2 ${s.accent === c ? 'border-black dark:border-white' : 'border-transparent'}`} style={{ background: c }} />)}
            <input type="color" aria-label="Custom accent" value={s.accent} onChange={(e) => set({ accent: e.target.value })} className="h-9 w-12 rounded-lg border-0 bg-transparent" />
          </div>
        </Row>
        <Row label="Wallpaper">
          <div className="flex flex-wrap justify-end gap-2">
            {Object.entries(WALLPAPERS).map(([k, w]) => (
              <button key={k} type="button" onClick={() => set({ wallpaper: k })} className={`flex h-12 w-20 items-end rounded-xl border-2 p-1 text-[10px] font-medium text-black/70 ${s.wallpaper === k ? 'border-blue-500' : 'border-transparent'}`} style={{ background: w.light }}>{w.label}</button>
            ))}
          </div>
        </Row>
        <Row label="Shape" hint="Corner style of buttons, cards and panels"><Seg value={s.radius} onChange={(v) => set({ radius: v })} options={[[0.25, 'Square'], [1, 'Rounded'], [1.5, 'Soft'], [2.4, 'Capsule']]} /></Row>
        <Slide label="Interface size" min={0.9} max={1.3} step={0.05} value={s.uiScale} onChange={(v) => set({ uiScale: v })} fmt={pct} />
        <Slide label="Scrollbar thickness" min={8} max={28} step={2} value={s.scrollSize} onChange={(v) => set({ scrollSize: v })} fmt={(v) => `${v} px`} />
        <Row label="Reduce motion" hint="Disables animations"><Toggle value={s.reduceMotion} onChange={(v) => set({ reduceMotion: v })} /></Row>
      </Section>

      <Section title="New documents and editor">
        <Row label="Page size"><select className="ginput !w-40" value={s.pageSize} onChange={(e) => set({ pageSize: e.target.value })}>{Object.keys(PAGE_SIZES).map((p) => <option key={p}>{p}</option>)}</select></Row>
        <Row label="Margins"><select className="ginput !w-56" value={s.marginPreset} onChange={(e) => set({ marginPreset: e.target.value })}>{Object.entries(MARGIN_PRESETS).map(([k, p]) => <option key={k} value={k}>{p.label}</option>)}</select></Row>
        <Row label="Font style"><select className="ginput !w-40" value={s.fontSet} onChange={(e) => set({ fontSet: e.target.value })}>{Object.entries(FONT_SET_LABELS).map(([k, n]) => <option key={k} value={k}>{n}</option>)}</select></Row>
        <Slide label="Default zoom" min={0.5} max={2} step={0.05} value={s.defaultZoom} onChange={(v) => set({ defaultZoom: v })} fmt={pct} />
        <Row label="Show ruler when editing"><Toggle value={s.showRuler} onChange={(v) => set({ showRuler: v })} /></Row>
        <Row label="Show text boundaries"><Toggle value={s.showBoundaries} onChange={(v) => set({ showBoundaries: v })} /></Row>
        <Row label="Auto-save"><Toggle value={s.autosave} onChange={(v) => set({ autosave: v })} /></Row>
        <Row label="Auto-save delay"><Seg value={s.autosaveMs} onChange={(v) => set({ autosaveMs: v })} options={[[1000, '1 s'], [3000, '3 s'], [8000, '8 s']]} /></Row>
      </Section>

      <button type="button" className="secondary" onClick={() => setSettings({ ...DEFAULT_SETTINGS, sidebarOpen: s.sidebarOpen })}>Reset everything to defaults</button>
    </div>
  );
}
