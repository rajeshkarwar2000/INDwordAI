import { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { NodeViewWrapper } from '@tiptap/react';
import { PanelLeft, PanelRight, AlignCenter, Type, Crop, RotateCcw, RotateCw, RefreshCw, Download, Trash2, SlidersHorizontal, Lock, Unlock, Undo2, Move } from 'lucide-react';
import { Modal, Field } from './Dialogs.jsx';
import { saveBlob } from '../services/exporters.js';
import { readAsDataUrl } from '../services/importers.js';

const loadImg = (src) => new Promise((res, rej) => {
  const i = new window.Image(); i.crossOrigin = 'anonymous';
  i.onload = () => res(i); i.onerror = () => rej(new Error('Image could not be loaded')); i.src = src;
});
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export async function cropDataUrl(src, { t, r, b, l }) {
  const i = await loadImg(src);
  const sx = Math.round((i.naturalWidth * l) / 100); const sy = Math.round((i.naturalHeight * t) / 100);
  const sw = Math.max(1, Math.round((i.naturalWidth * (100 - l - r)) / 100)); const sh = Math.max(1, Math.round((i.naturalHeight * (100 - t - b)) / 100));
  const c = document.createElement('canvas'); c.width = sw; c.height = sh;
  c.getContext('2d').drawImage(i, sx, sy, sw, sh, 0, 0, sw, sh);
  return c.toDataURL('image/png');
}
export async function rotateDataUrl(src, deg) {
  const i = await loadImg(src);
  const c = document.createElement('canvas'); c.width = i.naturalHeight; c.height = i.naturalWidth;
  const x = c.getContext('2d'); x.translate(c.width / 2, c.height / 2); x.rotate((deg * Math.PI) / 180);
  x.drawImage(i, -i.naturalWidth / 2, -i.naturalHeight / 2);
  return c.toDataURL('image/png');
}

/* ---------- free-form crop: drag any edge or corner, or move the whole frame ---------- */
const MIN = 6;
const HANDLES = [['nw', 0, 0], ['n', 50, 0], ['ne', 100, 0], ['e', 100, 50], ['se', 100, 100], ['s', 50, 100], ['sw', 0, 100], ['w', 0, 50]];
const RATIOS = [['Free', null], ['1:1', 1], ['4:3', 4 / 3], ['3:4', 3 / 4], ['16:9', 16 / 9]];

function CropDialog({ src, onApply, onClose }) {
  const [r, setR] = useState({ x: 0, y: 0, w: 100, h: 100 });
  const [ratio, setRatio] = useState(null);
  const [nat, setNat] = useState({ w: 1, h: 1 });
  const [busy, setBusy] = useState(false);
  const box = useRef(null);

  const pickRatio = (val) => {
    setRatio(val);
    if (!val) return;
    const ir = nat.w / nat.h;
    const w = val >= ir ? 100 : (100 * val) / ir; const h = val >= ir ? (100 * ir) / val : 100;
    setR({ x: (100 - w) / 2, y: (100 - h) / 2, w, h });
  };
  const begin = (mode) => (e) => {
    e.preventDefault(); e.stopPropagation();
    const b = box.current.getBoundingClientRect(); const s = { ...r };
    const x0 = e.clientX; const y0 = e.clientY; const t = e.currentTarget;
    t.setPointerCapture(e.pointerId);
    const move = (ev) => {
      const dx = ((ev.clientX - x0) / b.width) * 100; const dy = ((ev.clientY - y0) / b.height) * 100;
      let { x, y, w, h } = s;
      if (mode === 'move') { x = clamp(s.x + dx, 0, 100 - s.w); y = clamp(s.y + dy, 0, 100 - s.h); }
      else {
        if (mode.includes('w')) { const nx = clamp(s.x + dx, 0, s.x + s.w - MIN); w = s.w + (s.x - nx); x = nx; }
        if (mode.includes('e')) w = clamp(s.w + dx, MIN, 100 - s.x);
        if (mode.includes('n')) { const ny = clamp(s.y + dy, 0, s.y + s.h - MIN); h = s.h + (s.y - ny); y = ny; }
        if (mode.includes('s')) h = clamp(s.h + dy, MIN, 100 - s.y);
        if (ratio && mode.length === 2) {
          h = (w * nat.w) / (ratio * nat.h);
          if (mode.includes('n')) y = s.y + s.h - h;
          if (y < 0 || y + h > 100) return;
        }
      }
      setR({ x, y, w, h });
    };
    const up = () => { t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); };
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up);
  };
  const apply = async () => {
    setBusy(true);
    try { onApply(await cropDataUrl(src, { t: r.y, l: r.x, r: 100 - r.x - r.w, b: 100 - r.y - r.h })); } finally { setBusy(false); }
  };

  return (
    <Modal title="Crop Picture" onClose={onClose} wide>
      <p className="mb-2 text-sm opacity-70">Drag the edges or corners freely, or drag inside the frame to move it.</p>
      <div className="mb-3 flex justify-center rounded-2xl bg-black/10 p-4 dark:bg-white/10">
        <div ref={box} className="relative inline-block max-w-full select-none overflow-hidden" style={{ touchAction: 'none' }}>
          <img src={src} alt="" draggable={false} className="block max-h-[48vh] max-w-full" onLoad={(e) => setNat({ w: e.target.naturalWidth, h: e.target.naturalHeight })} />
          <div onPointerDown={begin('move')} className="absolute cursor-move" style={{ left: `${r.x}%`, top: `${r.y}%`, width: `${r.w}%`, height: `${r.h}%`, boxShadow: '0 0 0 9999px rgba(0,0,0,.55)', border: '2px solid #fff', touchAction: 'none' }}>
            {[33.3, 66.6].map((p) => <span key={`v${p}`} className="pointer-events-none absolute top-0 bottom-0 border-l border-white/50" style={{ left: `${p}%` }} />)}
            {[33.3, 66.6].map((p) => <span key={`h${p}`} className="pointer-events-none absolute left-0 right-0 border-t border-white/50" style={{ top: `${p}%` }} />)}
            {HANDLES.map(([k, x, y]) => (
              <span key={k} onPointerDown={begin(k)} aria-label={`Crop ${k}`}
                style={{ position: 'absolute', left: `${x}%`, top: `${y}%`, width: 30, height: 30, marginLeft: -15, marginTop: -15, display: 'grid', placeItems: 'center', touchAction: 'none' }}>
                <span style={{ width: k.length === 2 ? 16 : 12, height: k.length === 2 ? 16 : 12, borderRadius: k.length === 2 ? 3 : 6, background: '#fff', border: '2px solid #3b82f6', boxShadow: '0 1px 3px rgba(0,0,0,.5)' }} />
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="mb-3 flex flex-wrap gap-1">
        {RATIOS.map(([n, v]) => <button key={n} type="button" onClick={() => pickRatio(v)} className={`rbtn ${ratio === v ? 'rbtn-on' : ''}`}>{n}</button>)}
      </div>
      <div className="flex gap-2">
        <button type="button" className="secondary" onClick={() => { setRatio(null); setR({ x: 0, y: 0, w: 100, h: 100 }); }}>Reset</button>
        <button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button>
        <button type="button" className="primary flex-1" disabled={busy} onClick={apply}>Apply Crop</button>
      </div>
    </Modal>
  );
}

function PropsDialog({ attrs, onApply, onClose }) {
  const [alt, setAlt] = useState(attrs.alt || '');
  const [w, setW] = useState(attrs.width || '');
  const [h, setH] = useState(attrs.height || '');
  const [lock, setLock] = useState(attrs.lock !== false);
  const [align, setAlign] = useState(attrs.align || 'inline');
  return (
    <Modal title="Picture Properties" onClose={onClose}>
      <Field label="Alternative text"><input className="ginput" value={alt} onChange={(e) => setAlt(e.target.value)} /></Field>
      <Field label="Width (e.g. 320px or 50%)"><input className="ginput" value={w} onChange={(e) => setW(e.target.value)} placeholder="auto" /></Field>
      <Field label="Height (e.g. 200px, leave empty for automatic)"><input className="ginput" value={h} onChange={(e) => setH(e.target.value)} placeholder="auto" /></Field>
      <label className="mb-3 flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={lock} onChange={(e) => setLock(e.target.checked)} /> Lock aspect ratio</label>
      <Field label="Layout">
        <select className="ginput" value={align} onChange={(e) => setAlign(e.target.value)}>
          <option value="inline">Inline with text</option><option value="left">Float left</option>
          <option value="center">Centre</option><option value="right">Float right</option>
        </select>
      </Field>
      <button type="button" className="primary w-full" onClick={() => onApply({ alt, align, lock, width: /^\d+(\.\d+)?(px|%)$/.test(w.trim()) ? w.trim() : null, height: !lock && /^\d+(\.\d+)?px$/.test(h.trim()) ? h.trim() : null })}>Apply</button>
    </Modal>
  );
}

const TB = ({ icon: I, label, on, onClick, children }) => (
  <button type="button" title={label} aria-label={label} onMouseDown={(e) => e.preventDefault()} onClick={onClick}
    className={`rbtn !min-h-[44px] !min-w-[44px] ${on ? 'rbtn-on' : ''}`}>{I ? <I size={18} /> : children}</button>
);

export default function ImageView({ node, updateAttributes, deleteNode, selected, editor, getPos }) {
  const a = node.attrs;
  const img = useRef(null);
  const file = useRef(null);
  const [dlg, setDlg] = useState(null);
  const show = selected && editor.isEditable;

  const select = () => { const p = getPos(); if (typeof p === 'number') { editor.commands.setNodeSelection(p); editor.view.dom.blur(); } };
  const wrap = a.align === 'left' ? { float: 'left', margin: '4px 16px 8px 0' }
    : a.align === 'right' ? { float: 'right', margin: '4px 0 8px 16px' }
      : a.align === 'center' ? { display: 'block', margin: '8px auto', width: 'fit-content' }
        : { display: 'inline-block', verticalAlign: 'bottom' };

  /* Drag the picture itself to move it in any direction: no extra steps. */
  const startMove = (e) => {
    if (!editor.isEditable || (e.button !== undefined && e.button > 0)) return;
    if (e.pointerType === 'touch' && !show) return;           // first tap selects, then a drag moves
    const el = img.current.parentElement; const rect = el.getBoundingClientRect();
    const scale = rect.width / el.offsetWidth || 1;
    const x0 = e.clientX; const y0 = e.clientY; const ox = a.dx || 0; const oy = a.dy || 0; let moved = false;
    const t = e.currentTarget; t.setPointerCapture(e.pointerId);
    const pos = (ev) => [Math.round(ox + (ev.clientX - x0) / scale), Math.round(oy + (ev.clientY - y0) / scale)];
    const move = (ev) => {
      if (!moved && Math.hypot(ev.clientX - x0, ev.clientY - y0) < 5) return;
      if (!moved) { moved = true; select(); }
      const [x, y] = pos(ev); el.style.left = `${x}px`; el.style.top = `${y}px`;
    };
    const up = (ev) => {
      t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up);
      if (moved) { const [x, y] = pos(ev); updateAttributes({ dx: x, dy: y }); }
    };
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up);
  };

  /* dx/dy are -1, 0 or 1: which edges this handle moves. Corners keep the ratio while "lock" is on. */
  const startResize = (dx, dy) => (e) => {
    e.preventDefault(); e.stopPropagation();
    const el = img.current; const rect = el.getBoundingClientRect();
    const scale = rect.width / el.offsetWidth || 1;
    const x0 = e.clientX; const y0 = e.clientY; const w0 = el.offsetWidth; const h0 = el.offsetHeight; const target = e.currentTarget;
    const locked = a.lock !== false; const corner = dx !== 0 && dy !== 0;
    target.setPointerCapture(e.pointerId);
    const calc = (ev) => {
      let w = w0 + (dx * (ev.clientX - x0)) / scale; let h = h0 + (dy * (ev.clientY - y0)) / scale;
      if (locked) { if (dx !== 0) { h = (w * h0) / w0; } else { w = (h * w0) / h0; } }
      return [Math.max(30, Math.round(w)), Math.max(30, Math.round(h))];
    };
    const move = (ev) => {
      const [w, h] = calc(ev);
      if (dx !== 0 || locked) el.style.width = `${w}px`;
      if (dy !== 0 || locked) el.style.height = locked ? 'auto' : `${h}px`;
      if (!locked && dy !== 0) el.style.objectFit = 'fill';
    };
    const up = (ev) => {
      target.removeEventListener('pointermove', move); target.removeEventListener('pointerup', up);
      const [w, h] = calc(ev);
      if (locked) updateAttributes({ width: `${w}px`, height: null });
      else updateAttributes({ width: dx !== 0 || corner ? `${w}px` : (a.width || `${w0}px`), height: dy !== 0 || corner ? `${h}px` : (a.height || `${h0}px`) });
    };
    target.addEventListener('pointermove', move); target.addEventListener('pointerup', up);
  };

  const download = async () => {
    const blob = await (await fetch(a.src)).blob();
    const ext = (blob.type.split('/')[1] || 'png').replace('svg+xml', 'svg');
    saveBlob(`${(a.alt || 'image').replace(/[^\w-]+/g, '_')}.${ext}`, blob);
  };
  const replace = async (e) => { const f = e.target.files?.[0]; if (f) updateAttributes({ src: await readAsDataUrl(f), width: null, height: null }); e.target.value = ''; };
  const rotate = async (deg) => updateAttributes({ src: await rotateDataUrl(a.src, deg), width: null, height: null });
  const sizePct = (p) => updateAttributes({ width: `${p}%`, height: null });
  const freeH = a.height && a.lock === false;

  return (
    <NodeViewWrapper as="span" contentEditable={false} style={{ position: 'relative', left: a.dx || 0, top: a.dy || 0, ...wrap }} onClick={select}>
      <img ref={img} src={a.src} alt={a.alt || ''} draggable={false} onPointerDown={startMove}
        style={{ width: a.width || undefined, maxWidth: '100%', height: freeH ? a.height : 'auto', objectFit: freeH ? 'fill' : undefined, display: 'block', outline: show ? '2px solid #3b82f6' : 'none', outlineOffset: 1, touchAction: show ? 'none' : 'auto', cursor: editor.isEditable ? 'move' : 'default' }} />
      {show && (
        <>
          {[
            ['nw', -1, -1, { left: -12, top: -12 }, 'nwse-resize'], ['ne', 1, -1, { right: -12, top: -12 }, 'nesw-resize'],
            ['sw', -1, 1, { left: -12, bottom: -12 }, 'nesw-resize'], ['se', 1, 1, { right: -12, bottom: -12 }, 'nwse-resize'],
            ['n', 0, -1, { left: '50%', top: -12, marginLeft: -12 }, 'ns-resize'], ['s', 0, 1, { left: '50%', bottom: -12, marginLeft: -12 }, 'ns-resize'],
            ['w', -1, 0, { top: '50%', left: -12, marginTop: -12 }, 'ew-resize'], ['e', 1, 0, { top: '50%', right: -12, marginTop: -12 }, 'ew-resize'],
          ].map(([k, dx, dy, pos, cur]) => (
            <span key={k} onPointerDown={startResize(dx, dy)} aria-label={`Resize ${k}`}
              style={{ position: 'absolute', width: 24, height: 24, borderRadius: dx && dy ? 12 : 6, background: dx && dy ? '#3b82f6' : '#fff', border: '3px solid #3b82f6', boxShadow: '0 1px 4px rgba(0,0,0,.4)', touchAction: 'none', cursor: cur, zIndex: 5, ...pos }} />
          ))}
          <span className="glass glass-menu no-print" onMouseDown={(e) => e.preventDefault()} onPointerDown={(e) => e.stopPropagation()} style={{ position: 'absolute', left: 0, top: '100%', marginTop: 14, zIndex: 40, display: 'flex', flexWrap: 'wrap', gap: 2, padding: 6, borderRadius: 18, width: 'max-content', maxWidth: 460, fontSize: 13 }}>
            <TB icon={PanelLeft} label="Float left" on={a.align === 'left'} onClick={() => updateAttributes({ align: 'left' })} />
            <TB icon={AlignCenter} label="Centre" on={a.align === 'center'} onClick={() => updateAttributes({ align: 'center' })} />
            <TB icon={PanelRight} label="Float right" on={a.align === 'right'} onClick={() => updateAttributes({ align: 'right' })} />
            <TB icon={Type} label="Inline with text" on={a.align === 'inline'} onClick={() => updateAttributes({ align: 'inline' })} />
            {[25, 50, 75, 100].map((p) => <TB key={p} label={`${p}%`} on={a.width === `${p}%`} onClick={() => sizePct(p)}>{p}%</TB>)}
            <TB icon={a.lock === false ? Unlock : Lock} label={a.lock === false ? 'Free resize (ratio unlocked)' : 'Lock aspect ratio'} on={a.lock === false} onClick={() => updateAttributes({ lock: a.lock === false, height: null })} />
            <TB icon={Undo2} label="Reset size" onClick={() => updateAttributes({ width: null, height: null })} />
            <TB icon={Move} label="Reset position" onClick={() => updateAttributes({ dx: 0, dy: 0 })} />
            <TB icon={Crop} label="Crop" onClick={() => setDlg('crop')} />
            <TB icon={RotateCcw} label="Rotate left" onClick={() => rotate(-90)} />
            <TB icon={RotateCw} label="Rotate right" onClick={() => rotate(90)} />
            <TB icon={RefreshCw} label="Replace image" onClick={() => file.current?.click()} />
            <TB icon={Download} label="Download image" onClick={download} />
            <TB icon={SlidersHorizontal} label="Image properties" onClick={() => setDlg('props')} />
            <TB icon={Trash2} label="Delete image" onClick={() => deleteNode()} />
            <input ref={file} type="file" accept="image/*" hidden onChange={replace} />
          </span>
        </>
      )}
      {dlg === 'crop' && createPortal(<CropDialog src={a.src} onClose={() => setDlg(null)} onApply={(src) => { updateAttributes({ src, width: null, height: null }); setDlg(null); }} />, document.body)}
      {dlg === 'props' && createPortal(<PropsDialog attrs={a} onClose={() => setDlg(null)} onApply={(v) => { updateAttributes(v); setDlg(null); }} />, document.body)}
    </NodeViewWrapper>
  );
}
