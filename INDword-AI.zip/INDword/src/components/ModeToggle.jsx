import { Type, PenLine } from 'lucide-react';

/** Edit (typing) | Note (pen) switch */
export default function ModeToggle({ mode, onChange, compact }) {
  const item = (k, I, n) => (
    <button type="button" aria-label={`${n} mode`} aria-pressed={mode === k} onClick={() => mode !== k && onChange(k)}
      className={`flex min-h-[40px] items-center gap-1.5 rounded-full px-3 text-sm font-medium transition ${mode === k ? 'bg-blue-500 text-white shadow' : 'opacity-70 hover:opacity-100'}`}>
      <I size={17} />{!compact && n}
    </button>
  );
  return (
    <div className="flex shrink-0 items-center gap-0.5 rounded-full border border-black/10 bg-white/50 p-0.5 dark:border-white/15 dark:bg-white/10" role="group" aria-label="Mode">
      {item('word', Type, 'Edit')}{item('note', PenLine, 'Note')}
    </div>
  );
}
