import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { ChevronUp, ChevronDown, Pencil, Trash2 } from 'lucide-react';

const LABEL = { heading: (n) => `H${n.attrs.level}`, paragraph: () => 'Text', shapeBox: () => 'Box', callout: () => 'Note box', table: () => 'Table', pageBreak: () => 'Page break', columnBreak: () => 'Column break', bulletList: () => 'List', orderedList: () => 'List', taskList: () => 'Checklist', blockquote: () => 'Quote', codeBlock: () => 'Code', horizontalRule: () => 'Line', toc: () => 'Contents' };
const hasImage = (n) => { let f = false; n.descendants((c) => { if (c.type.name === 'image') f = true; return !f; }); return f; };
const kind = (n) => (n.type.name === 'paragraph' && hasImage(n) && !n.textContent.trim() ? 'Image' : (LABEL[n.type.name] || (() => n.type.name))(n));

/** All top-level blocks (and the blocks inside column sections) of the document. */
function collect(doc) {
  const out = [];
  doc.forEach((n, off) => {
    if (n.type.name === 'sectionColumns') n.forEach((c, o) => out.push({ pos: off + 1 + o, node: c, parent: off }));
    else out.push({ pos: off, node: n, parent: -1 });
  });
  return out;
}

export default function BlocksPanel({ editor, mainRef, ask, flash }) {
  const [tick, setTick] = useState(0);
  const [active, setActive] = useState(0);
  const listRef = useRef(null);
  const rows = useRef([]);
  const items = useMemo(() => collect(editor.state.doc), [editor, tick]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    let t; const bump = () => { clearTimeout(t); t = setTimeout(() => setTick((x) => x + 1), 250); };
    editor.on('update', bump);
    return () => { editor.off('update', bump); clearTimeout(t); };
  }, [editor]);

  /* document scroll -> highlight the block at the top and scroll the panel to match */
  const sync = useCallback(() => {
    const main = mainRef.current, list = listRef.current; if (!main || !list) return;
    const top = main.getBoundingClientRect().top + 60; let cur = 0;
    for (let i = 0; i < items.length; i += 1) {
      const dom = editor.view.nodeDOM(items[i].pos);
      if (dom && dom.getBoundingClientRect && dom.getBoundingClientRect().top <= top) cur = i; else if (dom) break;
    }
    setActive(cur);
    const row = rows.current[cur];
    if (row) list.scrollTop = row.offsetTop - list.clientHeight / 3;
  }, [editor, items, mainRef]);

  useEffect(() => {
    const main = mainRef.current; if (!main) return undefined;
    let raf = 0; const h = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(sync); };
    main.addEventListener('scroll', h, { passive: true }); sync();
    return () => { main.removeEventListener('scroll', h); cancelAnimationFrame(raf); };
  }, [mainRef, sync]);

  const go = (it) => { const dom = editor.view.nodeDOM(it.pos); if (dom?.scrollIntoView) dom.scrollIntoView({ block: 'start' }); };
  const sibs = (it) => items.filter((x) => x.parent === it.parent);
  const run = (fn) => { try { fn(); } catch (e) { flash('That change is not allowed here'); } };

  const move = (it, dir) => run(() => {
    const g = sibs(it), i = g.indexOf(it), o = g[i + dir]; if (!o) return;
    const { state, view } = editor, tr = state.tr, s = it.node.nodeSize;
    if (dir < 0) tr.delete(it.pos, it.pos + s).insert(o.pos, it.node);
    else { tr.insert(o.pos + o.node.nodeSize, it.node); tr.delete(it.pos, it.pos + s); }
    view.dispatch(tr);
  });
  const del = (it) => run(() => {
    const { state, view } = editor;
    if (it.parent >= 0 && sibs(it).length === 1) { const p = state.doc.nodeAt(it.parent); view.dispatch(state.tr.delete(it.parent, it.parent + p.nodeSize)); }
    else view.dispatch(state.tr.delete(it.pos, it.pos + it.node.nodeSize));
  });
  const edit = (it) => {
    if (!it.node.isTextblock) { editor.commands.setNodeSelection(it.pos); go(it); flash('Selected. Use the tabs above to modify it.'); return; }
    ask(`Edit ${kind(it.node)}`, 'Text', (v) => run(() => {
      const { state, view } = editor, n = state.doc.nodeAt(it.pos); if (!n) return;
      const marks = n.firstChild ? n.firstChild.marks : [];
      view.dispatch(state.tr.replaceWith(it.pos + 1, it.pos + n.nodeSize - 1, v ? state.schema.text(v, marks) : []));
    }), it.node.textContent);
  };

  return (
    <div ref={listRef} className="relative h-full overflow-y-auto">
      {!items.length && <p className="px-3 py-2 text-sm opacity-60">Boxes, headings and text you add will appear here.</p>}
      {items.map((it, i) => {
        const g = sibs(it), gi = g.indexOf(it), k = kind(it.node), txt = it.node.textContent.trim();
        return (
          <div key={`${it.pos}-${i}`} ref={(el) => { rows.current[i] = el; }} className={`mb-1 rounded-xl p-1.5 ${active === i ? 'bg-blue-500/20 ring-1 ring-blue-500' : 'hover:bg-black/5 dark:hover:bg-white/10'}`}>
            <button type="button" className="block w-full text-left" onClick={() => go(it)}>
              <span className="mr-1.5 rounded-full bg-blue-500/15 px-2 py-0.5 text-[10px] font-semibold text-blue-700 dark:text-blue-300">{k}</span>
              <span className="line-clamp-2 break-words text-xs">{txt || (k === 'Image' ? 'Picture' : '—')}</span>
            </button>
            <div className="mt-1 flex justify-end gap-0.5">
              <button type="button" aria-label="Move up" disabled={gi === 0} className="rbtn !min-h-[34px] !min-w-[34px] disabled:opacity-30" onClick={() => move(it, -1)}><ChevronUp size={16} /></button>
              <button type="button" aria-label="Move down" disabled={gi === g.length - 1} className="rbtn !min-h-[34px] !min-w-[34px] disabled:opacity-30" onClick={() => move(it, 1)}><ChevronDown size={16} /></button>
              <button type="button" aria-label="Modify" className="rbtn !min-h-[34px] !min-w-[34px]" onClick={() => edit(it)}><Pencil size={15} /></button>
              <button type="button" aria-label="Remove" className="rbtn !min-h-[34px] !min-w-[34px] text-red-500" onClick={() => del(it)}><Trash2 size={15} /></button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
