import { useEffect, useRef } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import TextStyle from '@tiptap/extension-text-style';
import Color from '@tiptap/extension-color';
import FontFamily from '@tiptap/extension-font-family';
import Highlight from '@tiptap/extension-highlight';
import TextAlign from '@tiptap/extension-text-align';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Subscript from '@tiptap/extension-subscript';
import Superscript from '@tiptap/extension-superscript';
import { FontSize, TextExtras, BlockLayout, PageBreak, ColumnBreak, Toc, Callout, WordImage, SectionColumns, ShapeBox } from '../extensions.js';
import { PAGE_SIZES, FONT_SETS } from '../constants.js';

const shade = {
  cellStyle: { default: null, parseHTML: (el) => el.getAttribute('data-cs'), renderHTML: (a) => (a.cellStyle ? { 'data-cs': a.cellStyle, style: a.cellStyle } : {}) },
  backgroundColor: { default: null, parseHTML: (el) => el.style.backgroundColor || null, renderHTML: (a) => (a.backgroundColor ? { style: `background-color:${a.backgroundColor}` } : {}) } };
const Header = TableHeader.extend({ addAttributes() { return { ...this.parent?.(), ...shade }; } });
const Cell = TableCell.extend({ addAttributes() { return { ...this.parent?.(), ...shade }; } });

export function useWordEditor({ onChange }) {
  return useEditor({
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3, 4] } }),
      Underline, Subscript, Superscript, TextStyle, Color, FontFamily, FontSize, TextExtras, BlockLayout,
      Link.configure({ openOnClick: false, autolink: true, HTMLAttributes: { target: '_blank', rel: 'noopener noreferrer' } }),
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ['heading', 'paragraph'] }),
      TaskList, TaskItem.configure({ nested: true }),
      Table.configure({ resizable: true }), TableRow, Header, Cell,
      WordImage, Callout, PageBreak, ColumnBreak, Toc, SectionColumns, ShapeBox,
    ],
    content: '<p></p>',
    onUpdate: () => onChange?.(),
    editorProps: { attributes: { autocapitalize: 'sentences', autocorrect: 'on' } },
  });
}

export const pageSize = (meta) => {
  const [w, h] = PAGE_SIZES[meta.size] || PAGE_SIZES.A4;
  return meta.orientation === 'landscape' ? [h, w] : [w, h];
};

export default function EditorCanvas({ editor, meta, zoom, mode, showRuler, showGrid, marks, boundaries, onPages }) {
  const pageRef = useRef(null);
  const [W, Hh] = pageSize(meta);
  const web = mode === 'web';
  const m = meta.margins;
  const b = meta.border;

  useEffect(() => {
    if (!pageRef.current) return undefined;
    const ro = new ResizeObserver(() => onPages?.(Math.max(1, Math.ceil(pageRef.current.offsetHeight / Hh))));
    ro.observe(pageRef.current);
    return () => ro.disconnect();
  }, [Hh, onPages]);

  useEffect(() => {
    if (!editor) return;
    editor.view.dom.setAttribute('lang', meta.lang || 'en-US');
    editor.view.dom.setAttribute('spellcheck', 'true');
  }, [editor, meta.lang]);

  if (!editor) return null;
  const fonts = FONT_SETS[meta.fontSet] || FONT_SETS.office;
  const pages = Math.max(1, Math.ceil((pageRef.current?.offsetHeight || Hh) / Hh));
  const style = {
    width: web ? '100%' : W, maxWidth: web ? 900 : 'none', minHeight: web ? 600 : Hh,
    padding: web ? '32px 40px' : `${m.top}px ${m.right}px ${m.bottom}px ${m.left}px`,
    '--page-bg': meta.bg, color: meta.textColor, '--accent': meta.accent, '--body-font': fonts[0], '--head-font': fonts[1],
    border: b.style !== 'none' ? `${b.width}px ${b.style} ${b.color}` : undefined,
    boxShadow: b.shadow ? '8px 8px 0 rgba(0,0,0,.25)' : undefined,
    backgroundImage: showGrid ? 'linear-gradient(rgba(100,116,139,.22) 1px, transparent 1px), linear-gradient(90deg, rgba(100,116,139,.22) 1px, transparent 1px)' : undefined,
    backgroundSize: showGrid ? '24px 24px' : undefined,
  };
  return (
    <div className={`py-4 ${mode === 'focus' ? '' : 'px-2 sm:px-6'}`}>
      <div className="zoomwrap mx-auto w-fit" style={{ zoom }}>
        {showRuler && !web && (
          <div className="ruler no-print" style={{ width: W }}>
            <div className="ruler-margin" style={{ left: 0, width: m.left }} />
            <div className="ruler-margin" style={{ right: 0, width: m.right }} />
            {Array.from({ length: Math.ceil(W / 37.8) }, (_, i) => <span key={i} style={{ width: 37.8 }}>{i}</span>)}
          </div>
        )}
        <div ref={pageRef} className={`page relative ${marks ? 'show-marks' : ''}`} style={style}>
          {(meta.watermark.text || meta.watermark.image) && (
            <div className="wm-wrap">
              {meta.watermark.image
                ? <img src={meta.watermark.image} alt="" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ width: meta.watermark.imageWidth || 400, maxWidth: '90%', opacity: meta.watermark.opacity ?? 1 }} />
                : <div className="watermark" style={{ opacity: meta.watermark.opacity }}>{meta.watermark.text}</div>}
            </div>
          )}
          {!web && Array.from({ length: pages }, (_, i) => {
            const mb = meta.marginBorder || { style: 'none' };
            const g = mb.gap ?? 10;
            return (
              <div key={i} className="pointer-events-none absolute left-0 right-0" style={{ top: i * Hh, height: Hh, zIndex: 2 }}>
                {mb.style !== 'none' && (
                  <div className="absolute" style={{ left: Math.max(0, m.left - g), right: Math.max(0, m.right - g), top: Math.max(0, m.top - g), bottom: Math.max(0, m.bottom - g), border: `${mb.width}px ${mb.style} ${mb.color}` }} />
                )}
                {boundaries && <div className="guide no-print" style={{ left: m.left, right: m.right, top: m.top, bottom: m.bottom }} />}
                <div className="absolute left-0 right-0 text-center text-[10pt]" style={{ top: 0, height: Hh, opacity: 0.7 }}>
                  {meta.header && <div className="absolute left-0 right-0" style={{ top: Math.max(8, m.top / 2 - 8) }}>{meta.header}</div>}
                  {(meta.footer || meta.pageNumbers) && <div className="absolute left-0 right-0" style={{ bottom: Math.max(8, m.bottom / 2 - 8) }}>{meta.footer}{meta.footer && meta.pageNumbers ? '  ·  ' : ''}{meta.pageNumbers ? `Page ${i + 1}` : ''}</div>}
                </div>
                {i > 0 && <div className="page-sep" style={{ top: 0 }} />}
              </div>
            );
          })}
          <div style={{ columnCount: meta.columns > 1 ? meta.columns : undefined, columnGap: 32, position: 'relative', zIndex: 1 }}>
            <EditorContent editor={editor} />
          </div>
        </div>
      </div>
    </div>
  );
}
