import { useState, useMemo, useRef } from 'react';
import {
  Home as HomeIcon, FilePlus, FolderOpen, Clock, Pin, PinOff, LayoutTemplate, Settings, Palette, HelpCircle, Info, Search, MoreVertical,
  PanelLeftClose, PanelLeftOpen, FileText, FolderPlus, Folder, ArrowUpDown, Upload, Sun, Moon, Monitor,
} from 'lucide-react';
import { Sparkles } from 'lucide-react';
import Logo from './Logo.jsx';
import SettingsPanel from './SettingsPanel.jsx';
import { Menu, Item, Sep } from '../ribbon/ui.jsx';

const NAV = [['home', 'Home', HomeIcon], ['new', 'New', FilePlus], ['open', 'Open', FolderOpen], ['recent', 'Recent Documents', Clock], ['pinned', 'Pinned Documents', Pin], ['templates', 'Templates', LayoutTemplate], ['prefs', 'App Preferences', Settings], ['themes', 'Themes', Palette], ['help', 'Help', HelpCircle], ['about', 'About INDword', Info]];

const fmtDate = (t) => new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const fmtTime = (t) => new Date(t).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });

function Preview({ html }) {
  return <div className="relative h-[275px] overflow-hidden bg-white"><div className="tpl-preview" dangerouslySetInnerHTML={{ __html: html }} /></div>;
}

export default function Home({ docs, folders, settings, setSettings, section, setSection, templates, onTplDelete, onNew, onOpen, onPickFile, onDocAction, onFolder, onTheme, theme, openAbout, onAi }) {
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('date');
  const [folder, setFolder] = useState(null); // null = all
  const open = settings.sidebarOpen;
  const fileRef = useRef(null);

  const list = useMemo(() => {
    let l = docs.filter((d) => (folder === null || d.folder === folder) && d.name.toLowerCase().includes(q.toLowerCase()));
    if (section === 'pinned') l = l.filter((d) => d.pinned);
    return l.sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : sort === 'type' ? a.ext.localeCompare(b.ext) : b.modified - a.modified));
  }, [docs, q, sort, folder, section]);

  const Docs = ({ items }) => (
    <div className="grid gap-2">
      {!items.length && <p className="glass glass-card rounded-2xl p-6 text-center text-sm opacity-70">No documents here yet. Create one from a template above.</p>}
      {items.map((d) => (
        <div key={d.id} className="glass glass-card flex items-center gap-3 rounded-2xl p-3">
          <button type="button" onClick={() => onOpen(d)} className="flex min-h-[56px] min-w-0 flex-1 items-center gap-3 text-left">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-blue-500/15 text-blue-600 dark:text-blue-300"><FileText size={22} /></span>
            <span className="min-w-0 flex-1">
              <span className="block truncate font-medium">{d.name}<span className="opacity-50">.{d.ext}</span></span>
              <span className="block truncate text-xs opacity-60">{fmtDate(d.modified)} · {fmtTime(d.modified)} · {d.folder || 'INDword Documents'}</span>
            </span>
            <span className="hidden shrink-0 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-medium text-emerald-700 sm:block dark:text-emerald-300">Saved</span>
          </button>
          <button type="button" aria-label={d.pinned ? 'Unpin' : 'Pin'} className="rbtn" onClick={() => onDocAction(d.pinned ? 'unpin' : 'pin', d)}>{d.pinned ? <Pin size={18} className="text-blue-500" fill="currentColor" /> : <Pin size={18} className="opacity-40" />}</button>
          <Menu width={230} trigger={() => <span className="rbtn" role="button" aria-label="More"><MoreVertical size={19} /></span>}>
            {(close) => [['open', 'Open'], ['rename', 'Rename'], [d.pinned ? 'unpin' : 'pin', d.pinned ? 'Unpin' : 'Pin'], ['duplicate', 'Duplicate'], ['export', 'Download / Export'], ['move', 'Move to Folder'], ['info', 'Document Information'], ['delete', 'Delete']].map(([k, n]) => (
              <Item key={k} onClick={() => { close(); onDocAction(k, d); }} style={k === 'delete' ? { color: '#ef4444' } : undefined}>{n}</Item>
            ))}
          </Menu>
        </div>
      ))}
    </div>
  );

  const Templates = ({ big }) => (
    <div className={`grid gap-4 ${big ? 'grid-cols-2 lg:grid-cols-4' : 'grid-cols-2 md:grid-cols-4 xl:grid-cols-8'}`}>
      {templates.map((t) => (
        <div key={t.id} className="glass glass-card overflow-hidden rounded-2xl">
          <button type="button" className="block w-full" onClick={() => onNew(t.id)}><Preview html={t.html} /></button>
          <div className="p-3"><div className="truncate text-sm font-semibold">{t.name}{t.custom && <span className="ml-2 rounded-full bg-blue-500/15 px-2 py-0.5 text-[10px] font-medium text-blue-600 dark:text-blue-300">Mine</span>}</div>{big && <div className="mt-0.5 text-xs opacity-60">{t.desc}</div>}
            {big && <div className="mt-2 flex gap-2"><button type="button" className="primary !min-h-[40px] flex-1 !px-2 text-sm" onClick={() => onNew(t.id)}>Create</button>{t.custom && <button type="button" className="secondary !min-h-[40px] !px-3 text-sm text-red-500" onClick={() => onTplDelete(t)}>Delete</button>}</div>}
          </div>
        </div>
      ))}
    </div>
  );

  const FolderBar = () => (
    <div className="mb-3 flex flex-wrap items-center gap-2">
      {[null, ...folders].map((f) => (
        <span key={f ?? 'all'} className="flex items-center">
          <button type="button" onClick={() => setFolder(f)} className={`rbtn !rounded-full border border-white/20 ${folder === f ? 'rbtn-on' : 'bg-white/40 dark:bg-white/10'}`}><Folder size={15} />{f ?? 'All'}</button>
          {f && folder === f && <button type="button" className="rbtn text-xs" onClick={() => onFolder('rename', f)}>Rename</button>}
        </span>
      ))}
      <button type="button" className="rbtn" onClick={() => onFolder('create')}><FolderPlus size={17} />New Folder</button>
      <Menu width={190} trigger={() => <span className="rbtn" role="button"><ArrowUpDown size={16} />Sort</span>}>
        {(close) => [['date', 'Date Modified'], ['name', 'Name'], ['type', 'File Type']].map(([k, n]) => <Item key={k} on={sort === k} onClick={() => { setSort(k); close(); }}>{n}</Item>)}
      </Menu>
    </div>
  );

  const Title = ({ children }) => <h2 className="mb-3 mt-2 text-xl font-semibold tracking-tight">{children}</h2>;

  let body;
  if (section === 'home') body = (<><button type="button" onClick={onAi} className="glass glass-card mb-4 flex w-full items-center gap-4 rounded-2xl p-4 text-left"><span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-500 text-white"><Sparkles size={26} /></span><span><span className="block text-lg font-semibold">AI Notes from Article Images</span><span className="block text-sm opacity-70">Add clippings, copy one prompt to Gemini, paste the reply. Get syllabus-tagged notes, keywords, PYQs, mocks and a cover, laid out page by page.</span></span></button><Title>New Document</Title>{Templates({ big: false })}<Title>Recent Documents</Title>{FolderBar()}{Docs({ items: list.slice(0, 8) })}</>);
  else if (section === 'new' || section === 'templates') body = (<><Title>{section === 'new' ? 'New Document' : 'Template Gallery'}</Title>{Templates({ big: true })}<div className="mt-4"><button type="button" className="secondary" onClick={() => fileRef.current?.click()}><Upload size={17} />Import Custom Template</button><input ref={fileRef} hidden type="file" accept=".docx,.txt,.md,.markdown,.html,.htm" onChange={(e) => { const f = e.target.files?.[0]; if (f) onPickFile(f, true); e.target.value = ''; }} /></div></>);
  else if (section === 'open') body = (<><Title>Open</Title><button type="button" className="primary mb-4" onClick={onPickFile}><FolderOpen size={18} />Open from this tablet (DOCX, TXT, MD, HTML)</button><p className="mb-4 text-sm opacity-70">Pick a file from Internal storage, Downloads, Documents or any folder Android can reach. DOCX keeps headings, text styles, lists, tables and images; page layout, headers/footers and comments are not imported.</p><Title>Document Library</Title>{FolderBar()}{Docs({ items: list })}</>);
  else if (section === 'recent' || section === 'pinned') body = (<><Title>{section === 'recent' ? 'Recent Documents' : 'Pinned Documents'}</Title>{FolderBar()}{Docs({ items: list })}</>);
  else if (section === 'prefs') body = (<><Title>App Preferences</Title><SettingsPanel settings={settings} setSettings={setSettings} /></>);
  else if (section === 'themes') body = (
    <><Title>Themes</Title>
      <div className="grid max-w-xl grid-cols-3 gap-3">
        {[['light', 'Light', Sun], ['dark', 'Dark', Moon], ['system', 'System', Monitor]].map(([k, n, I]) => (
          <button key={k} type="button" onClick={() => onTheme(k)} className={`glass flex min-h-[96px] flex-col items-center justify-center gap-2 rounded-2xl ${theme === k ? 'ring-2 ring-blue-500' : ''}`}><I size={26} />{n}</button>
        ))}
      </div></>);
  else if (section === 'help') body = (
    <><Title>Help</Title>
      <div className="glass glass-card space-y-3 rounded-2xl p-5 text-sm leading-relaxed">
        <p><b>Create:</b> tap New Document, choose a template or Blank Document.</p>
        <p><b>Pictures:</b> Insert → Image. Tap a picture to get corner handles for resizing, plus a toolbar for alignment, crop, rotate, replace, download and delete.</p>
        <p><b>Tables:</b> Insert → Table, then use the green Table Layout tab that appears when you tap inside a table.</p>
        <p><b>Zoom:</b> pinch the page with two fingers to zoom in or out.</p>
        <p><b>Saving:</b> documents save automatically on this tablet and work offline. Use File → Export to make DOCX, PDF, Markdown, HTML or text files.</p>
        <p><b>Opening files:</b> Open → Open from this tablet.</p>
      </div></>);
  else body = (<><Title>About INDword</Title><div className="glass glass-card flex flex-col items-center gap-3 rounded-2xl p-8 text-center"><Logo size={96} /><div className="text-2xl font-bold">IND<span className="text-blue-500">word</span></div><p className="max-w-sm text-sm opacity-70">A Word-style document app for Android tablets. Everything is stored on this device and works offline.</p><span className="rounded-full bg-black/5 px-3 py-1 text-xs dark:bg-white/10">Version 1.0.0</span></div></>);

  return (
    <div className="wallpaper flex h-full flex-col">
      <header className="glass glass-ribbon z-30 flex items-center gap-2 rounded-b-3xl px-3 pb-2 pt-[calc(env(safe-area-inset-top)+8px)]">
        <button type="button" aria-label="Toggle sidebar" className="rbtn" onClick={() => setSettings({ ...settings, sidebarOpen: !open })}>{open ? <PanelLeftClose size={20} /> : <PanelLeftOpen size={20} />}</button>
        <Logo size={36} /><span className="hidden text-lg font-bold tracking-tight sm:block">IND<span className="text-blue-500">word</span></span>
        <div className="relative mx-2 flex-1"><Search size={16} className="absolute left-3 top-3.5 opacity-50" /><input className="ginput pl-9" placeholder="Search documents" value={q} onChange={(e) => { setQ(e.target.value); if (section === 'home' || section === 'new') setSection('recent'); }} /></div>
        <button type="button" className="primary !px-4" onClick={() => onNew('blank')}><FilePlus size={18} /><span className="hidden md:inline">New Document</span></button>
        <button type="button" className="secondary !px-4" onClick={onPickFile}><FolderOpen size={18} /><span className="hidden md:inline">Open Document</span></button>
        <button type="button" aria-label="Settings" className="rbtn" onClick={() => setSection('prefs')}><Settings size={20} /></button>
      </header>
      <div className="flex min-h-0 flex-1">
        {open && (
          <nav className="glass glass-side m-3 mr-0 w-60 shrink-0 overflow-y-auto rounded-3xl p-2">
            {NAV.map(([k, n, I]) => <button key={k} type="button" onClick={() => (k === 'about' ? openAbout() : setSection(k))} className={`mitem !min-h-[48px] ${section === k ? 'rbtn-on' : ''}`}><I size={19} />{n}</button>)}
          </nav>
        )}
        <main className="min-w-0 flex-1 overflow-y-auto p-4 pb-[calc(env(safe-area-inset-bottom)+16px)]">{body}</main>
      </div>
    </div>
  );
}
void Sep; void PinOff;
