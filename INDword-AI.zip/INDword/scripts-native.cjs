// Copies the custom "Save to…" Android plugin into the generated android project. Safe to run repeatedly.
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, 'resources', 'native');
const dest = path.join(__dirname, 'android', 'app', 'src', 'main', 'java', 'com', 'indword', 'app');
if (!fs.existsSync(path.join(__dirname, 'android'))) process.exit(0);
fs.mkdirSync(dest, { recursive: true });
['SaveAsPlugin.java', 'MainActivity.java'].forEach((f) => fs.copyFileSync(path.join(src, f), path.join(dest, f)));
console.log('INDword native save plugin installed');
